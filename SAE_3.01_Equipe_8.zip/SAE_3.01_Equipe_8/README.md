#QCM BUILDER

Afin de lancer l'application QCM Builder il vous suffit de double cliquer sur le fichier SAE_3.01_Equipe_8.jar

Si cela ne fonctionne pas, veuillez vous accorder les droits d'exécution de ce fichier avec la commande chmod.

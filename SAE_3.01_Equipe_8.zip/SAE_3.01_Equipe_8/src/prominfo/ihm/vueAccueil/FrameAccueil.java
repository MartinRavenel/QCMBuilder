package prominfo.ihm.vueAccueil;

import prominfo.Controleur;

import javax.swing.JFrame;

public class FrameAccueil extends JFrame
{
	private Controleur ctrl;

	private PanelAccueil panelAccueil;

	public FrameAccueil(Controleur ctrl)
	{
		this.ctrl = ctrl;

		this.setTitle("Accueil");
		this.setSize(750, 400);
		this.setLocationRelativeTo(panelAccueil);
		this.setResizable(false);

		this.panelAccueil = new PanelAccueil(this);

		this.add(panelAccueil);

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		this.setVisible(true);
	}

	public Controleur getCtrl()
	{
		return this.ctrl;
	}
}
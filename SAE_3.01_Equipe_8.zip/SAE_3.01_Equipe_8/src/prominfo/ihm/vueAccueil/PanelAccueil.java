package prominfo.ihm.vueAccueil;

import prominfo.ihm.vueQuestionnaires.FrameQuestionnaires;
import prominfo.ihm.vueRessources.FrameRessources;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Cursor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelAccueil extends JPanel implements ActionListener, MouseListener
{
	private FrameAccueil        frameAccueil;
	private FrameRessources     frameRessources;
	private FrameQuestionnaires frameQuestionnaires;

	private JPanel panelQCMBuilder;
	private JPanel panelBouton;

	private GridBagConstraints gbcTitre;

	private JButton btnParametrage;
	private JButton btnQuestionnaire;
	private JButton btnQuitter;

	public PanelAccueil(FrameAccueil frameAccueil)
	{
		this.frameAccueil        = frameAccueil;
		this.frameRessources     = null;
		this.frameQuestionnaires = null;

		this.setLayout(new BorderLayout());

		/* ------------------------ */
		/*  Création des composants */
		/* ------------------------ */

		this.panelQCMBuilder  = new JPanel(new GridBagLayout());
		this.panelBouton      = new JPanel(new GridLayout(4, 3, 20, 20));

		this.gbcTitre   = new GridBagConstraints();

		this.gbcTitre.insets = new Insets(25, 100, 20, 100);
		this.gbcTitre.fill   = GridBagConstraints.BOTH;

		this.gbcTitre.weightx = 1.0;
		this.gbcTitre.weighty = 1.0;

		this.btnParametrage   = new JButton("Parametrage"   );
		this.btnQuestionnaire = new JButton("Questionnaires");
		this.btnQuitter       = new JButton("Quitter"       );

		/* ------------------------------ */
		/*  Positionnement des composants */
		/* ------------------------------ */

		this.panelQCMBuilder.add(new JLabel(new ImageIcon("./src/prominfo/ressources/images/qcm-builder.png")), gbcTitre);

		this.panelBouton.add(new JLabel());
		this.panelBouton.add(this.btnParametrage);
		this.panelBouton.add(new JLabel());

		this.panelBouton.add(new JLabel());
		this.panelBouton.add(this.btnQuestionnaire);
		this.panelBouton.add(new JLabel());

		this.panelBouton.add(new JLabel());
		this.panelBouton.add(this.btnQuitter);
		this.panelBouton.add(new JLabel());

		this.panelBouton.add(new JLabel());
		this.panelBouton.add(new JLabel());
		this.panelBouton.add(new JLabel());

		this.add(this.panelQCMBuilder, BorderLayout.NORTH );
		this.add(this.panelBouton    , BorderLayout.CENTER);

		/* -------------------------- */
		/*  Activation des composants */
		/* -------------------------- */

		this.btnParametrage.addActionListener(this);
		this.btnQuestionnaire.addActionListener(this);
		this.btnQuitter.addActionListener(this);

		this.btnParametrage.addMouseListener(this);
		this.btnQuestionnaire.addMouseListener(this);
		this.btnQuitter.addMouseListener(this);
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == this.btnParametrage)
		{
			if (this.frameRessources == null || ! this.frameRessources.isShowing())
			{
				this.frameRessources = new FrameRessources(this.frameAccueil.getCtrl());
			}
		}

		if (e.getSource() == this.btnQuestionnaire)
		{
			if (this.frameQuestionnaires == null || ! this.frameQuestionnaires.isShowing())
			{
				this.frameQuestionnaires = new FrameQuestionnaires(this.frameAccueil.getCtrl());
			}
		}

		if (e.getSource() == this.btnQuitter)
		{
			System.exit(0);
		}
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnQuestionnaire.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnParametrage.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnQuitter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnQuestionnaire.setCursor(Cursor.getDefaultCursor());
		this.btnParametrage.setCursor(Cursor.getDefaultCursor());
		this.btnQuitter.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}
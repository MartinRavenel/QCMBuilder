package prominfo.ihm.vueNotions;

import prominfo.Controleur;

import prominfo.ihm.vueQuestions.FrameQuestions;
import prominfo.ihm.vueRessources.FrameRessources;

import prominfo.ihm.vueUtil.GrilleDonneesModel;
import prominfo.ihm.vueUtil.MultiButtonEditor;
import prominfo.ihm.vueUtil.MultiButtonRenderer;

import java.awt.Cursor;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JTable;
import javax.swing.SwingUtilities;

import javax.swing.table.DefaultTableModel;

public class GrilleDonneesNotions extends GrilleDonneesModel implements MouseListener
{
	private Controleur ctrl;

	private FrameRessources frameRessources;
	private FrameNotions    frameNotions;

	private String[]   tabEntetes;
	private Object[][] tabDonnees;

	private String[]   tabNotions;
	private String     codeRessource;

	private int indexEnonce;

	private boolean estOuvert = false;

	public GrilleDonneesNotions(Controleur ctrl, String codeRessource, FrameRessources frameRessources, FrameNotions frameNotions)
	{
		this.ctrl            = ctrl;
		this.frameRessources = frameRessources;
		this.frameNotions    = frameNotions;
		this.codeRessource	 = codeRessource;

		this.tblGrille = new JTable(this);

		this.majGrille();
	}

	public void majGrille()
	{
		this.tabNotions = new String[this.ctrl.getNotionsParRessource(Integer.parseInt(this.codeRessource)).length];
		
		if (this.codeRessource != null)
		{
			this.tabNotions = this.ctrl.getNotionsParRessource(Integer.parseInt(this.codeRessource));
		}
		else
		{
			this.tabNotions = null;
		}

		this.setTabEntetes(new String[] { "Code Ressource", "Nom","Actions" });
		this.tabEntetes  = this.getTabEntetes();
		this.indexEnonce = this.getIntColumn("Nom");

		this.setTabDonnees( new Object[tabNotions.length][this.tabEntetes.length]);
		this.tabDonnees = this.getTabDonnees();

		for (int i = 0; i < tabNotions.length; i++)
		{
			this.tabDonnees[i][0] = "R" + codeRessource.charAt(0) + "." + codeRessource.substring(1);
			this.tabDonnees[i][1] = tabNotions[i];
			this.tabDonnees[i][2] = "Actions";
		}

		this.tblGrille.setModel(new DefaultTableModel(this.tabDonnees, this.tabEntetes));
		this.tblGrille.getColumn("Actions").setCellRenderer(new MultiButtonRenderer());
		this.tblGrille.getColumn("Actions").setCellEditor(new MultiButtonEditor(this));
		this.tblGrille.setRowHeight(40);

		this.tblGrille.addMouseListener(this);
		this.fireTableDataChanged();
	}

	@Override
	public void supprimer(int ligne)
	{
		String nomNot = this.tabNotions[ligne];
		this.ctrl.supprimerNotion(this.codeRessource, nomNot);
		this.majGrille();
	}

	public void modifier(int ligne)
	{
		new FrameCreationNotion(this.frameRessources.getCtrl(), this, Integer.parseInt(this.codeRessource), this.tabNotions[ligne]);
	}

	public boolean isCellEditable(int row, int col)
	{
		for (int cpt = 0; cpt < this.tabEntetes.length; cpt++)
		{
			if (this.tabEntetes[cpt].equals("Actions"))
			{
				return col == cpt;
			}
		}

		return false;
	}

	public int getIndexEnonce()
	{
		return this.indexEnonce;
	}

	public void mouseEntered(MouseEvent e)
	{
		this.tblGrille.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.tblGrille.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked(MouseEvent e)
	{
		if (e.getClickCount() == 1)
		{
			int col = this.tblGrille.columnAtPoint(e.getPoint());
			int row = this.tblGrille.rowAtPoint(e.getPoint());

			if (col != this.getIntColumn("Actions"))
			{
				String notion = this.tabNotions[row];

				if (!this.estOuvert)
				{
					this.estOuvert = true;
					SwingUtilities.invokeLater(() ->
					{
						new FrameQuestions(this.ctrl, this.frameRessources, this.frameNotions, notion);
						this.frameNotions.dispose();
						this.estOuvert = false;
					});
				}
			}
		}
	}

	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}
package prominfo.ihm.vueNotions;

import prominfo.Controleur;

import prominfo.ihm.vueRessources.FrameRessources;

import javax.swing.JFrame;

public class FrameNotions extends JFrame
{
	private Controleur ctrl;

	private FrameRessources frameRessources;

	private PanelNotions    panelNotions;

	private String codeRess;

	public FrameNotions(Controleur ctrl, FrameRessources frameRessources, String codeRess)
	{
		this.ctrl            = ctrl;
		this.frameRessources = frameRessources;
		this.codeRess        = codeRess;

		this.setTitle("QCM Builder" + " - " + "R" + codeRess.substring(0, 1) + "." + codeRess.substring(1, 3) + " " + this.ctrl.getRessourceParCode(Integer.parseInt(codeRess)));
		this.setSize(1800, 900);
		this.setLocationRelativeTo(panelNotions);

		this.panelNotions = new PanelNotions(this);

		this.add(panelNotions);

		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		this.setVisible(true);
	}

	public Controleur getCtrl()
	{
		return this.ctrl;
	}

	public FrameRessources getFrameRessources()
	{
		return this.frameRessources;
	}

	public String getCodeRess()
	{
		return this.codeRess;
	}
}
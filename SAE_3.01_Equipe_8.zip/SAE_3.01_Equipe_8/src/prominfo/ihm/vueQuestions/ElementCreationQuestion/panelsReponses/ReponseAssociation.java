package prominfo.ihm.vueQuestions.ElementCreationQuestion.panelsReponses;

import java.awt.Cursor;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ReponseAssociation extends JPanel implements MouseListener
{
	private PanelAssoc panelAssocTxtArea1;
	private PanelAssoc panelAssocTxtArea2;

	private JButton btnDelete;

	private JLabel lblFleche;

	public ReponseAssociation(String enonce1, String enonce2)
	{
		this.setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();

		this.btnDelete = new JButton(new ImageIcon("./src/prominfo/ressources/images/supprimerRep.png"));
		this.btnDelete.setBorderPainted(false);
		this.btnDelete.setContentAreaFilled(false);

		this.panelAssocTxtArea1 = new PanelAssoc(enonce1);
		this.panelAssocTxtArea2 = new PanelAssoc(enonce2);

		this.lblFleche = new JLabel(new ImageIcon("./src/prominfo/ressources/images/fleche-droite.png"));

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.gridx   = 0;
		gbc.gridy   = 0;
		gbc.weightx = 0.007;
		gbc.ipady   = 26;
		gbc.weighty = 0.1;
		gbc.insets  = new Insets(36,1,115,1);
		this.add(this.btnDelete, gbc);

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.gridx   = 1;
		gbc.gridy   = 0;
		gbc.weightx = 0.45;
		gbc.insets  = new Insets(18,5,-3,0);
		this.add(this.panelAssocTxtArea1, gbc);

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.gridx   = 2;
		gbc.gridy   = 0;
		gbc.weightx = 0.095;
		gbc.ipady   = 40;
		gbc.weighty = 0.2;
		gbc.insets  = new Insets(0,5,75,5);
		this.add(this.lblFleche, gbc);

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.gridx   = 3;
		gbc.gridy   = 0;
		gbc.weightx = 0.45;
		gbc.insets  = new Insets(23,0,0,0);
		this.add(this.panelAssocTxtArea2, gbc);

		this.btnDelete.addMouseListener(this);
	}

	public String getContentTextArea2()
	{
		try { return this.panelAssocTxtArea2.getTexteAreaEditor().getDocument().getText(0, this.panelAssocTxtArea2.getTexteAreaEditor().getDocument().getLength()); }
		catch (Exception e) { e.printStackTrace(); }

		return null;
	}

	public JEditorPane getEditorPane1()
	{
		return this.panelAssocTxtArea1.getTexteAreaEditor();
	}

	public JEditorPane getEditorPane2()
	{
		return this.panelAssocTxtArea2.getTexteAreaEditor();
	}

	public String getImage1()
	{
		return this.panelAssocTxtArea1.getImage();
	}

	public String getImage2()
	{
		return this.panelAssocTxtArea2.getImage();
	}

	public String getContentTextArea1()
	{
		try { return this.panelAssocTxtArea1.getTexteAreaEditor().getDocument().getText(0, this.panelAssocTxtArea1.getTexteAreaEditor().getDocument().getLength()); }
		catch (Exception e) { e.printStackTrace(); }

		return null;
	}

	public JButton getBtnDelete()
	{
		return this.btnDelete;
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnDelete.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnDelete.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}
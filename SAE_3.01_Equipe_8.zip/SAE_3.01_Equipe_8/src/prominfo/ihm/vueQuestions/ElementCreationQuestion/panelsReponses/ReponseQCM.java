package prominfo.ihm.vueQuestions.ElementCreationQuestion.panelsReponses;

import prominfo.ihm.vueQuestions.styleComponents.IStyleEditor;
import prominfo.ihm.vueQuestions.styleComponents.PanelStyleEditor;

import java.awt.Cursor;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import javax.swing.text.rtf.RTFEditorKit;

public class ReponseQCM extends JPanel implements MouseListener, IStyleEditor
{
	private static int nbPanel = 0;

	private int idPanel;

	private PanelStyleEditor panelStyleEditor;

	private RTFEditorKit rtfEditor;

	private JEditorPane epTextArea;

	private JCheckBox cbBonneRep;

	private JButton btnDelete;

	public ReponseQCM(String enonce, boolean bonne)
	{
		this.idPanel = ++ReponseQCM.nbPanel;
		this.setLayout(new GridBagLayout());

		this.rtfEditor  = new RTFEditorKit();

		GridBagConstraints gbc = new GridBagConstraints();

		this.btnDelete  = new JButton(new ImageIcon("./src/prominfo/ressources/images/supprimerRep.png"));
		this.btnDelete.setBorderPainted(false);
		this.btnDelete.setContentAreaFilled(false);

		this.epTextArea = new JEditorPane();
		this.cbBonneRep = new JCheckBox();

		this.cbBonneRep.setSelected(bonne);

		this.epTextArea.setContentType("text/rtf");
		this.epTextArea.setEditorKit(this.rtfEditor);

		this.panelStyleEditor = new PanelStyleEditor(this, enonce);

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 0.005;
		gbc.ipady   = 25;
		gbc.gridy   = 0;
		gbc.gridx   = 0;
		this.add(this.btnDelete, gbc);

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.ipady   = 67;
		gbc.weightx = 0.945;
		gbc.gridy   = 0;
		gbc.gridx   = 1;
		gbc.insets  = new Insets(2,5,2,10);
		this.add(new JScrollPane(this.epTextArea), gbc);

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 0.05;
		gbc.ipady   = 40;
		gbc.gridy   = 0;
		gbc.gridx   = 2;
		this.add(this.cbBonneRep, gbc);

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 0.5;
		gbc.ipady   = 40;
		gbc.gridy   = 1;
		gbc.gridx   = 1;
		this.add(this.panelStyleEditor, gbc);

		this.btnDelete.addMouseListener(this);
	}

	public String getContentTextArea()
	{
		try
		{
			return this.epTextArea.getDocument().getText(0, this.epTextArea.getDocument().getLength());
		}
		catch (Exception e)
		{
			System.out.println("document vide ou invalide");
		}

		return null;
	}

	public String getImage()
	{
		return this.panelStyleEditor.getImage();
	}

	public int getIdPanel()
	{
		return this.idPanel;
	}

	public boolean getBonneRep()
	{
		return this.cbBonneRep.isSelected();
	}

	public JButton getBtnDelete()
	{
		return this.btnDelete;
	}

	@Override
	public JEditorPane getTexteAreaEditor()
	{
		return this.epTextArea;
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnDelete.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnDelete.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}
package prominfo.ihm.vueQuestions.ElementCreationQuestion;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class FrameAjoutExplication extends JFrame implements ActionListener, MouseListener
{
	private JPanel panelTextArea;
	private JPanel panelValider;
	private JPanel panelLabel;

	private JButton btnValider;
	private JButton btnAnnuler;

	private JTextArea txtExplication;

	public FrameAjoutExplication()
	{
		this.setSize(400, 200);
		this.setTitle("Explications");
		this.setLocationRelativeTo(this);
		this.setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();

		this.panelLabel     = new JPanel(new FlowLayout(FlowLayout.LEFT));
		this.panelValider   = new JPanel(new FlowLayout(FlowLayout.LEFT));
		this.panelTextArea  = new JPanel(new BorderLayout());

		this.btnValider     = new JButton("Valider");
		this.btnAnnuler     = new JButton("Annuler");

		this.txtExplication = new JTextArea();

		this.panelLabel.add(new JLabel("Explications :", JLabel.LEFT));

		this.panelTextArea.add(this.txtExplication, BorderLayout.CENTER);

		this.panelValider.add(this.btnValider);
		this.panelValider.add(this.btnAnnuler);

		gbc.fill    = GridBagConstraints.BOTH;
		gbc.weightx = 1;
		gbc.weighty = 0.01;
		gbc.gridy   = 0;
		this.add(this.panelLabel, gbc);
		gbc.fill    = GridBagConstraints.BOTH;
		gbc.weightx = 1;
		gbc.weighty = 0.94;
		gbc.gridy   = 1;
		this.add(new JScrollPane(this.panelTextArea), gbc);
		gbc.fill    = GridBagConstraints.BOTH;
		gbc.weightx = 1;
		gbc.weighty = 0.05;
		gbc.gridy   = 2;
		this.add(this.panelValider, gbc);

		this.btnAnnuler.addActionListener(this);
		this.btnValider.addActionListener(this);

		this.btnAnnuler.addMouseListener(this);
		this.btnValider.addMouseListener(this);

		this.setVisible(false);
	}

	public String getFeedback()
	{
		return this.txtExplication.getText();
	}

	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == this.btnValider)
		{
			this.setVisible(false);
		}
		if(e.getSource() == this.btnAnnuler)
		{
			this.setVisible(false);
		}
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnAnnuler.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnValider.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnAnnuler.setCursor(Cursor.getDefaultCursor());
		this.btnValider.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}
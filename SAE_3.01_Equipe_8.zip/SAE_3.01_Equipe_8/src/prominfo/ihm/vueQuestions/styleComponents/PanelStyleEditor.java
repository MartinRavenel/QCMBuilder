package prominfo.ihm.vueQuestions.styleComponents;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Image;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;

import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDropEvent;

import java.awt.image.BufferedImage;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import java.io.File;

import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import java.util.List;

import javax.imageio.ImageIO;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;

public class PanelStyleEditor extends JPanel implements MouseListener, ActionListener
{
	private static final String CLE_IMAGE = "¤";

	private final DefaultStyledDocument doc;

	private final Style DEFAULT_STYLE;
	private final Style BOLD_STYLE;
	private final Style ITALIC_STYLE;
	private final Style UNDERLINED_STYLE;
	private final Style COLORED_STYLE;
	private final Style SIZED_STYLE;
	private final Style IMAGE_STYLE;

	private Color col;

	private JTextField txtSize;

	private StyleContext sc;

	private IStyleEditor iStyleEditor;

	private JButton btnGras;
	private JButton btnUnderline;
	private JButton btnItalique;
	private JButton btnApplyColor;
	private JButton btnSelectColor;
	private JButton btnSize;
	private JButton btnDefault;
	private JButton btnInsertFile;

	private JLabel  lblErreur;
	private JLabel  lblColorRender;
	private JLabel  lblImage;

	private String  image;

	private boolean dragEnable;

	public PanelStyleEditor(IStyleEditor iStyleEditor, String enonce)
	{
		this.iStyleEditor = iStyleEditor;

		this.sc = new StyleContext();
		Style styleDefault = this.sc.getStyle(StyleContext.DEFAULT_STYLE);
		this.DEFAULT_STYLE = this.sc.addStyle("default", styleDefault);
		StyleConstants.setFontSize(this.DEFAULT_STYLE, 12);
		StyleConstants.setBold(this.DEFAULT_STYLE, false);
		StyleConstants.setItalic(this.DEFAULT_STYLE, false);
		StyleConstants.setUnderline(this.DEFAULT_STYLE, false);
		StyleConstants.setForeground(this.DEFAULT_STYLE, Color.BLACK);

		this.col = Color.BLACK;
		this.dragEnable = true;

		this.setLayout(new FlowLayout(FlowLayout.LEFT));

		this.btnDefault     = new JButton("Police par défaut");
		this.btnSize        = new JButton("Appliquer la taille");
		this.btnGras        = new JButton("Gras");
		this.btnUnderline   = new JButton("Souligner");
		this.btnItalique    = new JButton("Italique");
		this.btnSelectColor = new JButton("Sélectionner couleur");
		this.btnApplyColor  = new JButton("Appliquer la couleur");
		this.btnInsertFile  = new JButton("Ajouter Image");

		this.lblErreur      = new JLabel();
		this.lblColorRender = new JLabel("       ");
		this.lblImage       = new JLabel();

		this.txtSize        = new JTextField(Integer.toString(12), 2);

		this.lblColorRender.setOpaque(true);
		this.lblColorRender.setBackground(col);

		this.add(this.btnDefault);
		this.add(this.btnSize);
		this.add(new JLabel(" : "));
		this.add(this.txtSize);
		this.add(new JLabel(" "));

		this.add(this.btnGras);
		this.add(this.btnUnderline);
		this.add(this.btnItalique);
		this.add(this.btnSelectColor);
		this.add(new JLabel(" : "));
		this.add(this.lblColorRender);
		this.add(this.btnApplyColor);
		this.add(this.lblImage);
		this.add(new JLabel(" "));

		this.add(this.btnInsertFile);
		this.add(new JLabel(" "));
		this.add(this.lblErreur);

		this.btnDefault.addActionListener(this);
		this.btnSize.addActionListener(this);
		this.btnGras.addActionListener(this);
		this.btnUnderline.addActionListener(this);
		this.btnItalique.addActionListener(this);
		this.btnSelectColor.addActionListener(this);
		this.btnApplyColor.addActionListener(this);
		this.btnInsertFile.addActionListener(this);

		this.btnDefault.addMouseListener(this);
		this.btnSize.addMouseListener(this);
		this.btnGras.addMouseListener(this);
		this.btnUnderline.addMouseListener(this);
		this.btnItalique.addMouseListener(this);
		this.btnSelectColor.addMouseListener(this);
		this.btnApplyColor.addMouseListener(this);
		this.btnInsertFile.addMouseListener(this);

		this.iStyleEditor.getTexteAreaEditor().setDropTarget(new GestionnaireDragAndDrop());
		this.iStyleEditor.getTexteAreaEditor().addKeyListener(new GestionnaireClavier());

		this.sc = new StyleContext();
		this.doc = new DefaultStyledDocument(sc);
		if(enonce != null)
		{
			try {
				this.doc.insertString(0, enonce, null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		

		iStyleEditor.getTexteAreaEditor().setDocument(doc);

		this.BOLD_STYLE = this.sc.addStyle("bold", null);
		StyleConstants.setBold(this.BOLD_STYLE, true);

		this.ITALIC_STYLE = this.sc.addStyle("italic", null);
		StyleConstants.setItalic(this.ITALIC_STYLE, true);

		this.UNDERLINED_STYLE = this.sc.addStyle("underlined", null);
		StyleConstants.setUnderline(this.UNDERLINED_STYLE, true);

		this.COLORED_STYLE = this.sc.addStyle("colored", null);
		StyleConstants.setForeground(this.COLORED_STYLE, Color.BLACK);

		this.SIZED_STYLE = this.sc.addStyle("sized", null);
		StyleConstants.setFontSize(this.SIZED_STYLE, ((StyledDocument)this.iStyleEditor.getTexteAreaEditor().getDocument()).getFont(this.DEFAULT_STYLE).getSize());

		this.IMAGE_STYLE = this.sc.addStyle("image", null);
		StyleConstants.setIcon(this.IMAGE_STYLE, new ImageIcon());
	}

	public void errorPrinter(int val)
	{
		switch (val)
		{
			case 1 ->  {this.lblErreur.setText("Pas de texte selectionné" );}
			case 2 ->  {this.lblErreur.setText("Valeur de taille invalide");}
			default -> {this.lblErreur.setText("");}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		int error = 0;

		if(e.getSource() == this.btnGras)
		{
			if(this.iStyleEditor.getTexteAreaEditor().getSelectedText() != null)
			{
				((StyledDocument)this.iStyleEditor.getTexteAreaEditor().getDocument()).setCharacterAttributes(this.iStyleEditor.getTexteAreaEditor().getSelectionStart(), this.iStyleEditor.getTexteAreaEditor().getSelectionEnd() - this.iStyleEditor.getTexteAreaEditor().getSelectionStart(), this.BOLD_STYLE, false);
			}
			else
			{
				error = 1;
			}
		}

		if (e.getSource() == this.btnSelectColor) 
		{
			this.col = JColorChooser.showDialog(null, "Choisir couleur", this.col);
			this.majLabel();
		}

		if(e.getSource() == this.btnApplyColor)
		{
			if(this.iStyleEditor.getTexteAreaEditor().getSelectedText() != null)
			{
				((StyledDocument)this.iStyleEditor.getTexteAreaEditor().getDocument()).setCharacterAttributes(this.iStyleEditor.getTexteAreaEditor().getSelectionStart(), this.iStyleEditor.getTexteAreaEditor().getSelectionEnd() - this.iStyleEditor.getTexteAreaEditor().getSelectionStart(), this.COLORED_STYLE, false);
				StyleConstants.setForeground(this.COLORED_STYLE, Color.BLACK);
				((StyledDocument)this.iStyleEditor.getTexteAreaEditor().getDocument()).setCharacterAttributes(this.iStyleEditor.getTexteAreaEditor().getSelectionEnd(), 1, this.COLORED_STYLE, false);
				StyleConstants.setForeground(this.COLORED_STYLE, col);
			}
			else
			{
				error = 1;
			}
		}

		if(e.getSource() == this.btnItalique)
		{
			if(this.iStyleEditor.getTexteAreaEditor().getSelectedText() != null)
			{
				((StyledDocument)this.iStyleEditor.getTexteAreaEditor().getDocument()).setCharacterAttributes(this.iStyleEditor.getTexteAreaEditor().getSelectionStart(), this.iStyleEditor.getTexteAreaEditor().getSelectionEnd() - this.iStyleEditor.getTexteAreaEditor().getSelectionStart(), this.ITALIC_STYLE, false);
			}
			else
			{
				error = 1;
			}
		}

		if(e.getSource() == this.btnUnderline)
		{
			if(this.iStyleEditor.getTexteAreaEditor().getSelectedText() != null)
			{
				((StyledDocument)this.iStyleEditor.getTexteAreaEditor().getDocument()).setCharacterAttributes(this.iStyleEditor.getTexteAreaEditor().getSelectionStart(), this.iStyleEditor.getTexteAreaEditor().getSelectionEnd() - this.iStyleEditor.getTexteAreaEditor().getSelectionStart(), this.UNDERLINED_STYLE, false);
			}
			else
			{
				error = 1;
			}
		}

		if(e.getSource() == this.btnSize)
		{
			if(this.iStyleEditor.getTexteAreaEditor().getSelectedText() != null)
			{
				if(this.txtSize.getText() != null)
				{
					if(this.txtSize.getText().matches("\\d+"))
					{
						StyleConstants.setFontSize(this.SIZED_STYLE, Integer.parseInt(this.txtSize.getText()));
						((StyledDocument)this.iStyleEditor.getTexteAreaEditor().getDocument()).setCharacterAttributes(this.iStyleEditor.getTexteAreaEditor().getSelectionStart(), this.iStyleEditor.getTexteAreaEditor().getSelectionEnd() - this.iStyleEditor.getTexteAreaEditor().getSelectionStart(), this.SIZED_STYLE, false);
					}
					else
					{
						error = 2;
					}
				}
				else
				{
					error = 2;
				}
			}
			else
			{
				error = 1;
			}
		}

		if(e.getSource() == this.btnDefault)
		{
			((StyledDocument)this.iStyleEditor.getTexteAreaEditor().getDocument()).setCharacterAttributes(this.iStyleEditor.getTexteAreaEditor().getSelectionStart(), this.iStyleEditor.getTexteAreaEditor().getSelectionEnd() - this.iStyleEditor.getTexteAreaEditor().getSelectionStart(), this.DEFAULT_STYLE, false);
		}

		if(e.getSource() == this.btnInsertFile)
		{
			JFileChooser fileChooser = new JFileChooser();

			int returnedValue = fileChooser.showOpenDialog(null);

			if (returnedValue == JFileChooser.APPROVE_OPTION) 
			{
				File file = fileChooser.getSelectedFile();
				this.ajouterMicroImage(file);
			}
		}

		this.errorPrinter(error);
	}

	private static boolean fichiersValides(File file)
	{
		return
		file.getName().endsWith(".png") || file.getName().endsWith(".PNG") ||
		file.getName().endsWith(".jpg") || file.getName().endsWith(".JPG") || file.getName().endsWith(".jpeg") || file.getName().endsWith(".JPEG") ||
		file.getName().endsWith(".gif") || file.getName().endsWith(".GIF");
	}

	public boolean ajouterMicroImage(File file)
	{
		if(this.dragEnable)
		{
			if(PanelStyleEditor.fichiersValides(file))
			{
				try
				{
					BufferedImage image = ImageIO.read(file);
					StyledDocument document = ((StyledDocument)this.iStyleEditor.getTexteAreaEditor().getDocument());
					Image image2 = image.getScaledInstance(150, 150, Image.SCALE_DEFAULT);
					StyleConstants.setIcon(this.IMAGE_STYLE, new ImageIcon(image2));
					document.insertString(document.getLength(), PanelStyleEditor.CLE_IMAGE, this.IMAGE_STYLE);
					this.image = file.getName();
					Files.copy(file.toPath(), (new File("./src/prominfo/ressources/import/temp/" + file.getName())).toPath(), StandardCopyOption.REPLACE_EXISTING);
					this.dragEnable = false;
				}
				catch (Exception ex) { ex.printStackTrace(); }

				this.lblImage.setText(file.getName());
				this.btnInsertFile.setEnabled(false);
				return true;
			}
			else
			{
				JOptionPane.showMessageDialog(null, "fichier Image non valide (PNG, JPG et GIF valide)", "Erreur", JOptionPane.ERROR_MESSAGE);
				return false;
			}
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Une image a déjà été inséré", "Erreur", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public void majLabel()
	{
		this.lblColorRender.setBackground(this.col);
		StyleConstants.setForeground(this.COLORED_STYLE, this.col);
	}

	public String getImage()
	{
		return this.image;
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnApplyColor.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnDefault.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnGras.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnInsertFile.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnItalique.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnSelectColor.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnSize.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnApplyColor.setCursor(Cursor.getDefaultCursor());
		this.btnDefault.setCursor(Cursor.getDefaultCursor());
		this.btnGras.setCursor(Cursor.getDefaultCursor());
		this.btnInsertFile.setCursor(Cursor.getDefaultCursor());
		this.btnItalique.setCursor(Cursor.getDefaultCursor());
		this.btnSelectColor.setCursor(Cursor.getDefaultCursor());
		this.btnSize.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}

	private class GestionnaireClavier extends KeyAdapter
	{
		@Override
		public void keyReleased(KeyEvent e) 
		{
			try
			{
				if(!((StyledDocument)PanelStyleEditor.this.iStyleEditor.getTexteAreaEditor().getDocument()).getText(0, ((StyledDocument)PanelStyleEditor.this.iStyleEditor.getTexteAreaEditor().getDocument()).getLength()).contains(PanelStyleEditor.CLE_IMAGE))
				{
					PanelStyleEditor.this.btnInsertFile.setEnabled(true);
					PanelStyleEditor.this.lblImage.setText("");
					PanelStyleEditor.this.image = null;
					PanelStyleEditor.this.dragEnable = true;
				}
			}
			catch (Exception ex) { ex.printStackTrace(); }
		}
	}

	private class GestionnaireDragAndDrop extends DropTarget
	{
		@Override
		public void drop(DropTargetDropEvent event)
		{
			event.acceptDrop(DnDConstants.ACTION_COPY);
			Transferable transferable = event.getTransferable();
			DataFlavor[] tabFlavors = transferable.getTransferDataFlavors();

			for (DataFlavor flavor : tabFlavors)
			{
				try
				{
					if (flavor.isFlavorJavaFileListType()) 
					{
						@SuppressWarnings("unchecked")
						List<File> files = ((List<File>) transferable.getTransferData(flavor));
						PanelStyleEditor.this.ajouterMicroImage(files.get(0));
					}

				}
				catch (Exception e) { e.printStackTrace(); }
			}

			event.dropComplete(true);
		}
	}
}
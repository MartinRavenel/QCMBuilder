package prominfo.ihm.vueQuestions.styleComponents;

import javax.swing.JEditorPane;

public interface IStyleEditor
{
	public JEditorPane getTexteAreaEditor();
}
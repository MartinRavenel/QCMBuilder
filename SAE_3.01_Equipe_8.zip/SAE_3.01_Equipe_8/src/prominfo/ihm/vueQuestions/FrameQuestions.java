package prominfo.ihm.vueQuestions;

import prominfo.Controleur;

import prominfo.ihm.vueNotions.FrameNotions;
import prominfo.ihm.vueRessources.FrameRessources;

import javax.swing.JFrame;

public class FrameQuestions extends JFrame
{
	private Controleur ctrl;

	private FrameRessources frameRessources;
	private FrameNotions    frameNotions;

	private PanelQuestions  panelQuestions;

	private String nomNotion;

	public FrameQuestions(Controleur ctrl, FrameRessources frameRessources, FrameNotions frameNotions, String nomNotion)
	{
		this.ctrl            = ctrl;
		this.frameRessources = frameRessources;
		this.frameNotions    = frameNotions;
		this.nomNotion       = nomNotion;

		this.setTitle("QCM Builder" + " - " + nomNotion);
		this.setSize(1800, 900);
		this.setLocationRelativeTo(panelQuestions);

		this.panelQuestions = new PanelQuestions(this, nomNotion);

		this.add(panelQuestions);

		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		this.setVisible(true);
	}

	public Controleur getCtrl()
	{
		return this.ctrl;
	}

	public FrameRessources getFrameRessources()
	{
		return this.frameRessources;
	}

	public FrameNotions getFrameNotions()
	{
		return this.frameNotions;
	}

	public String getNotion()
	{
		return this.nomNotion;
	}
}
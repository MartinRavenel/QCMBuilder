package prominfo.ihm.vueQuestions;

import prominfo.ihm.vueAccueil.FrameAccueil;
import prominfo.ihm.vueNotions.FrameNotions;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class PanelQuestions extends JPanel implements ActionListener, MouseListener
{
	private FrameQuestions frameQuestions;

	private GrilleDonneesQuestions grilleDonneesQuestions;

	private JPanel panelTitre;
	private JPanel panelGrille;
	private JPanel panelBouton;

	private GridBagConstraints gbcTableau;
	private GridBagConstraints gbcBouton;
	private GridBagConstraints gbcTitre;

	private JButton btnAccueil;
	private JButton btnAjouterQuestion;
	private JButton btnRetour;

	private String nomNotion;

	public PanelQuestions(FrameQuestions frameQuestions, String nomNotion)
	{
		this.frameQuestions = frameQuestions;
		this.nomNotion      = nomNotion;

		this.setLayout(new BorderLayout());

		/* ------------------------ */
		/*  Création des composants */
		/* ------------------------ */

		this.panelTitre  = new JPanel(new GridBagLayout());
		this.panelGrille = new JPanel(new GridBagLayout());
		this.panelBouton = new JPanel(new GridBagLayout());

		this.grilleDonneesQuestions = new GrilleDonneesQuestions(this.frameQuestions.getCtrl(), this.frameQuestions, this.nomNotion);

		this.gbcTableau = new GridBagConstraints();
		this.gbcBouton  = new GridBagConstraints();
		this.gbcTitre   = new GridBagConstraints();

		this.gbcTitre.insets    = new Insets(25, 700, 0, 600);
		this.gbcTitre.fill      = GridBagConstraints.BOTH;

		this.gbcTitre.weightx   = 1.0;
		this.gbcTitre.weighty   = 1.0;

		this.gbcTableau.insets  = new Insets(25, 200, 50, 200);
		this.gbcTableau.fill    = GridBagConstraints.BOTH;

		this.gbcTableau.weightx = 1.0;
		this.gbcTableau.weighty = 1.0;

		this.gbcBouton.insets   = new Insets(0, 250, 50, 250);
		this.gbcBouton.fill     = GridBagConstraints.BOTH;

		this.gbcBouton.weightx  = 1.0;
		this.gbcBouton.weighty  = 1.0;

		this.btnAccueil = new JButton(new ImageIcon("./src/prominfo/ressources/images/accueil.png"));
		this.btnAccueil.setPreferredSize(new Dimension(100, 100));
		this.btnAccueil.setBorderPainted(false);
		this.btnAccueil.setContentAreaFilled(false);

		this.btnAjouterQuestion = new JButton("Ajouter");
		this.btnAjouterQuestion.setPreferredSize(new Dimension(50, 50));

		this.btnRetour = new JButton("Retour");
		this.btnRetour.setPreferredSize(new Dimension(50, 50));

		/* ------------------------------ */
		/*  Positionnement des composants */
		/* ------------------------------ */

		this.panelTitre.add(this.btnAccueil);
		this.panelTitre.add(new JLabel((new ImageIcon("./src/prominfo/ressources/images/questions.png"))), gbcTitre, JLabel.CENTER);

		this.panelGrille.add(new JScrollPane(this.grilleDonneesQuestions.getTable()), gbcTableau);

		this.panelBouton.add(this.btnRetour, gbcBouton);
		this.panelBouton.add(this.btnAjouterQuestion, gbcBouton);

		this.add(this.panelTitre , BorderLayout.NORTH );
		this.add(this.panelGrille, BorderLayout.CENTER);
		this.add(this.panelBouton, BorderLayout.SOUTH );

		/* -------------------------- */
		/*  Activation des composants */
		/* -------------------------- */

		this.btnAccueil.addActionListener(this);
		this.btnAjouterQuestion.addActionListener(this);
		this.btnRetour.addActionListener(this);

		this.btnAccueil.addMouseListener(this);
		this.btnAjouterQuestion.addMouseListener(this);
		this.btnRetour.addMouseListener(this);
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == this.btnAccueil)
		{
			for( int i = 0; i < FrameQuestions.getFrames().length; i++ ) { FrameQuestions.getFrames()[i].dispose(); }
			new FrameAccueil(this.frameQuestions.getCtrl());
		}

		if (e.getSource() == this.btnAjouterQuestion)
		{
			new FrameCreationQuestion(this.frameQuestions.getCtrl(), this.frameQuestions, this.grilleDonneesQuestions, ' ', null, null, null, null, null, null);
		}

		if (e.getSource() == this.btnRetour)
		{
			new FrameNotions(this.frameQuestions.getCtrl(), this.frameQuestions.getFrameRessources(), this.frameQuestions.getCtrl().getRessourceParNotion(this.nomNotion));
			this.frameQuestions.dispose();
		}
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnAccueil.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnAjouterQuestion.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnRetour.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnAccueil.setCursor(Cursor.getDefaultCursor());
		this.btnAjouterQuestion.setCursor(Cursor.getDefaultCursor());
		this.btnRetour.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}
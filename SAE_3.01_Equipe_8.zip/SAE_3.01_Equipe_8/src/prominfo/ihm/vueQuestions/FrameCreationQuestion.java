package prominfo.ihm.vueQuestions;

import prominfo.Controleur;

import prominfo.ihm.vueQuestions.ElementCreationQuestion.FrameAjoutExplication;
import prominfo.ihm.vueQuestions.ElementCreationQuestion.PanelLstReponse;

import prominfo.ihm.vueQuestions.ElementCreationQuestion.panelsReponses.ReponseAssociation;
import prominfo.ihm.vueQuestions.ElementCreationQuestion.panelsReponses.ReponseElimination;
import prominfo.ihm.vueQuestions.ElementCreationQuestion.panelsReponses.ReponseQCM;

import prominfo.ihm.vueQuestions.styleComponents.IStyleEditor;
import prominfo.ihm.vueQuestions.styleComponents.PanelStyleEditor;

import prominfo.metier.Difficulte;
import prominfo.metier.Notion;
import prominfo.metier.Question;
import prominfo.metier.Ressource;

import prominfo.metier.ModelReponses.RAsso;
import prominfo.metier.ModelReponses.RElim;
import prominfo.metier.ModelReponses.Rcm;
import prominfo.metier.ModelReponses.Reponse;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import java.util.HashMap;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.text.Document;

import javax.swing.text.rtf.RTFEditorKit;

public class FrameCreationQuestion extends JFrame implements ActionListener, MouseListener, IStyleEditor
{
	private Controleur ctrl;

	private FrameQuestions frameQuestions;

	private GrilleDonneesQuestions grilleDonneesQuestions;

	private PanelLstReponse  panelLstReponse;
	private PanelStyleEditor panelStyleEditor;

	private Ressource  ressource;
	private Notion     notion;
	private Difficulte diffQuestion;
	private char   typeQuestion;
	private String enonce;
	private String explication;
	private double nbPoints;
	private int tps;

	private boolean modif;

	private File   fichierSelectionne;
	private Path   cheminDossierImport;

	private JFrame  frameExplication;

	private JPanel  panelChoixNRD;
	private JPanel  panelTextfield;
	private JPanel  panelNiveau;
	private JPanel  panelBorder;
	private JPanel  panelChoixType;
	private JPanel  panelTextarea;
	private JPanel  panelValider;

	private JLabel  lblTypeQuestion;
	private JLabel  lblFichier;

	private JButton btnValider;
	private JButton btnAjouter;
	private JButton btnExplication;
	private JButton btnInsererFichier;
	private JButton btnAssoc;
	private JButton btnElim;
	private JButton btnQCM;

	private JRadioButton rbTresFacile;
	private JRadioButton rbFacile;
	private JRadioButton rbMoyen;
	private JRadioButton rbDifficile;

	private ButtonGroup  btgDifficulte;

	private JScrollPane  spPanelLstReponse;

	private JTextField   txtTemps;
	private JTextField   txtPoints;

	private JEditorPane  epEnonceQuestion;

	private RTFEditorKit rtfEditor;

	public FrameCreationQuestion(Controleur ctrl, FrameQuestions frameQuestions, GrilleDonneesQuestions grilleDonneesQuestions, char typeQuestion, String enonce, String diffQuestion, String pts, String tps, String explication, String listeQuestion)
	{
		this.ctrl                   = ctrl;
		this.frameQuestions         = frameQuestions;
		this.grilleDonneesQuestions = grilleDonneesQuestions;

		this.modif = listeQuestion != null;

		if( typeQuestion != ' ')
		{
			this.typeQuestion = typeQuestion;
		}
		else
			this.typeQuestion  = 'Q';

		if(enonce != null )
			this.enonce = enonce;
		else
			this.enonce = null;

		if( diffQuestion != null )
		{
			for (Difficulte diff : Difficulte.values())
			{
				if (diffQuestion.equals(diff.name()))
					this.diffQuestion = diff;
			}
		}
		else
			this.diffQuestion  = Difficulte.TRES_FACILE;

		if( pts != null )
			this.nbPoints = Double.parseDouble(pts);
		else
			this.nbPoints = 0.0;

		if( tps != null )
			this.tps = Integer.parseInt(tps);
		else
			this.tps = 0;

		this.explication = explication;

		this.setTitle("Création d'une question");
		this.setSize(1400, 900);
		this.setLocationRelativeTo(this);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setLayout(new BorderLayout(20, 0));

		this.cheminDossierImport = Paths.get("./src/prominfo/ressources/import/");

		this.frameExplication    = new FrameAjoutExplication();
		this.btgDifficulte       = new ButtonGroup();
		this.rtfEditor           = new RTFEditorKit();

		//partie principal
		this.panelChoixNRD     = new JPanel(new GridLayout(2, 3, 20, 0));
		this.panelTextfield    = new JPanel(new GridLayout(2, 2, 20, 0));
		this.panelValider      = new JPanel(new FlowLayout(FlowLayout.LEFT));
		this.panelNiveau       = new JPanel(new GridLayout(1, 4, 5, 0));
		this.panelBorder       = new JPanel(new GridBagLayout());
		this.panelChoixType    = new JPanel(new GridLayout(1, 3, 2, 0));
		
		//partie question
		this.panelTextarea     = new JPanel(new GridLayout(3, 1));

		this.panelLstReponse   = new PanelLstReponse(ctrl, listeQuestion, this.typeQuestion);

		this.btnAjouter        = new JButton("Ajouter une réponse");
		this.btnExplication    = new JButton("Ajouter une explication");
		this.btnInsererFichier = new JButton("Inserer un fichier");
		this.btnValider        = new JButton("Enregistrer la question");

		this.rbTresFacile      = new JRadioButton("Très Facile");
		this.rbFacile          = new JRadioButton("Facile");
		this.rbMoyen           = new JRadioButton("Moyen");
		this.rbDifficile       = new JRadioButton("Difficile");

		this.btnAssoc          = new JButton("Association");
		this.btnElim           = new JButton("Elimination");
		this.btnQCM            = new JButton("QCM");

		this.lblTypeQuestion   = new JLabel();
		this.lblFichier        = new JLabel();

		this.epEnonceQuestion  = new JEditorPane();
		
		this.epEnonceQuestion.setContentType("text/rtf");
		this.epEnonceQuestion.setEditorKit(this.rtfEditor);
		

		this.txtPoints = new JTextField(4);
		this.txtPoints.setText(this.nbPoints <= 0 ? "" : String.valueOf(this.nbPoints));
		this.txtTemps  = new JTextField(5);
		this.txtTemps.setText(this.tps <= 0 ? "" : "00:" +String.valueOf(this.tps));

		this.panelStyleEditor = new PanelStyleEditor(this, this.enonce);

		//implementation panel textearea
		JPanel panelText = new JPanel(new BorderLayout());
		panelText.add(this.epEnonceQuestion, BorderLayout.CENTER);
		this.panelTextarea.add(this.lblTypeQuestion);
		this.panelTextarea.add(new JScrollPane(panelText));
		this.panelTextarea.add(this.panelStyleEditor);

		// implémentation panel N, R et D;
		this.btgDifficulte.add(this.rbTresFacile);
		this.btgDifficulte.add(this.rbFacile);
		this.btgDifficulte.add(this.rbMoyen);
		this.btgDifficulte.add(this.rbDifficile);

		this.panelNiveau.add(this.rbTresFacile);
		this.panelNiveau.add(this.rbFacile);
		this.panelNiveau.add(this.rbMoyen);
		this.panelNiveau.add(this.rbDifficile);

		this.panelChoixNRD.add(new JLabel("Ressource :", JLabel.LEFT));
		this.panelChoixNRD.add(new JLabel("Notion : ", JLabel.LEFT));
		this.panelChoixNRD.add(new JLabel("Difficulté : ", JLabel.CENTER));

		this.panelChoixNRD.add(new JLabel("R" + this.frameQuestions.getFrameNotions().getCodeRess().substring(0, 1) + "." + this.frameQuestions.getFrameNotions().getCodeRess().substring(1, 3) + " " + this.frameQuestions.getCtrl().getRessourceParCode(Integer.parseInt(this.frameQuestions.getFrameNotions().getCodeRess()))));
		this.panelChoixNRD.add(new JLabel(this.frameQuestions.getNotion()));
		this.panelChoixNRD.add(this.panelNiveau);

		// implémentation panel field;
		this.panelTextfield.add(new JLabel("Nombre de points : ", JLabel.LEFT));
		this.panelTextfield.add(new JLabel("Temps de réponse (min:sec) : ", JLabel.LEFT));
		
		this.panelTextfield.add(this.txtPoints);
		this.panelTextfield.add(this.txtTemps);
		this.panelTextfield.add(this.panelChoixType);

		//implémentation panel choix type
		this.panelChoixType.add(this.btnAssoc);
		this.panelChoixType.add(this.btnElim);
		this.panelChoixType.add(this.btnQCM);

		// implémentation panel valider;
		this.panelValider.add(this.btnAjouter);
		this.panelValider.add(this.btnExplication);
		this.panelValider.add(this.btnInsererFichier);
		this.panelValider.add(this.lblFichier);

		this.panelValider.add(this.btnValider);
		// implémentation panel border;

		/*----------------------------------------*/

		GridBagConstraints c   = new GridBagConstraints();

		this.spPanelLstReponse = new JScrollPane(this.panelLstReponse);

		this.spPanelLstReponse.setPreferredSize(new Dimension(1200, 350));

		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1;
		c.weighty = 0.05;
		c.gridy = 0;
		this.panelBorder.add(this.panelChoixNRD, c);

		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1;
		c.weighty = 0.1;
		c.gridy = 1;
		this.panelBorder.add(this.panelTextfield, c);

		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1;
		c.weighty = 0.05;
		c.gridy = 2;
		this.panelBorder.add(this.panelChoixType, c);

		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1;
		c.weighty = 0.2;
		c.gridy = 3;
		this.panelBorder.add(this.panelTextarea, c);

		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1;
		c.weighty = 0.55;
		c.gridy = 4;
		this.panelBorder.add(spPanelLstReponse, c);
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1;
		c.weighty = 0.05;
		c.gridy = 5;
		this.panelBorder.add(this.panelValider, c);

		this.add(new JLabel(), BorderLayout.WEST);
		this.add(this.panelBorder, BorderLayout.CENTER);
		this.add(new JLabel(), BorderLayout.EAST);

		/*----------------------------------------*/

		this.rbTresFacile.addActionListener(this);
		this.rbFacile.addActionListener(this);
		this.rbMoyen.addActionListener(this);
		this.rbDifficile.addActionListener(this);

		this.btnValider.addActionListener(this);
		this.btnAjouter.addActionListener(this);
		this.btnExplication.addActionListener(this);
		this.btnInsererFichier.addActionListener(this);

		this.btnQCM.addActionListener(this);
		this.btnAssoc.addActionListener(this);
		this.btnElim.addActionListener(this);

		this.btnValider.addMouseListener(this);
		this.btnAjouter.addMouseListener(this);
		this.btnExplication.addMouseListener(this);
		this.btnInsererFichier.addMouseListener(this);

		this.btnQCM.addMouseListener(this);
		this.btnAssoc.addMouseListener(this);
		this.btnElim.addMouseListener(this);

		// Option
		if(this.diffQuestion == Difficulte.TRES_FACILE)
		{
			this.rbTresFacile.setSelected(true);
		}
		if(this.diffQuestion == Difficulte.FACILE)
		{
			this.rbFacile.setSelected(true);
		}
		if(this.diffQuestion == Difficulte.MOYEN)
		{
			this.rbMoyen.setSelected(true);
		}
		if(this.diffQuestion == Difficulte.DIFFICILE)
		{
			this.rbDifficile.setSelected(true);
		}

		switch (this.typeQuestion) 
		{
			case 'Q' -> {this.lblTypeQuestion.setText("Question : QCM");}
			case 'E' -> {this.lblTypeQuestion.setText("Question : Elimination");}
			case 'A' -> {this.lblTypeQuestion.setText("Question : Association");}
		}

		if(listeQuestion != null)
		{
			this.btnAjouter.setEnabled(false);
		}

		this.setVisible(true);
	}

	public GrilleDonneesQuestions getGrilleDonneesQuestions()
	{
		return this.grilleDonneesQuestions;
	}

	public char getTypeQuestion()
	{
		return this.typeQuestion;
	}

	public File getSelectedFile()
	{
		return this.fichierSelectionne;
	}

	public JEditorPane getTexteAreaEditor()
	{
		return this.epEnonceQuestion;
	}

	public void actionPerformed(ActionEvent e)
	{
		//bouton Ajouter
		if(e.getSource() == this.btnAjouter)
		{
			this.panelLstReponse.addPanel();
		}

		//bouton Explication
		if(e.getSource() == this.btnExplication)
		{
			this.frameExplication.setVisible(true);
		}

		//bouton gestion fichiers externe
		if(e.getSource() == this.btnInsererFichier)
		{
			JFileChooser fileChooser = new JFileChooser();
			int returnValue = fileChooser.showOpenDialog(null);
			if (returnValue == JFileChooser.APPROVE_OPTION)
			{
				this.fichierSelectionne = fileChooser.getSelectedFile();
				this.lblFichier.setText(this.fichierSelectionne.getName());

				try
				{
					Files.copy(fichierSelectionne.toPath(), (new File(this.cheminDossierImport + "\\" + fichierSelectionne.getName())).toPath(), StandardCopyOption.REPLACE_EXISTING);
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}

		//selecion difficulte
		if (e.getSource() == this.rbTresFacile)
		{
			this.diffQuestion = Difficulte.TRES_FACILE;
		}
		if (e.getSource() == this.rbFacile)
		{
			this.diffQuestion = Difficulte.FACILE;
		}
		if (e.getSource() == this.rbMoyen)
		{
			this.diffQuestion = Difficulte.MOYEN;
		}
		if (e.getSource() == this.rbDifficile)
		{
			this.diffQuestion = Difficulte.DIFFICILE;
		}

		//selection QCM
		if (e.getSource() == this.btnQCM)
		{
			this.panelLstReponse.removeAll();
			this.panelLstReponse.clearLst();

			this.typeQuestion = 'Q';
			this.panelLstReponse.setTypeQuestion('Q');
			this.lblTypeQuestion.setText("Question : QCM");
			this.btnAjouter.setEnabled(true);
			this.panelLstReponse.addMultPanel();
		}

		//selection association
		if (e.getSource() == this.btnAssoc)
		{
			this.panelLstReponse.removeAll();
			this.panelLstReponse.clearLst();

			this.typeQuestion = 'A';
			this.panelLstReponse.setTypeQuestion('A');
			this.lblTypeQuestion.setText("Question : Association");
			this.btnAjouter.setEnabled(true);
			this.panelLstReponse.addMultPanel();
		}

		//selection elimination
		if (e.getSource() == this.btnElim)
		{
			this.panelLstReponse.removeAll();
			this.panelLstReponse.clearLst();

			this.typeQuestion = 'E';
			this.panelLstReponse.setTypeQuestion('E');
			this.lblTypeQuestion.setText("Question : Elimination");
			this.btnAjouter.setEnabled(true);
			this.panelLstReponse.addMultPanel();
		}

		//bouton Valider
		if (e.getSource() == this.btnValider)
		{
			try
			{
				// Vérifie si un champ est vide ou si le temps est invalide
				if ( this.epEnonceQuestion.getDocument().getText(0, this.epEnonceQuestion.getDocument().getLength()).isBlank() || this.diffQuestion == null
				||   this.txtPoints.getText().isBlank() || !this.txtPoints.getText().matches("\\d+(\\.\\d+)?")
				||   this.txtTemps.getText().isBlank())
				{
					JOptionPane.showMessageDialog(this, "Il manque des éléments à remplir");
					return;
				}

				// Traite le champ de temps au format "mm:ss"
				String[] timeParts = this.txtTemps.getText().split(":");
				if (timeParts.length != 2 || !timeParts[0].matches("\\d+") || !timeParts[1].matches("\\d+") )
				{
					JOptionPane.showMessageDialog(this, "Le format du temps est invalide. Utilisez 'mm:ss'.");
					return;
				}

				int minutes = Integer.parseInt(timeParts[0]);
				int seconds = Integer.parseInt(timeParts[1]);
				int totalTimeInSeconds = minutes * 60 + seconds;
	
				// Vérifie que le temps total n'est pas égal à zéro ou en dessours de zéro.
				if (totalTimeInSeconds <= 0)
				{
					JOptionPane.showMessageDialog(this, "Le temps total ne peut pas être zéro.");
					return;
				}

				// Crée la nouvelle ligne à ajouter à la table de Questions.
				this.ressource = this.frameQuestions.getCtrl().getRessourceParCode(Integer.parseInt(this.frameQuestions.getFrameNotions().getCodeRess()));
				this.notion = this.ctrl.getNotionParNom(this.frameQuestions.getNotion());
				this.nbPoints = Double.parseDouble(this.txtPoints.getText());
				this.explication = ((FrameAjoutExplication)this.frameExplication).getFeedback();

				// Crée la question avec les informations traitées
				Question q = this.ctrl.creerQuestion
				(
					this.ressource,
					this.notion,
					this.typeQuestion,
					this.epEnonceQuestion.getDocument().getText(0, this.epEnonceQuestion.getDocument().getLength()),
					this.diffQuestion,
					this.nbPoints,
					totalTimeInSeconds,
					this.lblFichier.getText(),
					this.explication
				);

				if(this.panelStyleEditor.getImage() != null)
				{
					q.setNomMicroImage(this.panelStyleEditor.getImage());
				}

				// Crée le bon type de Réponse.
				HashMap<Reponse, Document> hashDocsRep = new HashMap<Reponse, Document>();

				switch (this.typeQuestion)
				{
					case 'Q' ->
					{
						int nbReponseVrai = 0;
						for (JPanel panel : this.panelLstReponse.getListPanels())
						{
							ReponseQCM repCM = ((ReponseQCM)panel);
							if( repCM.getBonneRep() == true)
								nbReponseVrai++;

							Rcm rep = q.creerReponse(repCM.getTexteAreaEditor().getDocument().getText(0, repCM.getTexteAreaEditor().getDocument().getLength()), repCM.getBonneRep());
							hashDocsRep.put(rep, repCM.getTexteAreaEditor().getDocument());

							if(repCM.getImage() != null)
							{
								rep.setNomMicroImage(repCM.getImage());
							}
						}

						if(nbReponseVrai <= 0)
						{
							JOptionPane.showMessageDialog(this, "Veuillez entrer au moins une bonne réponse.");
							this.ctrl.supprimerQuestion(this.ressource, this.notion, q);
							return;
						}
					}
					case 'E' ->
					{
						boolean uneReponseVrai = false;
						for (JPanel panel : this.panelLstReponse.getListPanels())
						{
							int ordre = 0;
							ReponseElimination repElim = ((ReponseElimination)panel);

							if(repElim.getOrdre() == -1)
							{
								JOptionPane.showMessageDialog(this, "Veuillez remplir correctement l'ordre d'élimination des réponses.");
								this.ctrl.supprimerQuestion(this.ressource, this.notion, q);
								return;
							}

							if(repElim.getNbPointsEnMoins() == -1)
							{
								JOptionPane.showMessageDialog(this, "Veuillez remplir correctement les points perdus des réponses.");
								this.ctrl.supprimerQuestion(this.ressource, this.notion, q);
								return;
							}

							if( repElim.getBonneRep() == true || repElim.getOrdre() == 0)
							{
								if(uneReponseVrai == true)
								{
									JOptionPane.showMessageDialog(this, "Veuillez entrer une seule bonne réponse.");
									this.ctrl.supprimerQuestion(this.ressource, this.notion, q);
									return;
								}
								uneReponseVrai = true;
							}

							if (repElim.getOrdre() != 0)
								ordre = this.panelLstReponse.getListPanels().size() - repElim.getOrdre() - 1;
							
							RElim rep = q.creerReponse(repElim.getTexteAreaEditor().getDocument().getText(0, repElim.getTexteAreaEditor().getDocument().getLength()), ordre, repElim.getNbPointsEnMoins());
							hashDocsRep.put(rep, repElim.getTexteAreaEditor().getDocument());

							if(repElim.getImage() != null)
							{
								rep.setNomMicroImage(repElim.getImage());
							}
						}

						if (uneReponseVrai != true)
						{
							JOptionPane.showMessageDialog(this, "Veuillez entrer une seule bonne réponse.");
							this.ctrl.supprimerQuestion(this.ressource, this.notion, q);
							return;
						}
					}
					case 'A' ->
					{
						int idRepAsso = 0 ;
						for (JPanel panel : this.panelLstReponse.getListPanels())
						{
							ReponseAssociation repAsso = ((ReponseAssociation)panel);
							RAsso rep1 = q.creerReponse(repAsso.getEditorPane1().getDocument().getText(0, repAsso.getEditorPane1().getDocument().getLength()), idRepAsso, "");
							RAsso rep2 = q.creerReponse(repAsso.getEditorPane2().getDocument().getText(0, repAsso.getEditorPane2().getDocument().getLength()), idRepAsso, "");
							hashDocsRep.put(rep1, repAsso.getEditorPane1().getDocument());
							hashDocsRep.put(rep2, repAsso.getEditorPane2().getDocument());

							if(repAsso.getImage1() != null)
							{
								rep1.setNomMicroImage(repAsso.getImage1());
							}

							if(repAsso.getImage2() != null)
							{
								rep2.setNomMicroImage(repAsso.getImage2());
							}

							idRepAsso++;
						}
					}
				}

				// Ajoute la question à la table de Questions
				this.ctrl.ecrireQuestions("./src/prominfo/data/" +  this.ressource.getCode() + "_" + this.ressource.getNom() + "/" + this.notion.getNom(), q, this.epEnonceQuestion.getDocument(), hashDocsRep);
				if(this.modif)
				{
					this.ctrl.supprimerQuestion(ressource, notion, this.ctrl.getQuestionParEnonce(enonce));
				}
				this.getGrilleDonneesQuestions().majGrille();

				JOptionPane.showMessageDialog(this, "Votre question est créée !");
				this.dispose();
			}

			catch(Exception exp) { exp.printStackTrace(); }
		}
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnAjouter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnExplication.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnInsererFichier.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnValider.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

		this.btnAssoc.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnElim.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnQCM.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnAjouter.setCursor(Cursor.getDefaultCursor());
		this.btnAssoc.setCursor(Cursor.getDefaultCursor());
		this.btnElim.setCursor(Cursor.getDefaultCursor());
		this.btnQCM.setCursor(Cursor.getDefaultCursor());

		this.btnExplication.setCursor(Cursor.getDefaultCursor());
		this.btnInsererFichier.setCursor(Cursor.getDefaultCursor());
		this.btnValider.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}
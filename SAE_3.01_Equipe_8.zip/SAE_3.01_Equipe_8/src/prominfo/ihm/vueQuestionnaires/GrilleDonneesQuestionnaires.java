package prominfo.ihm.vueQuestionnaires;

import prominfo.Controleur;

import prominfo.ihm.vueUtil.GrilleDonneesModel;
import prominfo.ihm.vueUtil.MultiButtonEditor;
import prominfo.ihm.vueUtil.MultiButtonRenderer;

import java.awt.Cursor;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import java.io.File;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JFileChooser;

import javax.swing.table.DefaultTableModel;

public class GrilleDonneesQuestionnaires extends GrilleDonneesModel implements MouseListener
{
	private Controleur ctrl;

	private String[]   tabEntetes;
	private Object[][] tabDonnees;

	private int indexEnonce;

	private boolean fcOuvert;

	public GrilleDonneesQuestionnaires(Controleur ctrl)
	{
		this.ctrl = ctrl;

		this.tblGrille = new JTable(this);
		this.majGrille();
	}

	public void majGrille()
	{
		this.fcOuvert = false;
		String[][] tabQuestionnaires = this.ctrl.getStringQuestionnaires();

		this.setTabEntetes(new String[] { "Titre", "Ressource", "Notions", "Nombre de Questions", "Chronométré", "Actions" });
		this.tabEntetes  = this.getTabEntetes();
		this.indexEnonce = this.getIntColumn("Titre");

		this.setTabDonnees(new Object[tabQuestionnaires.length][this.tabEntetes.length]);
		this.tabDonnees = this.getTabDonnees();

		for (int i = 0; i < tabQuestionnaires.length; i++)
		{
			this.tabDonnees[i][0] = tabQuestionnaires[i][0];
			this.tabDonnees[i][1] = tabQuestionnaires[i][1];
			this.tabDonnees[i][2] = tabQuestionnaires[i][2];
			this.tabDonnees[i][3] = tabQuestionnaires[i][3];

			if (Boolean.parseBoolean(tabQuestionnaires[i][4]))
			{
				this.tabDonnees[i][4] = "Oui";
			}
			else
			{
				this.tabDonnees[i][4] = "Non";
			}

			this.tabDonnees[i][5] = "Actions";
		}

		this.tblGrille.setModel(new DefaultTableModel(this.tabDonnees, this.tabEntetes));
		this.tblGrille.getColumn("Actions").setCellRenderer(new MultiButtonRenderer());
		this.tblGrille.getColumn("Actions").setCellEditor(new MultiButtonEditor(this));
		this.tblGrille.setRowHeight(40);

		this.fireTableDataChanged();
		for (MouseListener listener : this.tblGrille.getMouseListeners()) {
			if (listener == this) {
				return;
			}
		}
		this.tblGrille.addMouseListener(this);
	}

	@Override
	public void supprimer(int ligne)
	{
		String titreQs = (String)this.tabDonnees[ligne][0];
		this.ctrl.supprimerQuestionnaire(titreQs);
		this.majGrille();
	}

	public void modifier(int ligne)
	{
		new FrameCreationQuestionnaire(this.ctrl, this, this.tabDonnees[ligne][0] + "",this.tabDonnees[ligne][1] + "", this.tabDonnees[ligne][4] + "", this.ctrl.getParametresQuestionnaire(this.tabDonnees[ligne][0] + ""));
	}

	public boolean isCellEditable(int row, int col)
	{
		for (int cpt = 0; cpt < this.tabEntetes.length; cpt++)
		{
			if (this.tabEntetes[cpt].equals("Actions"))
			{
				return col == cpt;
			}
		}

		return false;
	}

	public int getIndexEnonce()
	{
		return this.indexEnonce;
	}

	public void mouseEntered(MouseEvent e)
	{
		this.tblGrille.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.tblGrille.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked(MouseEvent e)
	{
		if (e.getClickCount() == 1)
		{
			int col = this.tblGrille.columnAtPoint(e.getPoint());
			int row = this.tblGrille.rowAtPoint(e.getPoint());

			if (col != this.getIntColumn("Actions"))
			{
				if (col != this.getTable().getColumnCount() - 1)
				{

					if (this.fcOuvert) 
					{
						return;
					}
					this.fcOuvert = true;
					try
					{
						

						String titreQs = "" + this.tabDonnees[row][0];

						JFileChooser fileChooser = new JFileChooser();
						fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
						fileChooser.setDialogTitle("Sélectionner l'emplacement du questionnaire");

						int result = fileChooser.showOpenDialog(null);
						if (result == JFileChooser.APPROVE_OPTION)
						{
							File selectedFile = fileChooser.getSelectedFile();

							int confirmation = JOptionPane.showConfirmDialog
							(
								null,
								"Générer le questionnaire \"" + titreQs + "\" dans " + selectedFile.getAbsolutePath() + " ?",
								"Génération de questionnaire",
								JOptionPane.YES_NO_OPTION
							);

							if (confirmation == JOptionPane.YES_OPTION)
							{
								if( !this.ctrl.genererQuestionnaire(selectedFile.getAbsolutePath() + "/" + titreQs))
								{
									JOptionPane.showMessageDialog
									(
										null,
										"Erreur lors de la génération du questionnaire \"" + titreQs + "\"",
										"Erreur",
										JOptionPane.ERROR_MESSAGE
									);
								}

								JOptionPane.showMessageDialog
								(
									null,
									"Questionnaire \"" + titreQs + "\" généré avec succès dans :\n" + selectedFile.getAbsolutePath() + "\n Lien copié dans le presse papiers", 
									"Succès",
									JOptionPane.INFORMATION_MESSAGE
								);
							}
						}
					}
					finally
					{
						this.fcOuvert = false;
					}
				}
			}
		}
	}

	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}

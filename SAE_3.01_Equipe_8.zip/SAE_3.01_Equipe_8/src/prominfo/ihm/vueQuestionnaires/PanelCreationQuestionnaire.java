package prominfo.ihm.vueQuestionnaires;

import java.awt.GridLayout;
import java.awt.Cursor;

import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JOptionPane;

public class PanelCreationQuestionnaire extends JPanel implements ActionListener, MouseListener
{
	private FrameCreationQuestionnaire frameCreationQuestionnaire;

	private JPanel panelTitre;
	private JPanel panelHaut;
	private JPanel panelChrono;
	private JPanel panelRadio;
	private JPanel panelBas;

	private JButton btnAnnuler;
	private JButton btnSuivant;

	private JRadioButton rbOui;
	private JRadioButton rbNon;

	private ButtonGroup btgChrono;

	private JTextField txtTitre;

	private JComboBox<String> cbRessources;

	private String[][] tabParamQuestionnaire = null;

	private String titre = "";

	public PanelCreationQuestionnaire(FrameCreationQuestionnaire frameCreationQuestionnaire)
	{
		this.frameCreationQuestionnaire = frameCreationQuestionnaire;

		this.setLayout(new GridLayout(7, 1));

		/* ------------------------ */
		/*  Création des composants */
		/* ------------------------ */

		this.panelTitre  = new JPanel(new GridLayout(1, 3));
		this.panelHaut   = new JPanel(new GridLayout(1, 5));
		this.panelChrono = new JPanel(new GridLayout(1, 1));
		this.panelRadio  = new JPanel(new GridLayout(2, 1));
		this.panelBas    = new JPanel(new GridLayout(1, 5));

		this.cbRessources = new JComboBox<>();

		for (int i = 0; i < this.frameCreationQuestionnaire.getCtrl().getNomsRessources().length; i++)
		{
			this.cbRessources.addItem(this.frameCreationQuestionnaire.getCtrl().getNomsRessources()[i]);
		}

		this.txtTitre = new JTextField(30);

		this.rbOui = new JRadioButton("Oui");
		this.rbNon = new JRadioButton("Non");

		this.btgChrono   = new ButtonGroup();

		this.btnAnnuler = new JButton("Annuler");
		this.btnSuivant = new JButton("Suivant");

		/* ------------------------------ */
		/*  Positionnement des composants */
		/* ------------------------------ */

		this.btgChrono.add(this.rbOui);
		this.btgChrono.add(this.rbNon);

		this.panelRadio.add(this.rbOui);
		this.panelRadio.add(this.rbNon);

		this.panelChrono.add(new JLabel(new ImageIcon("./src/prominfo/ressources/images/chronometre.png"), JLabel.CENTER));
		this.panelChrono.add(this.panelRadio);

		this.panelTitre.add(new JLabel("Titre : ", JLabel.RIGHT));
		this.panelTitre.add(this.txtTitre);
		this.panelTitre.add(new JLabel());

		this.panelHaut.add(new JLabel("Ressource : ", JLabel.RIGHT));
		this.panelHaut.add(this.cbRessources);
		this.panelHaut.add(new JLabel());
		this.panelHaut.add(this.panelChrono);
		this.panelHaut.add(new JLabel());

		this.panelBas.add(new JLabel());
		this.panelBas.add(this.btnAnnuler);
		this.panelBas.add(new JLabel());
		this.panelBas.add(this.btnSuivant);
		this.panelBas.add(new JLabel());

		this.add(new JLabel());
		this.add(this.panelTitre);
		this.add(new JLabel());
		this.add(this.panelHaut);
		this.add(new JLabel());
		this.add(this.panelBas);
		this.add(new JLabel());

		/* -------------------------- */
		/*  Activation des composants */
		/* -------------------------- */

		this.rbOui.setActionCommand("true");
		this.rbNon.setActionCommand("false");
		this.btnAnnuler.addActionListener(this);
		this.btnSuivant.addActionListener(this);

		this.btnAnnuler.addMouseListener(this);
		this.btnSuivant.addMouseListener(this);

		this.setVisible(true);
	}

	public PanelCreationQuestionnaire(FrameCreationQuestionnaire frameCreationQuestionnaire, String titre, String nomRessource, String estChrono, String[][] tabParamQuestionnaire)
	{
		this.frameCreationQuestionnaire = frameCreationQuestionnaire;
		this.tabParamQuestionnaire 		= tabParamQuestionnaire;
		this.titre						= titre;

		this.setLayout(new GridLayout(7, 1));

		/* ------------------------ */
		/*  Création des composants */
		/* ------------------------ */

		this.panelTitre  = new JPanel(new GridLayout(1, 3));
		this.panelHaut   = new JPanel(new GridLayout(1, 5));
		this.panelChrono = new JPanel(new GridLayout(1, 1));
		this.panelRadio  = new JPanel(new GridLayout(2, 1));
		this.panelBas    = new JPanel(new GridLayout(1, 5));

		this.cbRessources = new JComboBox<>();

		for (int i = 0; i < this.frameCreationQuestionnaire.getCtrl().getNomsRessources().length; i++)
		{
			this.cbRessources.addItem(this.frameCreationQuestionnaire.getCtrl().getNomsRessources()[i]);
		}
		this.cbRessources.setSelectedItem(nomRessource);

		this.txtTitre = new JTextField(30);
		this.txtTitre.setText(titre);

		this.rbOui = new JRadioButton("Oui");
		this.rbNon = new JRadioButton("Non");

		this.btgChrono   = new ButtonGroup();

		this.btnAnnuler = new JButton("Annuler");
		this.btnSuivant = new JButton("Suivant");

		/* ------------------------------ */
		/*  Positionnement des composants */
		/* ------------------------------ */

		this.btgChrono.add(this.rbOui);
		this.btgChrono.add(this.rbNon);
		this.rbOui.setSelected(estChrono.equals("Oui"));
		this.rbNon.setSelected(estChrono.equals("Non"));

		this.panelRadio.add(this.rbOui);
		this.panelRadio.add(this.rbNon);

		this.panelChrono.add(new JLabel(new ImageIcon("./src/prominfo/ressources/images/chronometre.png"), JLabel.CENTER));
		this.panelChrono.add(this.panelRadio);

		this.panelTitre.add(new JLabel("Titre : ", JLabel.RIGHT));
		this.panelTitre.add(this.txtTitre);
		this.panelTitre.add(new JLabel());

		this.panelHaut.add(new JLabel("Ressource : ", JLabel.RIGHT));
		this.panelHaut.add(this.cbRessources);
		this.panelHaut.add(new JLabel());
		this.panelHaut.add(this.panelChrono);
		this.panelHaut.add(new JLabel());

		this.panelBas.add(new JLabel());
		this.panelBas.add(this.btnAnnuler);
		this.panelBas.add(new JLabel());
		this.panelBas.add(this.btnSuivant);
		this.panelBas.add(new JLabel());

		this.add(new JLabel());
		this.add(this.panelTitre);
		this.add(new JLabel());
		this.add(this.panelHaut);
		this.add(new JLabel());
		this.add(this.panelBas);
		this.add(new JLabel());

		/* -------------------------- */
		/*  Activation des composants */
		/* -------------------------- */

		this.rbOui.setActionCommand("true");
		this.rbNon.setActionCommand("false");
		this.btnAnnuler.addActionListener(this);
		this.btnSuivant.addActionListener(this);

		this.btnAnnuler.addMouseListener(this);
		this.btnSuivant.addMouseListener(this);

		this.setVisible(true);
	}

	public boolean titreEstValide()
	{
		char[] tabCharsInterdits = new char[] { '/', '\\', ':', '*', '?', '"', '<', '>', '|' };

		for (char c : tabCharsInterdits)
		{
			if (this.txtTitre.getText().contains(String.valueOf(c)))
			{
				return false;
			}
		}
		return true;
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == this.btnAnnuler)
		{
			if (this.frameCreationQuestionnaire != null)
			{
				this.frameCreationQuestionnaire.dispose();
			}
		}

		if (e.getSource() == this.btnSuivant)
		{
			if (this.txtTitre.getText().isBlank())
			{
				JOptionPane.showMessageDialog(this, "Veuillez indiquer un titre");
				return;
			}
			if (!this.txtTitre.getText().equals(this.titre) && !this.frameCreationQuestionnaire.getCtrl().estUniqueQuestionnaire(this.txtTitre.getText()) )
			{
				JOptionPane.showMessageDialog(this, "Le titre doit être unique");
				return;
			}
			
			if (!this.titreEstValide())
			{
				JOptionPane.showMessageDialog(this, "Le titre ne doit pas contenir les caractères suivants : / \\ : * ? \" < > |");
				return;
			}

			if (btgChrono.getSelection() == null)
			{
				JOptionPane.showMessageDialog(this, "Veuillez indiquer si l'évaluation est chronométrée");
				return;
			}
			if (this.cbRessources.getSelectedItem() == null)
			{
				JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ressource");
				return;
			}

			int codeRessource = Integer.parseInt(this.frameCreationQuestionnaire.getCtrl().getCodesRessources()[this.cbRessources.getSelectedIndex()]);
			boolean chrono = Boolean.parseBoolean(btgChrono.getSelection().getActionCommand());

			new FrameCreationQuestionnaire2(this.frameCreationQuestionnaire.getCtrl(), this.frameCreationQuestionnaire.getAncienTitre(), this.txtTitre.getText(), codeRessource, chrono, this.frameCreationQuestionnaire.getGrilleDonneesQuestionnaires(), this.tabParamQuestionnaire);
			this.frameCreationQuestionnaire.dispose();
		}
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnAnnuler.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnSuivant.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnAnnuler.setCursor(Cursor.getDefaultCursor());
		this.btnSuivant.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}
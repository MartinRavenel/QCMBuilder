package prominfo.ihm.vueQuestionnaires;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class PanelQuestionnaires extends JPanel implements ActionListener, MouseListener
{
	private FrameQuestionnaires frameQuestionnaires;

	private GrilleDonneesQuestionnaires grilleDonneesQuestionnaires;

	private JPanel panelTitre;
	private JPanel panelGrille;
	private JPanel panelBouton;

	private GridBagConstraints gbcTableau;
	private GridBagConstraints gbcBouton;
	private GridBagConstraints gbcTitre;

	private JButton btnCreerQuestionnaire;
	private JButton btnRetour;

	public PanelQuestionnaires(FrameQuestionnaires frameQuestionnaires)
	{
		this.frameQuestionnaires = frameQuestionnaires;

		this.setLayout(new BorderLayout());

		/* ------------------------ */
		/*  Création des composants */
		/* ------------------------ */

		this.panelTitre  = new JPanel(new GridBagLayout());
		this.panelGrille = new JPanel(new GridBagLayout());
		this.panelBouton = new JPanel(new GridBagLayout());

		this.grilleDonneesQuestionnaires = new GrilleDonneesQuestionnaires(frameQuestionnaires.getCtrl());

		this.gbcTableau = new GridBagConstraints();
		this.gbcBouton  = new GridBagConstraints();
		this.gbcTitre   = new GridBagConstraints();

		this.gbcTitre.insets    = new Insets(25, 700, 0, 700);
		this.gbcTitre.fill      = GridBagConstraints.BOTH;

		this.gbcTitre.weightx   = 1.0;
		this.gbcTitre.weighty   = 1.0;

		this.gbcTableau.insets  = new Insets(25, 200, 50, 200);
		this.gbcTableau.fill    = GridBagConstraints.BOTH;

		this.gbcTableau.weightx = 1.0;
		this.gbcTableau.weighty = 1.0;

		this.gbcBouton.insets   = new Insets(0, 250, 50, 250);
		this.gbcBouton.fill     = GridBagConstraints.BOTH;

		this.gbcBouton.weightx  = 1.0;
		this.gbcBouton.weighty  = 1.0;

		this.btnCreerQuestionnaire = new JButton("Créer");
		this.btnCreerQuestionnaire.setPreferredSize(new Dimension(50, 50));

		this.btnRetour = new JButton("Retour");
		this.btnRetour.setPreferredSize(new Dimension(50, 50));

		/* ------------------------------ */
		/*  Positionnement des composants */
		/* ------------------------------ */

		this.panelTitre.add(new JLabel((new ImageIcon("./src/prominfo/ressources/images/questionnaires.png"))), gbcTitre, JLabel.CENTER);

		this.panelGrille.add(new JScrollPane(this.grilleDonneesQuestionnaires.getTable()), gbcTableau);

		this.panelBouton.add(this.btnRetour, gbcBouton);
		this.panelBouton.add(this.btnCreerQuestionnaire, gbcBouton);

		this.add(this.panelTitre , BorderLayout.NORTH );
		this.add(this.panelGrille, BorderLayout.CENTER);
		this.add(this.panelBouton, BorderLayout.SOUTH );

		/* -------------------------- */
		/*  Activation des composants */
		/* -------------------------- */

		this.btnCreerQuestionnaire.addActionListener(this);
		this.btnCreerQuestionnaire.addMouseListener(this);

		this.btnRetour.addActionListener(this);
		this.btnRetour.addMouseListener(this);
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == this.btnCreerQuestionnaire)
		{
			new FrameCreationQuestionnaire(this.frameQuestionnaires.getCtrl(), this.grilleDonneesQuestionnaires);
		}

		if (e.getSource() == this.btnRetour)
		{
			this.frameQuestionnaires.dispose();
		}
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnCreerQuestionnaire.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnRetour.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnCreerQuestionnaire.setCursor(Cursor.getDefaultCursor());
		this.btnRetour.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}
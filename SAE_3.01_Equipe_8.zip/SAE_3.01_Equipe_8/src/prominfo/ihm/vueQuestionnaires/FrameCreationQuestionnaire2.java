package prominfo.ihm.vueQuestionnaires;

import prominfo.Controleur;

import javax.swing.JFrame;

public class FrameCreationQuestionnaire2 extends JFrame
{
	private Controleur ctrl;

	private GrilleDonneesQuestionnaires grilleDonneesQuestionnaires;

	private PanelCreationQuestionnaire2 panelCreationQuestionnaire;

	private int codeRess;

	private String titre;
	private String ancienTitre;

	private boolean estChrono;

	public FrameCreationQuestionnaire2(Controleur ctrl, String ancienTitre, String titre, int codeRess, boolean estChrono, GrilleDonneesQuestionnaires grilleDonneesQuestionnaires, String[][] tabParamQuestionnaire)
	{
		this.ctrl      = ctrl;
		this.titre     = titre;
		this.codeRess  = codeRess;
		this.estChrono = estChrono;
		this.ancienTitre = ancienTitre;
		this.grilleDonneesQuestionnaires = grilleDonneesQuestionnaires;

		if (tabParamQuestionnaire == null)
		{
			this.setTitle("Création d'un questionnaire");
		}
		else
		{
			this.setTitle("Modification d'un questionnaire");
		}
		this.setSize(1170, 510);
		this.setLocationRelativeTo(panelCreationQuestionnaire);

		this.panelCreationQuestionnaire = new PanelCreationQuestionnaire2(this, tabParamQuestionnaire);

		this.add(this.panelCreationQuestionnaire);

		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		this.setVisible(true);
	}

	public Controleur getCtrl()
	{
		return this.ctrl;
	}

	public GrilleDonneesQuestionnaires getGrilleDonneesQuestionnaires()
	{
		return this.grilleDonneesQuestionnaires;
	}

	public String getTitre()
	{
		return this.titre;
	}

	public int getCodeRess()
	{
		return this.codeRess;
	}

	public boolean getEstChrono()
	{
		return this.estChrono;
	}

	public String getAncienTitre()
	{
		return this.ancienTitre;
	}
}
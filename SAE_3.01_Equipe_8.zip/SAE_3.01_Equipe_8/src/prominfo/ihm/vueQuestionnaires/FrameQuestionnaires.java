package prominfo.ihm.vueQuestionnaires;

import prominfo.Controleur;

import javax.swing.JFrame;

public class FrameQuestionnaires extends JFrame
{
	private Controleur ctrl;

	private PanelQuestionnaires panelQuestionnaires;

	public FrameQuestionnaires(Controleur ctrl)
	{
		this.ctrl = ctrl;

		this.setTitle("QCM Builder");
		this.setSize(1800, 900);
		this.setLocationRelativeTo(panelQuestionnaires);

		this.panelQuestionnaires = new PanelQuestionnaires(this);

		this.add(panelQuestionnaires);

		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		this.setVisible(true);
	}

	public Controleur getCtrl()
	{
		return this.ctrl;
	}
}
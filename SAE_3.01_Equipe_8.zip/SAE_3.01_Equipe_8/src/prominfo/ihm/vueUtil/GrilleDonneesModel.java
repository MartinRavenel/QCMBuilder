package prominfo.ihm.vueUtil;

import javax.swing.JTable;

import javax.swing.table.AbstractTableModel;

public class GrilleDonneesModel extends AbstractTableModel
{
	public static final int TAILLE_COLLONNE_ACTIONS = 129;

	protected JTable tblGrille;

	private String[]   tabEntetes;
	private Object[][] tabDonnees;

	public GrilleDonneesModel()
	{
		this.tabEntetes = new String[0];
		this.tabDonnees = new Object[0][this.tabEntetes.length];

		this.tblGrille  = new JTable(this);
	}

	public void supprimer(int ligne){}

	public void modifier(int ligne){}

	public JTable getTable()
	{
		return this.tblGrille;
	}

	public void setTable(JTable tblGrille)
	{
		this.tblGrille = tblGrille;
	}

	public void setTabEntetes(String[] tabEntetes)
	{
		this.tabEntetes = tabEntetes;
	}

	public String[] getTabEntetes()
	{
		return this.tabEntetes;
	}

	public void setTabDonnees(Object[][] tabDonnees)
	{
		this.tabDonnees = tabDonnees;
	}

	public Object[][] getTabDonnees()
	{
		return this.tabDonnees;
	}

	public int getIntColumn(String nomColonne)
	{
		for (int i = 0; i < this.tabEntetes.length; i++)
		{
			if (this.tabEntetes[i].equals(nomColonne))
			{
				return i;
			}
		}

		return -1;
	}

	public int getColumnCount()
	{
		return this.tabEntetes.length;
	}

	public int getRowCount()
	{
		return this.tabDonnees.length;
	}

	public String getColumnName(int col)
	{
		return this.tabEntetes[col];
	}

	public Object getValueAt(int row, int col)
	{
		return this.tabDonnees[row][col];
	}

	public void setValueAt(Object value, int row, int col)
	{
		if(row < 0 || row >= this.tabDonnees.length)
		{
			return;
		}

		this.tabDonnees[row][col] = value;
		this.fireTableCellUpdated(row, col);
	}

	public boolean isCellEditable(int row, int col)
	{
		for (int i = 0; i < this.tabEntetes.length; i++)
		{
			if (this.tabEntetes[i].equals("Actions"))
			{
				return col == i;
			}
		}

		return false;
	}

	public int getIndexEnonce()
	{
		return 0;
	}
}

package prominfo.ihm.vueRessources;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class PanelRessources extends JPanel implements ActionListener, MouseListener
{
	private FrameRessources frameRessources;

	private GrilleDonneesRessources grilleDonneesRessources;

	private JPanel panelTitre;
	private JPanel panelGrille;
	private JPanel panelBouton;

	private GridBagConstraints gbcTableau;
	private GridBagConstraints gbcBouton;
	private GridBagConstraints gbcTitre;

	private JButton btnAjouterRessource;
	private JButton btnRetour;

	public PanelRessources(FrameRessources frameRessources)
	{
		this.frameRessources = frameRessources;

		this.setLayout(new BorderLayout());

		/* ------------------------ */
		/*  Création des composants */
		/* ------------------------ */

		this.panelTitre  = new JPanel(new GridBagLayout());
		this.panelGrille = new JPanel(new GridBagLayout());
		this.panelBouton = new JPanel(new GridBagLayout());

		this.grilleDonneesRessources = new GrilleDonneesRessources(frameRessources.getCtrl(), this.frameRessources);

		this.gbcTableau = new GridBagConstraints();
		this.gbcBouton  = new GridBagConstraints();
		this.gbcTitre   = new GridBagConstraints();

		this.gbcTitre.insets    = new Insets(25, 100, 0, 100);
		this.gbcTitre.fill      = GridBagConstraints.BOTH;

		this.gbcTitre.weightx   = 1.0;
		this.gbcTitre.weighty   = 1.0;

		this.gbcTableau.insets  = new Insets(25, 200, 50, 200);
		this.gbcTableau.fill    = GridBagConstraints.BOTH;

		this.gbcTableau.weightx = 1.0;
		this.gbcTableau.weighty = 1.0;

		this.gbcBouton.insets   = new Insets(0, 250, 50, 250);
		this.gbcBouton.fill     = GridBagConstraints.BOTH;

		this.gbcBouton.weightx  = 1.0;
		this.gbcBouton.weighty  = 1.0;

		this.btnAjouterRessource = new JButton("Ajouter");
		this.btnAjouterRessource.setPreferredSize(new Dimension(50, 50));

		this.btnRetour = new JButton("Retour");
		this.btnRetour.setPreferredSize(new Dimension(50, 50));

		/* ------------------------------ */
		/*  Positionnement des composants */
		/* ------------------------------ */

		this.panelTitre.add(new JLabel((new ImageIcon("./src/prominfo/ressources/images/ressources.png"))), gbcTitre, JLabel.CENTER);

		this.panelGrille.add(new JScrollPane(this.grilleDonneesRessources.getTable()), gbcTableau);

		this.panelBouton.add(this.btnRetour, gbcBouton);
		this.panelBouton.add(this.btnAjouterRessource, gbcBouton);

		this.add(this.panelTitre , BorderLayout.NORTH );
		this.add(this.panelGrille, BorderLayout.CENTER);
		this.add(this.panelBouton, BorderLayout.SOUTH );

		/* -------------------------- */
		/*  Activation des composants */
		/* -------------------------- */

		this.btnAjouterRessource.addActionListener(this);
		this.btnRetour.addActionListener(this);

		this.btnAjouterRessource.addMouseListener(this);
		this.btnRetour.addMouseListener(this);
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == this.btnAjouterRessource)
		{
			new FrameCreationRessource(this.frameRessources.getCtrl(), this.grilleDonneesRessources);
		}

		if (e.getSource() == this.btnRetour)
		{
			this.frameRessources.dispose();
		}
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnAjouterRessource.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnRetour.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnAjouterRessource.setCursor(Cursor.getDefaultCursor());
		this.btnRetour.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}
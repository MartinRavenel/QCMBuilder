package prominfo.ihm.vueRessources;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.GridLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelCreationRessource extends JPanel implements ActionListener, MouseListener
{
	private FrameCreationRessource frameCreationRessource;

	private JPanel panelNom;
	private JPanel panelCode;
	private JPanel panelBouton;

	private JTextField txtCodeRes;
	private JTextField txtNomRes;

	private JButton btnValider;
	private JButton btnAnnuler;

	public PanelCreationRessource(FrameCreationRessource frameCreationRessource)
	{
		this.frameCreationRessource = frameCreationRessource;

		this.setLayout(new GridLayout(7, 1));

		/* ------------------------ */
		/*  Création des composants */
		/* ------------------------ */

		this.panelNom    = new JPanel (new GridLayout(1, 3));
		this.panelCode   = new JPanel (new GridLayout(1, 3));
		this.panelBouton = new JPanel (new GridLayout(1, 5));

		this.txtCodeRes  = new JTextField(15);
		this.txtCodeRes.setBackground(Color.WHITE);
		this.txtCodeRes.setEnabled(true);
		if (!this.frameCreationRessource.getCodeRessource().equals(""))
		{
			this.txtCodeRes.setText(this.frameCreationRessource.getCodeRessource());
		}

		this.txtNomRes   = new JTextField(15);
		this.txtNomRes.setBackground(Color.WHITE);
		this.txtNomRes.setEnabled(true);
		if (!this.frameCreationRessource.getNomRessource().equals(""))
		{
			this.txtNomRes.setText(this.frameCreationRessource.getNomRessource());
		}

		this.btnValider  = new JButton("Valider");
		this.btnAnnuler  = new JButton("Annuler");

		/* ------------------------------ */
		/*  Positionnement des composants */
		/* ------------------------------ */

		if (this.frameCreationRessource.getCodeRessource().equals(""))
		{
			this.panelNom.add(new JLabel("Code (101 -> R1.01) : ", JLabel.RIGHT));
		}
		else
		{
			this.panelNom.add(new JLabel("Nouveau code (101 -> R1.01) : ", JLabel.RIGHT));
		}
		
		this.panelNom.add(this.txtCodeRes);
		this.panelNom.add(new JLabel());
		
		if (this.frameCreationRessource.getCodeRessource().equals(""))
		{
			this.panelCode.add(new JLabel("Nom : ", JLabel.RIGHT));
		}
		else
		{
			this.panelCode.add(new JLabel("Nouveau nom : ", JLabel.RIGHT));
		}
		this.panelCode.add(this.txtNomRes);
		this.panelCode.add(new JLabel());

		this.panelBouton.add(new JLabel());
		this.panelBouton.add(this.btnAnnuler);
		this.panelBouton.add(new JLabel());
		this.panelBouton.add(this.btnValider);
		this.panelBouton.add(new JLabel());

		this.add(new JLabel());
		this.add(this.panelNom);
		this.add(new JLabel());
		this.add(this.panelCode);
		this.add(new JLabel());
		this.add(this.panelBouton);
		this.add(new JLabel());

		/* -------------------------- */
		/*  Activation des composants */
		/* -------------------------- */

		this.txtCodeRes.addActionListener(this);
		this.txtNomRes .addActionListener(this);

		this.btnValider.addActionListener(this);
		this.btnAnnuler.addActionListener(this);

		this.btnValider.addMouseListener(this);
		this.btnAnnuler.addMouseListener(this);
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == this.btnValider)
		{
			if (this.txtCodeRes.getText().isBlank() || this.txtNomRes.getText().isBlank() || !this.txtCodeRes.getText().matches("\\d+"))
			{
				JOptionPane.showMessageDialog(this, "Veuillez renseigner correctement toutes les informations", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
			else if (!this.frameCreationRessource.getCtrl().estUniqueRessource("" + this.txtCodeRes.getText()) && !this.frameCreationRessource.getCodeRessource().equals(this.txtCodeRes.getText()))
			{
				JOptionPane.showMessageDialog(this, "Le code de la ressource doit être unique", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
			else if (this.txtCodeRes.getText().length() != 3)
			{
				JOptionPane.showMessageDialog(this, "Veuillez renseigner un code de ressource de 3 chiffres seulement", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
			else if (this.txtCodeRes.getText().substring(0, 1).equals("0"))
			{
				JOptionPane.showMessageDialog(this, "Veuillez renseigner un code de ressource supérieur a 0 (> R0.99)", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
			else if (this.txtCodeRes.getText().substring(1, 3).equals("00"))
			{
				JOptionPane.showMessageDialog(this, "Veuillez renseigner un code de ressource ne se finissant pas par 00 (R1.00 --> R1.01)", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
			else
			{
				if (this.frameCreationRessource.getNomRessource().equals(""))
				{
					this.frameCreationRessource.getCtrl().creerRessource(Integer.parseInt(this.txtCodeRes.getText()), this.txtNomRes.getText());
					JOptionPane.showMessageDialog(this, "Ressource créée avec succès !", "Ressource " + this.txtNomRes.getText(), JOptionPane.PLAIN_MESSAGE);
				}
				else
				{
					this.frameCreationRessource.getCtrl().modifierRessource(this.frameCreationRessource.getCodeRessource(), this.txtCodeRes.getText(), this.txtNomRes.getText());
					JOptionPane.showMessageDialog(this, "Ressource modifiée avec succès !", "Ressource " + this.txtNomRes.getText(), JOptionPane.PLAIN_MESSAGE);
				}

				this.frameCreationRessource.getGrilleDonneesRessources().majGrille();
				this.frameCreationRessource.dispose();
			}
		}

		if (e.getSource() == this.btnAnnuler)
		{
			this.frameCreationRessource.dispose();
		}
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnValider.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnAnnuler.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnValider.setCursor(Cursor.getDefaultCursor());
		this.btnAnnuler.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}

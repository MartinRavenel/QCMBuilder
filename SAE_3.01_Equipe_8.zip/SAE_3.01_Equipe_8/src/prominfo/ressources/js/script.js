const ressourceElement = document.getElementById("ressource");
const titreElement = document.getElementById("titre");
const pieceJointeElmt = document.getElementById("piece-jointe");

const NotionQuesElement = document.getElementById("notion");
const questionElement = document.getElementById("question");
const nbPointsElement = document.getElementById("pts");
const feedbackElement = document.getElementById("feedback");

const answerButtons = document.getElementById("answer-buttons");
const association = document.getElementById("asso");
const timer = document.getElementById("demo");

let canva = null;
let interval = null;

const elimButton = document.getElementById("eliminer");
const nextButton = document.getElementById("next-btn");
const submitButton = document.getElementById("submit-btn");
const precButton = document.getElementById("prec-btn");
const feedbackBtn = document.getElementById("feedback-btn");
const closeFeedback = document.getElementById("closeFeedback");
const modal = document.getElementById("modal");

let currentQuestionIndex = 0;
let score = 0;
let nbRep = 0;
let nbBonneRep = 0;
let nbPoint = 0;
let lstRep = [];
let lstSubmitted = [];
let positions = [];
let lstAsso = [];

let buttonAsso = [];

let derniereAsso = null;

let qcm = false;
let elim = false;
let asso = false;
let fini = false;

function startQuiz() {
	currentQuestionIndex = 0;
	score = 0;
	lstSubmitted = []
	questions.forEach(any => { lstSubmitted.push(null); })
	fini = false;

	ressourceElement.innerHTML = "";
	showQuestion();
}

function showQuestion() {
	submitButton.innerHTML = "Valider";
	resetState();

	let currentQuestion = questions[currentQuestionIndex];
	let questionNo = currentQuestionIndex + 1;

	switch (currentQuestion.type) {
		case "QCM": qcm = true; break;
		case "Elimination": elim = true; break;
		case "Association": asso = true; break;
	}

	nbPoint = currentQuestion.nbPoint
	submitButton.disabled = false;
	NotionQuesElement.innerHTML = currentQuestion.notion;
	questionElement.innerHTML = "Question " + questionNo + "/" + questions.length + " : " + currentQuestion.question;

	if (!currentQuestion.feedback || currentQuestion.feedback == "") feedbackElement.innerHTML = "Pas de feedback pour cette question";
	else feedbackElement.innerHTML = currentQuestion.feedback;

	nbPointsElement.innerHTML = currentQuestion.type + '<span class="marge"/>' + nbPoint + ' pts<span class="marge"/>';
	switch (currentQuestion.difficulte) {
		case 0: nbPointsElement.innerHTML += '<span class="tf"/>Très Facile'; break;
		case 1: nbPointsElement.innerHTML += '<span class="facile"/>Facile'; break;
		case 2: nbPointsElement.innerHTML += '<span class="moyen"/>Moyen'; break;
		case 3: nbPointsElement.innerHTML += '<span class="difficile"/>Difficile'; break;
	};

	if (estChrono && !fini) {
		timer.innerHTML = currentQuestion.temps + " s";
		var countDownDate = currentQuestion.temps * 1000;
		interval = setInterval(function () {
			countDownDate -= 1000;
			timer.innerHTML = (countDownDate / 1000) + " s";
			if (countDownDate <= 0) {
				clearInterval(interval);
				submit();
				timer.innerHTML = "FINI";
			}
		}, 1000);
	}
	else if (fini) {
		if (lstSubmitted[currentQuestionIndex] == true) timer.innerHTML = '<span class="facile"/>Vous avez bien répondu à cette question';
		else if (lstSubmitted[currentQuestionIndex] == "nope" || lstSubmitted[currentQuestionIndex] == null) timer.innerHTML = '<span class="moyen"/>Vous n\'avez pas répondu à cette question';
		else timer.innerHTML = '<span class="difficile"/>Vous avez mal répondu à cette question';
	}
	else
		timer.innerHTML = "Temps estimé : " + currentQuestion.temps + " s";

	if (asso) answerAsso(currentQuestion);
	else answerAutre(currentQuestion);

	if (qcm && nbBonneRep > 1) nbPointsElement.innerHTML += '<br><span class="difficile"/> Plusieurs réponses possibles';
	else if (qcm) nbPointsElement.innerHTML += '<br><span class="difficile"/> Une seule réponse possible';

	precButton.addEventListener("click", handlePrec);

	timer.style.visibility = "visible";
	submitButton.style.visibility = "visible";
	precButton.style.visibility = "visible";
	nextButton.style.visibility = "visible";

	if (currentQuestionIndex == 0 || (estChrono && !fini))
		precButton.style.visibility = "hidden";

	if (currentQuestion.link != null) {
		pieceJointeElmt.href = currentQuestion.link;
		pieceJointeElmt.style.visibility = "visible";
	}

	if (elim)
		elimButton.style.visibility = "visible";

	if ((lstSubmitted[currentQuestionIndex] != null && asso) || (asso && fini))
		drawEnd();
	if (lstSubmitted[currentQuestionIndex] != null || fini)
		showAnswer();
}

function answerAutre(currentQuestion) {
	currentQuestion.answers.forEach(answer => {
		if (!positions.includes(answer.position)) {
			positions.push(answer.position);
			nbRep++;
		}
		let button = document.createElement("button");
		button.innerHTML = answer.text;
		button.classList.add("btn");
		answerButtons.appendChild(button);
		button.dataset.correct = answer.correct;
		button.dataset.position = answer.position;
		button.dataset.pointPerdus = answer.pointPerdus;
		if (answer.correct) nbBonneRep++;
		button.addEventListener("click", selectAnswer);
	})
}

function answerAsso(currentQuestion) {
	const column1 = document.createElement("div");
	canva = document.createElement("canvas");
	const column2 = document.createElement("div");

	association.appendChild(column1);
	association.appendChild(canva);
	association.appendChild(column2);

	column1.id = "asso-column1";
	column2.id = "asso-column2";
	canva.id = "canva";

	for (let i = 0; i < currentQuestion.answers.length; i++) {
		let answer = currentQuestion.answers[i];
		let input = document.createElement("div");
		input.id = "wow";
		input.innerHTML = answer.text;
		if (!positions.includes(answer.numero)) {
			lstAsso.push(null);
			positions.push(answer.numero);
			column1.appendChild(input);
			input.dataset.column = 1;
		}
		else {
			column2.appendChild(input);
			input.dataset.column = 2;
		}
		input.classList.add("input");
		input.dataset.numero = answer.numero;
		input.addEventListener("click", selectAsso);
		buttonAsso.push(input);
	}
	drawStart();
}

function drawAnswer() {
	canva.width = (association.getBoundingClientRect().right - association.getBoundingClientRect().left) / 3;
	canva.height = association.getBoundingClientRect().height;
	let ctx = canva.getContext("2d");
	ctx.clearRect(0, 0, canva.width, canva.height);

	buttonAsso.forEach(button => {
		let leDivLa = association.getBoundingClientRect();
		let rect = button.getBoundingClientRect();
		let y1 = ((rect.bottom + rect.top) / 2) - leDivLa.top;
		if (button.dataset.column == 1 && lstAsso[button.dataset.numero] != null) {
			rect = lstAsso[button.dataset.numero].getBoundingClientRect();
			let y2 = ((rect.bottom + rect.top) / 2) - leDivLa.top;

			ctx.beginPath();
			ctx.moveTo(20, y1);
			ctx.lineTo(canva.width - 20, y2);
			ctx.strokeStyle = "#b497dc";
			ctx.lineWidth = 5;
			ctx.stroke();

			ctx.beginPath();
			ctx.arc(20, y1, 3, 0, 2 * Math.PI);
			ctx.fillStyle = "black";
			ctx.fill();
		}
		else {
			ctx.beginPath();
			if (button.dataset.column == 1)
				ctx.arc(20, y1, 3, 0, 2 * Math.PI);
			else
				ctx.arc(canva.width - 20, y1, 3, 0, 2 * Math.PI);
			ctx.fillStyle = "black";
			ctx.fill();
		}
	})
}

function drawStart() {
	canva.width = (association.getBoundingClientRect().right - association.getBoundingClientRect().left) / 3;
	canva.height = association.getBoundingClientRect().height;
	let ctx = canva.getContext("2d");
	ctx.clearRect(0, 0, canva.width, canva.height);
	ctx.font = "20px Arial";
	ctx.fillText("Cliquez pour relier", 10, 80);
}

function drawEnd() {
	clearInterval(interval);
	let ctx = canva.getContext("2d");
	ctx.clearRect(0, 0, canva.width, canva.height);
	buttonAsso.forEach(button => {
		if (button.dataset.column == 2)
			lstAsso[button.dataset.numero] = button;
	})

	buttonAsso.forEach(button => {
		let leDivLa = association.getBoundingClientRect();
		let rect = button.getBoundingClientRect();
		let y1 = ((rect.bottom + rect.top) / 2) - leDivLa.top;
		if (button.dataset.column == 1) {
			rect = lstAsso[button.dataset.numero].getBoundingClientRect();
			let y2 = ((rect.bottom + rect.top) / 2) - leDivLa.top;

			ctx.beginPath();
			ctx.moveTo(20, y1);
			ctx.lineTo(canva.width - 20, y2);
			ctx.strokeStyle = "green";
			ctx.lineWidth = 5;
			ctx.stroke();

			ctx.beginPath();
			ctx.arc(20, y1, 3, 0, 2 * Math.PI);
			ctx.arc(canva.width - 20, y2, 3, 0, 2 * Math.PI);
			ctx.fillStyle = "black";
			ctx.fill();
		}
	})
}


function resetState() {
	nbRep = 0;
	nbBonneRep = 0;
	lstRep = [];
	positions = [];
	lstAsso = [];
	buttonAsso = [];

	qcm = false;
	elim = false;
	asso = false;

	document.getElementById("score").innerHTML = "score : " + score;
	document.getElementById("score").style.visibility = "visible";
	elimButton.style.visibility = "hidden";
	pieceJointeElmt.style.visibility = "hidden";
	feedbackBtn.style.visibility = "hidden";

	document.getElementById("result").innerHTML = "Feedback";

	while (answerButtons.firstChild)
		answerButtons.removeChild(answerButtons.firstChild);

	while (association.firstChild)
		association.removeChild(association.firstChild);
}

function submit() {
	if (lstSubmitted[currentQuestionIndex] != null) {
		modal.classList.add("open");
		return;
	}
	if (estChrono)
		clearInterval(interval);
	if (currentQuestionIndex == -1) {
		startQuiz();
		return;
	}
	if (lstRep[0] == null && currentQuestionIndex != questions.length && !asso) {
		document.getElementById("result").innerHTML = "<span class=\"difficile\"/>VOUS N'AVEZ PAS REPONDU";
		modal.classList.add("open");
		showAnswer();
		lstSubmitted[currentQuestionIndex] = "nope";
		return;
	}
	if (currentQuestionIndex >= questions.length) startQuiz();
	else {
		let bon = true;

		if (asso) bon = validationAsso();
		else {
			lstRep.forEach(rep => {
				if (rep.dataset.correct == "false") bon = false;
			});

			if ((lstRep.length != nbBonneRep) && qcm)
				bon = false;

			if (lstRep[0].dataset.position != 0 && elim)
				bon = false;
		}

		if (bon) {
			score += nbPoint;
			document.getElementById("result").innerHTML = "<span class=\"facile\"/>BONNE REPONSE";
		}
		else
			document.getElementById("result").innerHTML = "<span class=\"difficile\"/> 	MAUVAISE REPONSE";
		showAnswer();

		lstSubmitted[currentQuestionIndex] = bon;

		document.getElementById("score").innerHTML = "score : " + score;

		if (qcm)
			lstRep.forEach(rep => {
				if (rep.dataset.correct == "false") {
					rep.innerHTML = "x " + rep.innerHTML;
					rep.classList.add("incorrect");
				}
				else {
					rep.innerHTML = "✓ " + rep.innerHTML;
					rep.classList.add("correctSelected");
				}
			});
		if (asso) drawEnd()

		submitButton.innerHTML = "Feedback";
		modal.classList.add("open")
	}
}

function validationAsso() {
	for (let i = 0; i < lstAsso.length; i++) {
		if (lstAsso[i] == null) return false;
		if (lstAsso[i].dataset.numero != i) return false;
	}
	return true;
}

function selectAnswer(e) {
	let selectedBtn = e.target;
	while (selectedBtn.nodeName != "BUTTON")
		selectedBtn = selectedBtn.parentElement;
	console.log(selectedBtn.innerHTML);

	if (elim) {
		if (lstRep[0] == null) lstRep[0] = selectedBtn;
		lstRep[0].classList.remove("selected");
		lstRep[0] = selectedBtn;
		lstRep[0].classList.add("selected");
	}
	else if (lstRep.includes(selectedBtn)) {
		selectedBtn.classList.remove("selected");
		lstRep.splice(lstRep.indexOf(selectedBtn), 1);
	}
	else {
		lstRep.push(selectedBtn);
		selectedBtn.classList.add("selected");
	}
}

function selectAsso(e) {
	if (lstSubmitted[currentQuestionIndex] != null) return;
	let btnSelected = e.target;
	while (btnSelected.nodeName != "DIV")
		btnSelected = btnSelected.parentElement;
	if (derniereAsso == null)
		derniereAsso = btnSelected;
	else if (derniereAsso.dataset.column == btnSelected.dataset.column)
		derniereAsso = btnSelected;
	else {
		for (let index = 0; index < lstAsso.length; index++)
			if (lstAsso[index] == derniereAsso || lstAsso[index] == btnSelected)
				lstAsso[index] = null;

		if (btnSelected.dataset.column == 1)
			lstAsso[btnSelected.dataset.numero] = derniereAsso;
		else
			lstAsso[derniereAsso.dataset.numero] = btnSelected;

		derniereAsso = null;
	}
	drawAnswer();
}

function showAnswer() {
	clearInterval(interval);
	elimButton.style.visibility = "hidden";
	Array.from(answerButtons.children).forEach(button => {
		if ((qcm && button.dataset.correct == "true") || (elim && button.dataset.position == 0))
			button.classList.add("correct");
		else
			button.classList.remove("selected");

		button.disabled = true;
	});
	submitButton.innerHTML = "Feedback";
	feedbackBtn.style.visibility = "visible";
}

function showScore() {
	resetState();
	let totPoint = 0;
	fini = true;

	questions.forEach(question => { totPoint += question.nbPoint; })

	NotionQuesElement.innerHTML = "";
	questionElement.innerHTML = `Vous avez un score de ${score} sur ${totPoint}!`;
	nbPointsElement.innerHTML = "";
	submitButton.innerHTML = "Recommencer";

	precButton.style.visibility = "visible";
	document.getElementById("score").style.visibility = "hidden";
	timer.style.visibility = "hidden";
	nextButton.style.visibility = "hidden";
}

function handlePrec() {
	currentQuestionIndex--;
	showQuestion();
}

function handleNext() {
	currentQuestionIndex++;

	if (estChrono)
		clearInterval(interval);
	if (currentQuestionIndex < questions.length)
		showQuestion();
	else
		showScore();
}

function handleElim() {
	if (nbRep <= 2) {
		Array.from(answerButtons.children).forEach(button => { if (button.dataset.position != 0) button.classList.add("elim"); })
		elimButton.style.visibility = "hidden";
		document.getElementById("result").innerHTML = "<span class=\"difficile\"/>VOUS N'AVEZ PAS REPONDU";
		modal.classList.add("open");
		showAnswer();
		return
	}
	let nbRepFixe = nbRep;
	Array.from(answerButtons.children).forEach(button => {
		if (button.dataset.position == nbRepFixe - 1) {
			button.classList.add("elim");
			button.disabled = true;
			nbPoint -= button.dataset.pointPerdus;
			questionElement.innerHTML = "Question " + (currentQuestionIndex + 1) + "/" + questions.length + " : " + questions[currentQuestionIndex].question;
			questionElement.innerHTML += "<br>Points obtenu en cas de bonne réponse : <span class=\"difficile\"/>" + nbPoint;
		}
	});
	nbRep--;
}

nextButton.addEventListener("click", handleNext);
elimButton.addEventListener("click", handleElim);

feedbackBtn.addEventListener("click", handleNext);
closeFeedback.addEventListener("click", () => {
	modal.classList.remove("open");
});

function accueil() {
	resetState();
	let totPoint = 0;
	let totTemps = 0;
	let lstNotion = [];
	currentQuestionIndex = -1;
	let nbQParDiff = [0, 0, 0, 0];
	questions.forEach(question => {
		nbQParDiff[question.difficulte]++;
		totPoint += question.nbPoint;
		totTemps += question.temps;
		if (!lstNotion.includes(question.notion))
			lstNotion.push(question.notion);
	})
	totTemps *= 1000;

	ressourceElement.innerHTML = ressource;
	titreElement.innerHTML = titre;

	NotionQuesElement.innerHTML = "";
	questionElement.innerHTML = questions.length + " questions sur " + totPoint + " points";
	questionElement.innerHTML += "<br>" + nbQParDiff[0] + "  <span class=\"tf\">Très Facile</span>, "
		+ nbQParDiff[1] + "  <span class=\"facile\">Facile</span>, "
		+ nbQParDiff[2] + "  <span class=\"moyen\">Moyen</span>, "
		+ nbQParDiff[3] + "  <span class=\"difficile\">Difficile</span>"
	questionElement.innerHTML += '<br><br>Ce questionnaire concerne les notions suivantes : ';

	lstNotion.forEach(notion => { questionElement.innerHTML += notion + ", "; })
	questionElement.innerHTML = questionElement.innerHTML.slice(0, -2) + ".";

	let min = Math.floor((totTemps % (1000 * 60 * 60)) / (1000 * 60));
	let secondes = Math.floor((totTemps % (1000 * 60)) / 1000);
	if (min > 0) nbPointsElement.innerHTML = "Temps estimé : " + min + "min" + secondes + "s<br>";
	else
		nbPointsElement.innerHTML = "Temps estimé : " + secondes + " secondes<br>";

	if (estChrono)
		nbPointsElement.innerHTML += "<span class=\"difficile\">Quiz timer";
	else
		nbPointsElement.innerHTML += "<span class=\"facile\">Pas de timer";
	submitButton.innerHTML = "Commencer";

	nextButton.style.visibility = "hidden";
	precButton.style.visibility = "hidden";
	document.getElementById("score").style.visibility = "hidden";
	submitButton.addEventListener("click", submit);
}

accueil();

package prominfo;

import prominfo.ihm.vueAccueil.FrameAccueil;

import prominfo.metier.Difficulte;
import prominfo.metier.Metier;
import prominfo.metier.Notion;
import prominfo.metier.Question;
import prominfo.metier.Questionnaire;
import prominfo.metier.Ressource;
import prominfo.metier.ModelReponses.*;

import java.awt.Toolkit;

import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Clipboard;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import javax.swing.text.Document;

public class Controleur
{
	private Metier metier;
	@SuppressWarnings("unused")
	private FrameAccueil frameAccueil;

	// Constructeur
	public Controleur()
	{
		this.metier       = new Metier();
		this.frameAccueil = new FrameAccueil(this);
	}

	// Getters et Setters
	public List<Ressource> getLstRessources()
	{
		return this.metier.getLstRessources();
	}

	public String[] getCodesRessources()
	{
		String[] tabCodesRessources = new String[this.getLstRessources().size()];

		int cpt = 0;
		for (Ressource ressource : this.getLstRessources())
		{
			tabCodesRessources[cpt] = "" + ressource.getCode();
			cpt++;
		}

		return tabCodesRessources;
	}

	public String[] getNomsRessources()
	{
		String[] tabRessources = new String[this.getLstRessources().size()];

		int cpt = 0;
		for (Ressource ressource : this.getLstRessources())
		{
			tabRessources[cpt] = ressource.getNom();
			cpt++;
		}

		return tabRessources;
	}

	public List<Notion> getNotionsRessource(Ressource r)
	{
		return r.getLstNotions();
	}

	public List<Questionnaire> getLstQuestionnaires()
	{
		return this.metier.getLstQuestionnaires();
	}

	public int[] getMaxDiffsParNotion(String nomNotion)
	{
		Notion notion = this.getNotionParNom(nomNotion);
		int[] tabNbDiffs = {0, 0, 0, 0};

		for (Question question : notion.getLstQuestions())
		{
			tabNbDiffs[question.getDifficulte().getIdDifficulte()] += 1;
		}

		return tabNbDiffs;
	}

	// Méthodes de recherche
	public Ressource getRessourceParCode(int code)
	{
		return this.metier.getRessourceParCode(code);
	}

	public String getRessourceParNotion(String n)
	{
		Notion notion = this.getNotionParNom(n);
		return this.metier.getRessourceParNotion(notion).getCode() + "";
	}

	public Notion getNotionParNom(String nom)
	{
		return this.metier.getNotionParNom(nom);
	}

	public String[] getNotionsParRessource(int codeRessource)
	{
		Ressource ressource = this.getRessourceParCode(codeRessource);
		String[] tabNotions = new String[this.getNotionsRessource(ressource).size()];

		int cpt = 0;
		for (Notion notion : this.getNotionsRessource(ressource))
		{
			tabNotions[cpt] = notion.getNom();
			cpt++;
		}

		return tabNotions;
	}

	public String[][] getStringQuestionnaires()
	{
		String[][] tabQuestionnaires = new String[this.getLstQuestionnaires().size()][5];

		int cpt = 0;
		for (Questionnaire questionnaire : this.getLstQuestionnaires())
		{
			tabQuestionnaires[cpt][0] =      questionnaire.getTitre();
			tabQuestionnaires[cpt][1] =      questionnaire.getRessource().getNom();
			tabQuestionnaires[cpt][2] =      questionnaire.getNotionsNom();
			tabQuestionnaires[cpt][3] = "" + questionnaire.getNbQuestions();
			tabQuestionnaires[cpt][4] = "" + questionnaire.getEstChrono();
			cpt++;
		}

		return tabQuestionnaires;
	}

	public String[][] getQuestionsParNotion(String nomNotion)
	{
		Notion notion = this.getNotionParNom(nomNotion);
		String[][] tabQuestions = new String[notion.getLstQuestions().size()][Question.class.getDeclaredFields().length];

		//(0 = char type, 1 = String enonce, 2 = Difficulte diff,  3 = double pts , 4 = int tps, 5 = String cheminPJ, 6 = String explication, 7 = lstReponse)
		int cpt = 0;
		for(Question question : notion.getLstQuestions())
		{
			tabQuestions[cpt][0] = String.valueOf(question.getTypeQuestion());
			tabQuestions[cpt][1] = question.getEnonce();
			tabQuestions[cpt][2] = question.getDifficulte().name();
			tabQuestions[cpt][3] = String.valueOf(question.getPoints());
			tabQuestions[cpt][4] = String.valueOf(question.getTemps());
			tabQuestions[cpt][5] = question.getCheminPJ();
			tabQuestions[cpt][6] = question.getExplication();
			tabQuestions[cpt][7] = "";
			switch (question.getTypeQuestion())
			{
				case 'Q' ->
				{
					for( Reponse r : question.getLstReponse() )
						tabQuestions[cpt][7] += (((Rcm) r).getTexte() )+ "\t" + (((Rcm) r).getCorrect() + "\t");
				}
				case 'E' ->
				{
					for( Reponse r : question.getLstReponse() )
						tabQuestions[cpt][7] += (((RElim) r).getTexte() )+ "\t" + (((RElim) r).getOrdreElim()) + "\t" + (((RElim) r).getnbPts() + "\t");
				}
				case 'A' ->
				{
					for( Reponse r : question.getLstReponse() )
						tabQuestions[cpt][7] += (((RAsso) r).getTexte() )+ "\t";
				}

			}
			cpt++;
		}
		return tabQuestions;
	}

	public Questionnaire getQuestionnaireParTitre(String titreQs)
	{
		for(Questionnaire questionnaire : this.getLstQuestionnaires())
		{
			if (questionnaire.getTitre().equals(titreQs))
			{
				return questionnaire;
			}
		}

		return null;
	}

	public Question getQuestionParEnonce(String enonce)
	{
		for (Ressource r : this.metier.getLstRessources()) 
		{
			for (Notion n : r.getLstNotions()) 
			{
				for (Question q : n.getLstQuestions()) 
				{
					if(q.getEnonce().equals(enonce))
					{
						return q;
					}	
				}	
			}	
		}
		return null;
	}

	public String[][] getParametresQuestionnaire(String titreQuestionnaire)
	{
		Questionnaire questionnaire = this.getQuestionnaireParTitre(titreQuestionnaire);
		HashMap<Notion, LinkedList<Integer>> hmParametres = questionnaire.getHmParametres();
		String[] tabNomsNotions = this.getNotionsParRessource(questionnaire.getRessource().getCode());

		String[][] tabParametresQuestionnaire = new String[tabNomsNotions.length][5];

		for (int i = 0; i < tabNomsNotions.length; i++)
		{
			Notion notion = this.getNotionParNom(tabNomsNotions[i]);
			tabParametresQuestionnaire[i] = new String[5];
			tabParametresQuestionnaire[i][0] = tabNomsNotions[i];

			if (hmParametres.containsKey(notion))
			{
				LinkedList<Integer> valeurs = hmParametres.get(notion);
				for (int j = 0; j < valeurs.size(); j++)
				{
					tabParametresQuestionnaire[i][j + 1] = "" + valeurs.get(j);
				}
			}

			for (int j = 1; j < 5; j++)
			{
				if (tabParametresQuestionnaire[i][j] == null)
				{
					tabParametresQuestionnaire[i][j] = "0";
				}
			}
		}

		return tabParametresQuestionnaire;
	}
	

	//Tests d'unicité
	public boolean estUniqueRessource(String codeRessource)
	{
		String[] tabCodeRess = this.getCodesRessources();

		for (int cpt = 0; cpt < tabCodeRess.length; cpt++)
		{
			if (tabCodeRess[cpt].equals(codeRessource))
			{
				return false;
			}
		}

		return true;
	}

	public boolean estUniqueNotion(String nomNotion)
	{
		if (this.getNotionParNom(nomNotion) != null)
		{
			return false;
		}

		return true;
	}

	public boolean estUniqueQuestionnaire(String nomQuestionnaire)
	{
		if (this.getQuestionnaireParTitre(nomQuestionnaire) != null)
		{
			return false;
		}
		return true;
	}

	// Méthodes de création
	public Questionnaire creerQuestionnaire(String titre, int codeRess, boolean estChrono, HashMap<String,LinkedList<Integer>> hashTableau)
	{
		return this.metier.creerQuestionnaire(titre, codeRess, estChrono, hashTableau);
	}

	public Ressource creerRessource(int code, String nom)
	{
		return this.metier.creerRessource(code, nom);
	}

	public Notion creerNotion(String codeRess, String nom)
	{
		Ressource ressource = this.getRessourceParCode(Integer.parseInt(codeRess));
		return this.metier.creerNotion(ressource, nom);
	}

	public Question creerQuestion(Ressource ress, Notion nt, char type, String inti, Difficulte diff, double pts, int temps, String cheminPJ, String explication)
	{
		return this.metier.creerQuestion(ress, nt, type, inti, diff, pts, temps, cheminPJ, explication);
	}

	public Reponse creerReponse(Ressource r, Notion n, Question q, String texte, boolean correct)
	{
		return r.creerReponse(n, q, texte, correct);
	}

	public Reponse creerReponse(Ressource r, Notion n, Question q, String texte, int ordre, double nbPts)
	{
		return r.creerReponse(n, q, texte, ordre, nbPts);
	}

	public Reponse creerReponse(Ressource r, Notion n, Question q, String texte, int iAsso, String lienfic)
	{
		return r.creerReponse(n, q, texte, iAsso, lienfic);
	}

	public void ecrireQuestions(String cheminNotion, Question question, Document styleQuestion, HashMap<Reponse, Document> reponses)
	{
		this.metier.ecrireQuestions(cheminNotion, question, styleQuestion, reponses);
	}

	public void ecrireQuestionnaire(Questionnaire qs)
	{
		this.metier.ecrireQuestionnaire(qs);
	}

	//Méthodes de modification

	public void modifierRessource(String ancienCodeRessource, String nouveauCodeRessource, String nouveauNomRessource)
	{
		Ressource r = this.getRessourceParCode(Integer.parseInt(ancienCodeRessource));
		this.metier.modifierRessource(r, Integer.parseInt(nouveauCodeRessource), nouveauNomRessource);
	}

	public void modifierNotion(String ancienNomNotion, String nouveauNomNotion)
	{
		Notion n = this.getNotionParNom(ancienNomNotion);
		this.metier.modifierNotion(n, nouveauNomNotion);
	}

	// Méthodes de suppression
	
	public void supprimerRessource(String codeRessource)
	{
		Ressource r = this.getRessourceParCode(Integer.parseInt(codeRessource));
		this.metier.supprimerRessource(r);
	}

	public void supprimerNotion(String codeRessource, String nomNotion)
	{
		int code = Integer.parseInt(codeRessource);
		Ressource r = this.getRessourceParCode(code);
		Notion n = this.getNotionParNom(nomNotion);
		this.metier.supprimerNotion(r, n);
	}

	public void supprimerQuestion(String nomNot, int ligne)
	{
		Ressource r = this.metier.getRessourceParNotion(this.getNotionParNom(nomNot)); 
		Notion n = this.getNotionParNom(nomNot);
		Question q = n.getLstQuestions().get(ligne);
		this.metier.supprimerQuestion(r,n,q);
	}

	public void supprimerQuestionnaire(String titreQs)
	{
		Questionnaire qs = this.getQuestionnaireParTitre(titreQs);
		this.metier.supprimerQuestionnaire(qs);
	}

	public void supprimerQuestion(Ressource r, Notion n, Question q)
	{
		this.metier.supprimerQuestion(r,n,q);
	}

	//Méthode de génération du questionnaire
	public boolean genererQuestionnaire(String chemin)
	{
		String[] tabChemin = chemin.split("/");
		String titreQs = tabChemin[tabChemin.length - 1];
		if( !this.metier.genererQuestionnaire(chemin, this.getQuestionnaireParTitre(titreQs)))
		{
			return false;
		}

		StringSelection selection = new StringSelection("file://" + chemin + "/index.html");

		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(selection, null);
		return true;
	}

	public static void main(String[] args)
	{
		new Controleur();
	}
}
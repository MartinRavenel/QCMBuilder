package prominfo.metier;

import prominfo.metier.ModelReponses.RAsso;
import prominfo.metier.ModelReponses.RElim;
import prominfo.metier.ModelReponses.Rcm;
import prominfo.metier.ModelReponses.Reponse;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import java.util.LinkedList;
import java.util.HashMap;
import java.util.Scanner;

import javax.swing.JOptionPane;

import javax.swing.text.Document;

import javax.swing.text.rtf.RTFEditorKit;

public class Lecture
{
	private Metier metier;

	private RTFEditorKit editor;

	private String cheminDossier;

	private HashMap<Question     , File> hmQuestionsFile;
	private HashMap<Questionnaire, File> hmQuestionnairesFile;

	public Lecture(Metier metier)
	{
		this.metier = metier;

		this.editor        = new RTFEditorKit();
		this.cheminDossier = "./src/prominfo/data";

		this.hmQuestionsFile      = new HashMap<Question     , File>();
		this.hmQuestionnairesFile = new HashMap<Questionnaire, File>();
	}

	public boolean estVide()
	{
		File f = new File(this.cheminDossier);
		return f.listFiles().length == 0;
	}

	public boolean genererArborescence()
	{
		boolean work = false;
		File temp;

		File questFold = new File(this.cheminDossier + "/questionnaires");
		if (!questFold.exists())
		{
			questFold.mkdirs();
		}

		File dossierTemp = new File("./src/prominfo/ressources/import/temp");

		if(!dossierTemp.exists() && !dossierTemp.isDirectory())
		{
			dossierTemp.mkdirs();
		}

		File dossierDelete = new File("./src/prominfo/ressources/import/delete");

		if(!dossierDelete.exists() && !dossierDelete.isDirectory())
		{
			dossierDelete.mkdirs();
		}

		this.clearFile(this.cheminDossier + "/questionnaires/infosQuestionnaire/infosQuestionnaire.rtf");

		for (Ressource r : this.metier.getLstRessources()) 
		{
			String chemin = this.cheminDossier + "/" +  r.getCode() + "_" + r.getNom();
			temp = new File(chemin);
	
			if(!temp.exists())
			{
				work = temp.mkdirs();  
			}

			for (Notion n : r.getLstNotions()) 
			{
				String cheminNotion = this.cheminDossier + "/" +  r.getCode() + "_" + r.getNom() + "/" + n.getNom();
				temp = new File(cheminNotion);
		
				if(!temp.exists())
				{
					work = temp.mkdirs();
				}
			}
		}

		return work;
	}

	public void viderDeleteFolder()
	{
		File deleteFolder = new File("./src/prominfo/ressources/import/delete");
		if(deleteFolder.exists())
		{
			this.deleteDirectory(deleteFolder);
			deleteFolder.mkdir();
		}
		
	}

	public void lireNotions()
	{
		try 
		{
			for (Ressource r : this.metier.getLstRessources())
			{
				File dossier = new File(this.cheminDossier + "/" + r.getCode() + "_" + r.getNom());

				for (File f : dossier.listFiles()) 
				{
					if(f.isDirectory() && !f.getName().equals("questionnaires"))
					{
						r.creerNotion(f.getName());
					}
				}
			}
		}
		catch (Exception e)
		{
			System.out.println("document inexistant ou erronné");
			e.printStackTrace();
		}
	}

	public void lireRessources()
	{
		try
		{
			File dossier = new File(this.cheminDossier);
			
			for (File f : dossier.listFiles()) 
			{
				if(!f.getName().equals("questionnaires"))
				{
					if(f.isDirectory())
					{
						String[] tabLigne = f.getName().split("_");
	
						int    code = Integer.parseInt(tabLigne[0]);
						String nom  = tabLigne[1];
	
						this.metier.creerRessource(code, nom);
					}
				}
			}
		}
		catch (Exception e)
		{
			System.out.println("document inexistant ou erronné");
			e.printStackTrace();
		}
	}

	public void lireQuestions()
	{
		Ressource  ressource;
		Notion     notion;

		char       type;
		Difficulte diff;
		double     pts;
		int        temps;
		String     enonceRep;
		String     cheminPJ;
		String     explication;

		if(!this.estVide())
		{
			for (Ressource r : this.metier.getLstRessources())
			{
				for (Notion n : r.getLstNotions())
				{
					String cheminNotion = this.cheminDossier + "/" +  r.getCode() + "_" + r.getNom() + "/" + n.getNom();
					
					File dossierNotion = new File(cheminNotion);

					if(dossierNotion.exists() && dossierNotion.isDirectory() && !dossierNotion.getName().equals("questionnaires"))
					{
						for (File f : dossierNotion.listFiles())
						{
							String cheminQuestion = f.getPath();

							File dossierQuestion = new File(cheminQuestion);

							if (dossierQuestion.exists() && dossierNotion.isDirectory()) 
							{
								Document docQuestion = this.editor.createDefaultDocument();
								File enonceFile = new File(cheminQuestion + "/enonce.rtf");

								ressource = r;
								notion = n;

								String enonce;
								try
								{
									FileInputStream fis = new FileInputStream(enonceFile);

									this.editor.read(fis, docQuestion, 0);
	
									enonce = docQuestion.getText(0, docQuestion.getLength());
	
									enonce = enonce.trim();

									try
									{
										Scanner sc   = new Scanner(new File(cheminQuestion + "/paramQuestion.csv"), "utf-8");
										String ligne = sc.nextLine();
		
										String[] tabParam = ligne.split("\t");
		
										type  = tabParam[0].charAt(0);
										diff  = Difficulte.getDifficulte(Integer.parseInt(tabParam[1]));
										pts   = Double.parseDouble(tabParam[2]);
										temps = Integer.parseInt(tabParam[3]);

										if(tabParam.length > 4)
										{
											cheminPJ = tabParam[4];
										}
										else
										{
											cheminPJ = "";
										}

										if(tabParam.length > 5)
										{
											explication = tabParam[5];
										}
										else
										{
											explication = "";
										}

										sc.close();
	
										Question q = this.metier.creerQuestion(ressource, notion, type, enonce, diff, pts, temps, cheminPJ, explication);

										this.hmQuestionsFile.put(q, dossierQuestion);

										File dossierComp = new File(cheminQuestion + "/complement");
										if(dossierComp.exists() && dossierComp.listFiles().length > 0)
										{
											q.setCheminMicroImage(dossierComp.listFiles()[0].getPath());
										}

										FileInputStream fis6 = new FileInputStream(enonceFile);
										q.setHtmlEnonce(fis6);

										String cheminDossierReponses = cheminQuestion + "/reponses"; 

										File dossierReponses = new File(cheminDossierReponses);

										if(dossierReponses.exists() && dossierReponses.isDirectory())
										{
											for (File f2 : dossierReponses.listFiles())
											{
												String cheminDossierReponse = f2.getPath();

												File dossierReponse = new File(cheminDossierReponse);

												Document temp = this.editor.createDefaultDocument();

												if(dossierReponse.exists() && dossierReponse.isDirectory())
												{
													try
													{
														FileInputStream fis2 = new FileInputStream(cheminDossierReponse + "/enonce.rtf");

														this.editor.read(fis2, temp, 0);
			
														enonceRep = temp.getText(0, temp.getLength());
			
														enonceRep = enonceRep.trim();
			
														Scanner sc2 = new Scanner(new File(dossierReponse + "/paramReponse.csv"), "utf-8");
			
														String ligneRep = sc2.nextLine();
			
														String[] tabLigneRep = ligneRep.split("\t");
	
														FileInputStream fis3 = new FileInputStream(cheminDossierReponse + "/enonce.rtf");
														File dossierCompRep = new File(cheminDossierReponse + "/complement");

														switch (type)
														{
															case 'A' ->
															{
																if(tabLigneRep.length > 1)
																{
																	RAsso repAsso = q.creerReponse(enonceRep, Integer.parseInt(tabLigneRep[0]), tabLigneRep[1]);
																	q.setHTMLtoRep(repAsso, fis3);

																	if(dossierCompRep.exists() && dossierCompRep.listFiles().length > 0)
																	{
																		repAsso.setCheminMicroImage(dossierCompRep.listFiles()[0].getPath());
																	}
																}
																else
																{
																	q.setHTMLtoRep(q.creerReponse(enonceRep, Integer.parseInt(tabLigneRep[0]), ""), fis3);
																}
															}
															case 'E' ->
															{	
																RElim repElim = q.creerReponse(enonceRep, Integer.parseInt(tabLigneRep[0]), Double.parseDouble(tabLigneRep[1]));
																q.setHTMLtoRep(repElim, fis3);

																if(dossierCompRep.exists() && dossierCompRep.listFiles().length > 0)
																{
																	repElim.setCheminMicroImage(dossierCompRep.listFiles()[0].getPath());
																}
															}
															case 'Q' ->
															{
																Rcm repCM = q.creerReponse(enonceRep, Boolean.parseBoolean(tabLigneRep[0]));
																q.setHTMLtoRep(repCM, fis3);

																if(dossierCompRep.exists() && dossierCompRep.listFiles().length > 0)
																{
																	repCM.setCheminMicroImage(dossierCompRep.listFiles()[0].getPath());
																}
															}
														}

														sc2.close();
													}
													catch (Exception e)
													{
														System.out.println("[ERREUR] reponse corrompu : " + cheminDossierReponse + "\\enonce.rtf");
														n.supprimerQuestion(q);
														JOptionPane.showMessageDialog(null, "[ERREUR] Reponse Corrompue : " + cheminDossierReponse + "\\enonce.rtf", "Erreur", JOptionPane.ERROR_MESSAGE);
													}
												}
											}
										}
									}
									catch (Exception e)
									{
										System.out.println("[ERREUR] paramètre de questions erroné : " + cheminQuestion + "/paramQuestion.csv");
										JOptionPane.showMessageDialog(null, "[ERREUR] paramètre de questions erroné : " + cheminQuestion + "/paramQuestion.csv", "Erreur", JOptionPane.ERROR_MESSAGE);
									}
								}
								catch (Exception e)
								{
									System.out.println("[ERREUR] enonce manquant ou corrompu : " + enonceFile.getPath());
									JOptionPane.showMessageDialog(null, "[ERREUR] enonce manquant ou corrompu : " + enonceFile.getPath(), "Erreur", JOptionPane.ERROR_MESSAGE);
								}
							}
						}
					}
				}
			}
		}
	}

	public void lireQuestionnaire()
	{
		for (Ressource r : this.metier.getLstRessources()) 
		{
			HashMap<String, LinkedList<Integer>> hmStringInteger = new HashMap<String, LinkedList<Integer>>();
			String cheminDossiersQuestionnaires = this.cheminDossier + "/" + r.getCode() + "_" + r.getNom() + "/questionnaires";
			File dossiersQuestionnaires = new File(cheminDossiersQuestionnaires);

			if(dossiersQuestionnaires.exists() && dossiersQuestionnaires.isDirectory())
			{
				for (File f : dossiersQuestionnaires.listFiles()) 
				{
					if(f.isDirectory() && f.getName().substring(0, 14).equals("questionnaire_"))
					{
						String cheminQuestionnaire = f.getPath();

						try
						{
							File file = new File(cheminQuestionnaire + "/datasQuestionnaire.csv");

							if(file.exists())
							{
								Scanner sc = new Scanner(file, "utf-8");

								if(sc.hasNextLine())
								{
									String ligne = sc.nextLine();

									String[] tabDatasQuestionnaires = ligne.split("\t");

									String titre = tabDatasQuestionnaires[0];
									int ress = Integer.parseInt(tabDatasQuestionnaires[1]);
									boolean estChrono = Boolean.parseBoolean(tabDatasQuestionnaires[2]);

									while (sc.hasNextLine())
									{
										LinkedList<Integer> lstInt = new LinkedList<Integer>();

										ligne = sc.nextLine();
										String notion = ligne.trim();
										
										ligne = sc.nextLine();
										String[] tabDiffQuest = ligne.split("\t");

										for (String s : tabDiffQuest)
										{
											if(s != null)
											{
												lstInt.add(Integer.parseInt(s));
											}
										}

										hmStringInteger.put(notion, lstInt);
									}

									sc.close();
									Questionnaire q = this.metier.creerQuestionnaire(titre, ress, estChrono, hmStringInteger);
									this.hmQuestionnairesFile.put(q, new File(cheminQuestionnaire));
								}
							}
						}
						catch (Exception e)
						{
							JOptionPane.showMessageDialog(null, "[ERREUR] datasQuestionnaires.csv manquant ou corrompue : " + cheminQuestionnaire + "\\datasQuestionnaire.csv", "Erreur", JOptionPane.ERROR_MESSAGE);
							System.err.println("[ERREUR] datasQuestionnaires.csv manquant ou corrompue : " + cheminQuestionnaire + "\\datasQuestionnaire.csv");
							e.printStackTrace();
						}
					}
				}
			}
		}
	}

	public void ecrireQuestionnaire(Questionnaire qs)
	{
		if(!this.estVide())
		{
			try 
			{
				String cheminDossierQuestionnaires = this.cheminDossier + "/" + qs.getRessource().getCode() + "_" + qs.getRessource().getNom() + "/questionnaires";
				File dossierQuestionnaires = new File(cheminDossierQuestionnaires);
	
				if(!dossierQuestionnaires.exists() && !dossierQuestionnaires.isDirectory())
				{
					dossierQuestionnaires.mkdirs();
				}
	
				int questValue = Lecture.getMaxCodeValue(cheminDossierQuestionnaires, "/questionnaire_");
	
				String cheminDossierQuestionnaire = cheminDossierQuestionnaires + "/questionnaire_" + questValue;
				File dossierQuestionnaire = new File(cheminDossierQuestionnaire);
	
				if(!dossierQuestionnaire.exists() && !dossierQuestionnaire.isDirectory())
				{
					dossierQuestionnaire.mkdirs();
				}

				this.hmQuestionnairesFile.put(qs, dossierQuestionnaire);

				String cheminFileQuestionnaire = cheminDossierQuestionnaire + "/datasQuestionnaire.csv";
				File fileQuestionnaire = new File(cheminFileQuestionnaire);

				if(!fileQuestionnaire.exists())
				{
					fileQuestionnaire.createNewFile();
				}

				PrintWriter pw = new PrintWriter(fileQuestionnaire, "utf-8");
				
				pw.print(qs.getTitre() + "\t");
				pw.print(qs.getRessource().getCode() + "\t");
				pw.print(qs.getEstChrono() + "\t");
				pw.println("");

				for (Notion n : qs.getHmParametres().keySet()) 
				{
					pw.print(n.getNom());
					pw.println("");
					for (Integer i : qs.getHmParametres().get(n)) 
					{
						pw.print(i + "\t");
					}

					pw.println("");
				}

				pw.close();
			}
			catch (Exception e)
			{
				System.out.println("questionnaire : echec");
				e.printStackTrace();
			}
		}
	}

	public boolean clearFile(String chemin)
	{
		File file = new File(chemin);

		if(file.exists() && !file.isDirectory())
		{
			try
			{
				BufferedWriter writer = Files.newBufferedWriter(Paths.get(chemin));
				writer.write("");
				writer.flush();
				writer.close();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}

			return true;
		}

		return false;
	}

	public void ecrireQuestions(String cheminNotion, Question question, Document styleQuestion, HashMap<Reponse, Document> hmReponses)
	{
		int  numQuestion = Lecture.getMaxCodeValue(cheminNotion, "/question_");
		char typeQuestion;
		File repQuestion = new File(cheminNotion + "/question_" + numQuestion + "/reponses");

		if(!repQuestion.exists())
		{
			repQuestion.mkdirs();
		}

		try
		{
			FileOutputStream fos = new FileOutputStream(cheminNotion + "/question_" + numQuestion + "/enonce.rtf");
			FileInputStream  fis = new FileInputStream (cheminNotion + "/question_" + numQuestion + "/enonce.rtf");

			question.setHtmlEnonce(fis);
			this.editor.write(fos, styleQuestion, 0, styleQuestion.getLength());

			this.hmQuestionsFile.put(question, new File(cheminNotion + "/question_" + numQuestion));

			File paramQuestion = new File(cheminNotion + "/question_" + numQuestion + "/paramQuestion.csv");

			if(!paramQuestion.exists() && !paramQuestion.isDirectory())
			{
				paramQuestion.createNewFile();
			}

			/*-------------- */
			File compFold = Lecture.creeFoldComp(cheminNotion + "/question_" + numQuestion);
			/*-------------- */

			if(question.getNomMicroImage() != null)
			{
				Files.copy((new File("./src/prominfo/ressources/import/temp/" + question.getNomMicroImage())).toPath(), (new File(compFold.getPath() + "/" + question.getNomMicroImage())).toPath(), StandardCopyOption.REPLACE_EXISTING);
				question.setCheminMicroImage(compFold.getPath() + "/" + question.getNomMicroImage());
			}

			PrintWriter pw = new PrintWriter(paramQuestion, "utf-8");

			typeQuestion = question.getTypeQuestion();

			pw.print(question.getTypeQuestion() + "\t");
			pw.print(question.getDifficulte().getIdDifficulte() + "\t");
			pw.print(question.getPoints() + "\t");
			pw.print(question.getTemps() + "\t");

			if(question.getCheminPJ() == null)
			{
				pw.print("null\t");
			}
			else
			{
				pw.print(question.getCheminPJ() + "\t");
			}

			if(question.getExplication() == null)
			{
				pw.print("null\t");
			}
			else
			{
				pw.print(question.getExplication().replaceAll("\n", "<br>").replaceAll("\r", "<br>") + "\t");
			}

			pw.close();

			for (Reponse r : hmReponses.keySet())
			{
				int numRep = Lecture.getMaxCodeValue(cheminNotion + "/question_" + numQuestion + "/reponses", "/reponse_");

				File dossierReponse = new File(cheminNotion + "/question_" + numQuestion + "/reponses/reponse_" + numRep);
				
				if(!dossierReponse.exists())
				{
					dossierReponse.mkdirs();
				}

				File paramReponse = new File(cheminNotion + "/question_" + numQuestion + "/reponses/reponse_" + numRep + "/paramReponse.csv");

				if(!paramReponse.exists() && !paramReponse.isDirectory())
				{
					paramReponse.createNewFile();
				}

				File foldCompRep = Lecture.creeFoldComp(cheminNotion + "/question_" + numQuestion + "/reponses/reponse_" + numRep);

				if(r.getNomMicroImage() != null)
				{
					Files.copy((new File("./src/prominfo/ressources/import/temp/" + r.getNomMicroImage())).toPath(), (new File(foldCompRep.getPath() + "/" + r.getNomMicroImage())).toPath(), StandardCopyOption.REPLACE_EXISTING);
					r.setCheminMicroImage(foldCompRep.getPath() + "/" + r.getNomMicroImage());
				}

				PrintWriter pwRep = new PrintWriter(paramReponse, "utf-8");

				switch (typeQuestion)
				{
					case 'A' ->
					{
						pwRep.print(((RAsso)r).getIAsso() + "\t");
						pwRep.print(((RAsso)r).getLienFic() + "\t");
					}
					case 'E' ->
					{
						pwRep.print(((RElim)r).getOrdreElim() + "\t");
						pwRep.print(((RElim)r).getnbPts() + "\t");
					}
					case 'Q' ->
					{
						pwRep.print(((Rcm)r).getCorrect() + "\t");
					}
				}

				pwRep.close();

				fos = new FileOutputStream(cheminNotion + "/question_" + numQuestion + "/reponses/reponse_" + numRep + "/enonce.rtf");
				fis = new FileInputStream(cheminNotion + "/question_" + numQuestion + "/reponses/reponse_" + numRep + "/enonce.rtf");

				question.setHTMLtoRep(r, fis);
				this.editor.write(fos, hmReponses.get(r), 0, hmReponses.get(r).getLength());
			}

			File tempFile = new File("./src/prominfo/ressources/import/temp");
			this.deleteDirectory(tempFile);
			tempFile.mkdir();
		}
		catch (Exception e) { e.printStackTrace(); }

		this.viderTemp();
	}

	public void modifierRessource(Ressource r, int nouveauCodeRessource, String nouveauNomRessource)
	{
		File oldDirectory = new File(this.cheminDossier + "/" +  r.getCode() + "_" + r.getNom());
		File newDirectory = new File(this.cheminDossier + "/" +  nouveauCodeRessource + "_" + nouveauNomRessource);
		
		try {
			Lecture.copyDirectory(oldDirectory, newDirectory);
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.deleteDirectory(oldDirectory);
	}

	public void modifierNotion(Notion n, String nouveauNomNotion)
	{
		Ressource r = this.metier.getRessourceParNotion(n);

		File oldDirectory = new File(this.cheminDossier + "/" +  r.getCode() + "_" + r.getNom() + "/" + n.getNom());
		File newDirectory = new File(this.cheminDossier + "/" +  r.getCode() + "_" + r.getNom() + "/" + nouveauNomNotion);
		
		try {
			Lecture.copyDirectory(oldDirectory, newDirectory);
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.deleteDirectory(oldDirectory);
	}

	public void viderTemp()
	{
		File tempFile = new File("./src/prominfo/ressources/import/temp");
		this.deleteDirectory(tempFile);
		tempFile.mkdir();
	}

	public static File creeFoldComp(String chemin)
	{
		File file = new File(chemin + "/complement");

		if(!file.exists() && !file.isDirectory())
		{
			file.mkdirs();
			return file;
		}

		return null;
	}

	public static int getMaxCodeValue(String chemin, String code)
	{
		File dossierNotion = new File(chemin);

		int cpt;
		for (cpt = 1; cpt < dossierNotion.listFiles().length + 1; cpt++)
		{
			File temp = new File(chemin + code + cpt);

			if(!temp.exists() && !temp.isDirectory())
			{
				return cpt;
			}
		}

		return cpt;
	}

	public void nettoyage()
	{
		File file = new File(this.cheminDossier);

		this.deleteDirectory(file);
		file.mkdirs();
	}

	public void supprimerRessources(Ressource rs)
	{
		File file = new File(this.cheminDossier + "/" + rs.getCode() + "_" + rs.getNom());
		try {
			Files.move(file.toPath(), new File("./src/prominfo/ressources/import/delete").toPath(), StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void supprimerNotion(Notion notion)
	{
		for (Ressource r : this.metier.getLstRessources()) 
		{
			for (Notion n : r.getLstNotions()) 
			{
				File file = new File(this.cheminDossier + "/" +  r.getCode() + "_" + r.getNom() + "/" + n.getNom());

				if(file.exists() && n == notion)
				{
					try {
						Files.move(file.toPath(), new File("./src/prominfo/ressources/import/delete").toPath(), StandardCopyOption.REPLACE_EXISTING);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
	}

	public void supprimerQuestion(Question q)
	{
		try 
		{
			Files.move(this.hmQuestionsFile.get(q).toPath(), new File("./src/prominfo/ressources/import/delete").toPath(), StandardCopyOption.REPLACE_EXISTING);

			System.out.println("questions supprimé");
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public void supprimerQuestionnaire(Questionnaire q)
	{
		try 
		{
			Files.move(this.hmQuestionnairesFile.get(q).toPath(), new File("./src/prominfo/ressources/import/delete").toPath(), StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	private boolean deleteDirectory(File folder)
	{
		if (folder == null || !folder.exists()) {
            return false;
        }
        boolean success = true;

        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    success &= deleteDirectory(file);
                } else {
                    success &= deleteFile(file); 
                }
            }
        }

        success &= deleteFile(folder);

        return success;
	}

	private static boolean deleteFile(File file) {
        try {
            if (!file.delete()) {
                System.err.println("Échec de la suppression : " + file.getAbsolutePath());
                forceDelete(file);
                return file.delete();
            }
            return true;
        } catch (Exception e) {
            System.err.println("Erreur lors de la suppression : " + e.getMessage());
            return false;
        }
    }

	private static void forceDelete(File file) {
        String os = System.getProperty("os.name").toLowerCase();
        try {
            if (os.contains("win")) {
                ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/c", "del /f /q \"" + file.getAbsolutePath() + "\"");
                pb.inheritIO();
                Process process = pb.start();
                process.waitFor();
            } else if (os.contains("nix") || os.contains("nux") || os.contains("mac")) {
                ProcessBuilder pb = new ProcessBuilder("rm", "-rf", file.getAbsolutePath());
                pb.inheritIO();
                Process process = pb.start();
                process.waitFor();
            }
        } catch (Exception e) {
            System.err.println("Impossible de forcer la suppression sur " + os + " : " + e.getMessage());
        }
    }

	public static void copyDirectory(File sourceDir, File targetDir) throws IOException 
	{
        if (sourceDir.isDirectory()) {
            copyDirectoryRecursively(sourceDir, targetDir);
        } else {
            Files.copy(sourceDir.toPath(), targetDir.toPath());
        }
    }
	private static void copyDirectoryRecursively(File source, File target) throws IOException 
	{
        if (!target.exists()) {
            target.mkdir();
        }

        for (String child : source.list()) {
            copyDirectory(new File(source, child), new File(target, child));
        }
    }

	public void afficherDossier()
	{
		File file = new File(this.cheminDossier);
		for (File f : file.listFiles())
		{
			System.out.println(f.getName());
		}
	}

	public String getCheminDossier()
	{
		return this.cheminDossier;
	}
}
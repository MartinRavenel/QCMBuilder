package prominfo.metier;

public enum Difficulte
{
	TRES_FACILE(0),
	FACILE(1),
	MOYEN(2),
	DIFFICILE(3);

	private int idDifficulte;

	Difficulte(int diff)
	{
		this.idDifficulte = diff;
	}

	public int getIdDifficulte()
	{
		return idDifficulte;
	}

	public static Difficulte getDifficulte(int id)
	{
		for (Difficulte d : Difficulte.values())
		{
			if (d.idDifficulte == id)
			{
				return d;
			}
		}

		return null;
	}
}
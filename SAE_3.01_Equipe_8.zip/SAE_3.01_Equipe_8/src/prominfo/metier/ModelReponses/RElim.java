package prominfo.metier.ModelReponses;

public class RElim extends Reponse
{
	private int ordreElim;

	private double nbPts;

	public RElim(String texte, int ordre, double nbPts)
	{
		super(texte);
		this.ordreElim = ordre;
		this.nbPts     = nbPts;
	}

	public int getOrdreElim() { return this.ordreElim; }
	public void setOrdreElim(int ordreElim) { this.ordreElim = ordreElim; }

	public double getnbPts() { return this.nbPts; }
	public void setnbPts(double nbPts) { this.nbPts = nbPts; }
}
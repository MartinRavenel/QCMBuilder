package prominfo.metier.ModelReponses;

public class Rcm extends Reponse
{
	private boolean correct;

	public Rcm(String texte, boolean correct)
	{
		super(texte);
		this.correct = correct;
	}

	public boolean getCorrect() { return correct; }
	public void setCorrect(boolean correct) { this.correct = correct; }
}
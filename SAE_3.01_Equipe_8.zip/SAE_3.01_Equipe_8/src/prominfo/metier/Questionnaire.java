package prominfo.metier;

import java.util.HashMap;
import java.util.LinkedList;

public class Questionnaire
{
	private String titre;
	private Ressource ressource;
	private boolean estChrono;
	private HashMap<Notion,LinkedList<Integer>> hmParametres;

	public Questionnaire(String titre, Ressource ressource, boolean estChrono, HashMap<Notion,LinkedList<Integer>> hmParametres)
	{
		this.titre          = titre;
		this.ressource      = ressource;
		this.estChrono      = estChrono;
		this.hmParametres = hmParametres;
	}

	public String getTitre() { return titre; }
	public void setTitre(String titre) { this.titre = titre; }

	public Ressource getRessource() { return ressource; }
	public void setRessource(Ressource ressource) { this.ressource = ressource; }

	public String getNotionsNom()
	{
		String s = "";
		for (Notion n : this.hmParametres.keySet())
		{
			s += n.getNom() + ", ";
		}

		return s;
	}

	public Notion[] getLstNotions()
	{
		Notion[] tabNotions = (Notion[]) this.hmParametres.keySet().toArray();
		return tabNotions;
	}

	public int getNbQuestions()
	{
		int nbQuestions = 0;
		for (LinkedList<Integer> lstInteger : this.hmParametres.values())
		{
			for (int valeur : lstInteger)
			{
				nbQuestions += valeur;
			}
		}

		return nbQuestions;
	}

	public boolean getEstChrono() { return this.estChrono; }
	public void setEstChrono(boolean estChrono) { this.estChrono = estChrono; }

	public HashMap<Notion, LinkedList<Integer>> getHmParametres() { return this.hmParametres; }
	public void setHmParametres(HashMap<Notion, LinkedList<Integer>> hmParametres) { this.hmParametres = hmParametres; }

	public String toString()
	{
		String s = "";

		s += this.titre + "  " + this.getRessource().getCode() + "  " + this.getEstChrono() + " " +this.getNbQuestions() + " questions" + "\n";
		s += "------------------*\n";
		int nbNotions = 1, idDiff;
		for (Notion n : hmParametres.keySet())
		{
			idDiff = 0;
			s+= "Notion n°" + nbNotions + " : " + n.getNom() + "\n";
			for (Integer i : hmParametres.get(n))
			{
				s += (i + " - " + Difficulte.getDifficulte(idDiff) +"\n");
				idDiff++;
			}

			nbNotions++;
		}

		s+="\n";
		return s;
	}
}
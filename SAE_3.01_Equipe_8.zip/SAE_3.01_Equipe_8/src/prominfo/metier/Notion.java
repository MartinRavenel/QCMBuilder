package prominfo.metier;

import prominfo.metier.ModelReponses.Reponse;

import java.util.ArrayList;
import java.util.List;

public class Notion
{
	private String nom;

	private List<Question> lstQuestions;

	public Notion(String nom)
	{
		this.nom = nom;
		this.lstQuestions = new ArrayList<Question>();
	}

	// Getters et Setters
	public String getNom() { return this.nom; }
	public void setNom(String nom) { this.nom = nom; }

	public List<Question> getLstQuestions() { return this.lstQuestions; }
	public void setLstQuestions(List<Question> lstQuestions) { this.lstQuestions = lstQuestions; }

	// Méthodes de recherche
	public Question recQuestionParEnonce(String enonce)
	{
		for( Question q : this.lstQuestions )
		{
			if( q.getEnonce().equals(enonce))
				return q;
		}

		return null;
	}

	// Méthodes de création
	public Question creerQuestion(char type, String enonce, Difficulte diff, double pts, int temps, String cheminPJ, String explication)
	{
		Question q = Question.creerQuestion(type, enonce, diff, pts, temps, cheminPJ, explication);
		if (this.ajouterQuestion(q))
			return q;

		System.out.println("ALERTE : Question pas créé ");
		return null;
	}

	public boolean ajouterQuestion(Question q)
	{
		return this.lstQuestions.add(q);
	}

	public Reponse creerReponse(Question q, String texte, boolean correct)
	{
		return q.creerReponse(texte, correct);
	}

	public Reponse creerReponse(Question q, String texte, int ordre, double nbPts)
	{
		return q.creerReponse(texte, ordre, nbPts);
	}

	public Reponse creerReponse(Question q, String texte, int iAsso, String lienFic)
	{
		return q.creerReponse(texte, iAsso, lienFic);
	}

	// Méthodes de suppression
	public void supprimerQuestion(Question q)
	{
		this.lstQuestions.remove(q);
	}
	
	// Méthodes d'affichage
	public String toString()
	{
		return this.nom;
	}
}
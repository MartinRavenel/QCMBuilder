#!/bin/sh

# Variables
SRC_DIR="src"
BIN_DIR="bin"
JAR_NAME="QCM_Builder.jar"
MAIN_CLASS="com.example.Main"  # Remplacez par le nom complet de votre classe principale

# Créer le répertoire bin s'il n'existe pas
mkdir -p $BIN_DIR

# Compiler les fichiers .java
javac -d $BIN_DIR $(find $SRC_DIR -name "*.java")

# Créer le fichier JAR
jar cfe $JAR_NAME $MAIN_CLASS -C $BIN_DIR .

echo "Compilation terminée. Le fichier JAR est créé : $JAR_NAME"
package prominfo.metier;

import prominfo.metier.ModelReponses.RAsso;
import prominfo.metier.ModelReponses.RElim;
import prominfo.metier.ModelReponses.Rcm;
import prominfo.metier.ModelReponses.Reponse;

import java.io.FileInputStream;

import java.util.ArrayList;
import java.util.HashMap;

public class Question
{
	private char       typeQuestion;
	private String     enonce;
	private Difficulte difficulte;
	private double     points;
	private int        temps;
	private String     cheminPJ;
	private String     explication;

	private String nomMicroImage;
	private String cheminMicroImage;
	
	private String htmlEnonce;
	private HashMap<Reponse, String> hmRepHTML;

	private ArrayList<Reponse> lstReponse;

	private Question(char type, String enonce, Difficulte diff,  double pts , int tps, String cheminPJ, String explication)
	{
		this.typeQuestion  = type;
		this.enonce        = enonce;
		this.difficulte    = diff;
		this.points        = pts;
		this.temps         = tps;
		this.cheminPJ      = cheminPJ;
		this.explication   = explication;
		this.nomMicroImage = "";

		this.hmRepHTML  = new HashMap<Reponse, String>();
		this.lstReponse = new ArrayList<Reponse>();
	}

	public static Question creerQuestion(char type, String enonce, Difficulte diff, double pts, int tps, String cheminPJ, String explication)
	{
		if( type != 'Q' && type != 'E' && type != 'A')
			return null;
		if( pts < 0 ||  tps < 0 )
			return null;

		return new Question(type, enonce, diff,  pts, tps, cheminPJ, explication);
	}

	public char getTypeQuestion() { return this.typeQuestion; }
	public void setTypeQuestion(char typeQuestion) { this.typeQuestion = typeQuestion; }

	public String getEnonce() { return this.enonce; }
	public void setEnonce(String enonce) { this.enonce = enonce; }

	public Difficulte getDifficulte() { return this.difficulte; }
	public void setDifficulte(Difficulte difficulte) { this.difficulte = difficulte; }

	public double getPoints() { return this.points; }
	public void setPoints(double points) { this.points = points; }

	public int getTemps() { return this.temps; }
	public void setTemps(int temps) { this.temps = temps; }

	public ArrayList<Reponse> getLstReponse() { return new ArrayList<Reponse>(this.lstReponse); }
	public void setLstReponse(ArrayList<Reponse> lstReponse) { this.lstReponse = lstReponse; }

	public String getCheminPJ() { return this.cheminPJ; }
	public void   setCheminPJ(String str) { this.cheminPJ = str; }

	public String getExplication() { return this.explication; }
	public void setExplication(String explication) {this.explication = explication;}

	public String getNomMicroImage() { return this.nomMicroImage; }
	public void setNomMicroImage(String nomMicroImage) {this.nomMicroImage = nomMicroImage;}

	public String getCheminMicroImage() { return cheminMicroImage; }
	public void setCheminMicroImage(String cheminMicroImage) {this.cheminMicroImage = cheminMicroImage;}

	public String getHtmlEnonce() { return this.htmlEnonce; }
	public void setHtmlEnonce(String htmlEnonce) { this.htmlEnonce = htmlEnonce; }
	public void setHtmlEnonce(FileInputStream fis)
	{
		try {this.htmlEnonce = Util.rtfToHtml(fis); }
		catch (Exception e) { e.printStackTrace(); }
	}

	public String getHTMLofRep(Reponse rep) { return this.hmRepHTML.get(rep); }
	public HashMap<Reponse, String> getHmRepHTML() { return hmRepHTML; }
	public void setHTMLtoRep(Reponse rep, String html) { this.hmRepHTML.put(rep, html); }
	public void setHTMLtoRep(Reponse rep, FileInputStream rtf)
	{
		try { this.hmRepHTML.put(rep, Util.rtfToHtml(rtf)); }
		catch (Exception e) { e.printStackTrace(); }
	}

	public Rcm creerReponse(String texte, boolean correct)
	{
		Rcm r = new Rcm(texte, correct);
		this.lstReponse.add(r);
		return r;
	}

	public RElim creerReponse(String texte, int ordre, double nbPts)
	{
		if( nbPts > this.points )
			nbPts = 0;

		RElim r = new RElim(texte, ordre, nbPts);
		this.lstReponse.add(r);
		return r;
	}

	public RAsso creerReponse(String texte, int iAsso, String lienFic)
	{
		RAsso r = new RAsso(texte, iAsso, lienFic);
		this.lstReponse.add(r);
		return r;
	}

	@Override
	public String toString()
	{
		String s = "Question [enonce=" + enonce       + ", difficulte="    + difficulte    + ", points=" + points + ", temps=" + temps
				+ ", typeQuestion="    + typeQuestion + ", cheminPJ="      + cheminPJ
				+ ", explication="     + explication  + ", nomMicroImage=" + nomMicroImage + "]";

		for( Reponse r : this.lstReponse )
		{
			s += "\n" + r.toString();
		}

		return s;
	}
}
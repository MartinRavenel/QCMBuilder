package prominfo.metier.ModelReponses;

public abstract class Reponse
{
	private String texte;
	private String nomMicroImage;
	private String cheminMicroImage;

	public Reponse(String texte)
	{
		this.texte = texte;
		this.nomMicroImage = "";
	}

	public String getTexte() { return this.texte; }
	public void setTexte(String reponse) { this.texte = reponse; }

	public String getNomMicroImage() {return this.nomMicroImage;}
	public void setNomMicroImage(String nomMicroImage) {this.nomMicroImage = nomMicroImage;}

	public String getCheminMicroImage() {return cheminMicroImage;}
	public void setCheminMicroImage(String cheminMicroImage) {this.cheminMicroImage = cheminMicroImage;}
}
package prominfo.metier.ModelReponses;

public class RAsso extends Reponse
{
	private int iAsso;

	private String lienFic;

	public RAsso(String texte, int iAsso, String lienFic)
	{
		super(texte);
		this.iAsso   = iAsso;
		this.lienFic = lienFic;
	}

	public int getIAsso() { return iAsso; }
	public void setIAsso(int iAsso) { this.iAsso = iAsso; }

	public String getLienFic() { return lienFic; }
	public void setLienFic(String lienFic) { this.lienFic = lienFic; }
}
package prominfo.metier;

import prominfo.metier.ModelReponses.RAsso;
import prominfo.metier.ModelReponses.RElim;
import prominfo.metier.ModelReponses.Rcm;
import prominfo.metier.ModelReponses.Reponse;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.PrintWriter;

import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class GenererSite
{
	public static String gererPieceJointe(String cheminPJ, String cheminDossier, Boolean microImage)
	{
		try
		{
			String part[] = cheminPJ.split("/");
			if (System.getProperty("os.name").contains("Windows"))
				part = cheminPJ.split("\\\\");
			String nomFichier = part[part.length-1];
			if (microImage)
				Files.copy((new File(cheminPJ).toPath()),
						(new File(cheminDossier + "/ressources/" + nomFichier).toPath()),
						StandardCopyOption.REPLACE_EXISTING);
			else
				Files.copy((new File("src/prominfo/ressources/import/"+cheminPJ).toPath()),
					(new File(cheminDossier+"/ressources/"+nomFichier).toPath()),
					StandardCopyOption.REPLACE_EXISTING);
			return "./ressources/" + nomFichier;
		}
		catch (Exception e) { e.printStackTrace(); }

		return "";
	}

	public static String purificationFeedback(String str)
	{
		str = str.replaceAll("\n", "<br>");
		str = str.replaceAll("\"","\\\"");
		return str;
	}

	public static String purification(String str)
	{
		String[] wow = { "<html>", "</html>", "<body>", "</body>", "<head>", "</head>", "<p>", "</p>",
				"<p class=default>", "\n","\r","¤"};
		for (String string : wow)
		{
			str = str.replaceAll(string, "");
		}
		str = str.replace('\"', '\'');
		str = str.replaceAll("\"", "\\\"");
		return str;
	}

	public static String ecritureRcm(ArrayList<Reponse> lstRep,String cheminDossier, Question q)
	{
		Rcm tmp = null;
		String micro ="";
		String sRet = "\ttype : \"QCM\",\n";
		sRet += "\tanswers : [\n";

		for(int i=0; i<lstRep.size()-1; i++)
		{
			tmp = (Rcm) lstRep.get(i);
			if (tmp.getCheminMicroImage()==null||tmp.getCheminMicroImage()==""|| tmp.getCheminMicroImage().equals("null")) micro = "";
			else
			micro = "<br><img src="+'\\'+"\""+GenererSite.gererPieceJointe(tmp.getCheminMicroImage(), cheminDossier,true)+'\\'+"\"/>";
			sRet += "\t\t{ text : \""+purification(q.getHTMLofRep(tmp))+micro+"\", correct: "+tmp.getCorrect()+"},\n";
		}
		tmp = (Rcm)lstRep.get(lstRep.size()-1);
		if (tmp.getCheminMicroImage()==null||tmp.getCheminMicroImage()==""|| tmp.getCheminMicroImage().equals("null")) micro = "";
			else micro = "<br><img src="+'\\'+"\""+GenererSite.gererPieceJointe(tmp.getCheminMicroImage(), cheminDossier,true)+'\\'+"\"/>";
		sRet += "\t\t{ text : \"" + purification(q.getHTMLofRep(tmp))+micro + "\", correct: " + tmp.getCorrect() + "}\n\t],\n";

		return sRet;
	}

	public static String ecritureRElim(ArrayList<Reponse> lstRep,String cheminDossier, Question q)
	{
		RElim tmp = null;
		String micro ="";
		String sRet = "\ttype : \"Elimination\",\n";
		sRet += "\tanswers : [\n";

		for(int i=0; i<lstRep.size()-1; i++)
		{
			tmp = (RElim) lstRep.get(i);
			if (tmp.getCheminMicroImage()==null||tmp.getCheminMicroImage()==""|| tmp.getCheminMicroImage().equals("null")) micro = "";
			else micro = "<br><img src="+'\\'+"\""+GenererSite.gererPieceJointe(tmp.getCheminMicroImage(), cheminDossier,true)+'\\'+"\"/>";
			sRet += "\t\t{ text : \""+purification(q.getHTMLofRep(tmp))+micro+"\", position: "+tmp.getOrdreElim()+", pointPerdus: "+tmp.getnbPts()+"},\n";
		}
		tmp = (RElim) lstRep.get(lstRep.size()-1);
		if (tmp.getCheminMicroImage()==null||tmp.getCheminMicroImage()==""|| tmp.getCheminMicroImage().equals("null")) micro = "";
			else micro = "<br><img src="+'\\'+"\""+GenererSite.gererPieceJointe(tmp.getCheminMicroImage(), cheminDossier,true)+'\\'+"\"/>";
		sRet += "\t\t{ text : \"" + purification(q.getHTMLofRep(tmp))+micro + "\", position: " + tmp.getOrdreElim() + ", pointPerdus: "+ tmp.getnbPts() + "}\n\t],\n";
		
		return sRet;
	}

	public static String ecritureRAsso(ArrayList<Reponse> lstRep, String cheminDossier, Question q)
	{
		RAsso tmp = null;
		String micro="";
		String sRet = "\ttype : \"Association\",\n";
		sRet += "\tanswers : [\n";

		for(int i=0; i<lstRep.size()-1; i++)
		{
			tmp = (RAsso) lstRep.get(i);
			if (tmp.getCheminMicroImage()==null||tmp.getCheminMicroImage()==""|| tmp.getCheminMicroImage().equals("null")) micro = "";
			else micro = "<br><img src="+'\\'+"\""+GenererSite.gererPieceJointe(tmp.getCheminMicroImage(), cheminDossier,true)+'\\'+"\"/>";

			sRet += "\t\t{ text : \""+purification(q.getHTMLofRep(tmp))+micro+"\", numero: "+tmp.getIAsso();

			if((!(tmp.getLienFic().equals("null")))&&tmp.getLienFic()!=null && tmp.getLienFic()!="")
				sRet += "link : \""+gererPieceJointe(tmp.getLienFic(), cheminDossier,false)+"\"";
			sRet+="},\n";
		}
		tmp = (RAsso) lstRep.get(lstRep.size()-1);
		if (tmp.getCheminMicroImage()==null||tmp.getCheminMicroImage()==""|| tmp.getCheminMicroImage().equals("null")) micro = "";
			else micro = "<br><img src="+'\\'+"\""+GenererSite.gererPieceJointe(tmp.getCheminMicroImage(), cheminDossier,true)+'\\'+"\"/>";

		sRet += "\t\t{ text : \"" + purification(q.getHTMLofRep(tmp))+micro + "\", numero: " + tmp.getIAsso();

		if ((!(tmp.getLienFic().equals("null"))) && tmp.getLienFic()!=null && tmp.getLienFic()!="")
			sRet += "link : \"" +gererPieceJointe(tmp.getLienFic(), cheminDossier,false)+"\"";

		return sRet+"}\n\t],";
	}

	public static String ecritureQuestion(Question q, Notion notion,String cheminDossier)
	{
		String sRet = "{\n\tnotion :\""+purification(notion.getNom())+"\",\n";
		String micro = "";
		if (q.getCheminMicroImage()!=null&&q.getCheminMicroImage() != "" && !q.getCheminMicroImage().equals("null"))
			micro = "<br><img src="+'\\'+"\"" + GenererSite.gererPieceJointe(q.getCheminMicroImage(), cheminDossier,true) +'\\'+"\"/>";

		sRet += "\tquestion : \"" + purification(q.getHtmlEnonce())+micro + "\",\n";
		sRet += "\tdifficulte: " + q.getDifficulte().getIdDifficulte() + ",\n";
		if ((!(q.getCheminPJ().equals("null")))&&q.getCheminPJ()!=null && q.getCheminPJ()!="")
		sRet += "\tlink : \"" +gererPieceJointe(q.getCheminPJ(), cheminDossier,false)+"\",\n";

		if (q.getTypeQuestion()=='Q') sRet += ecritureRcm  (q.getLstReponse(),cheminDossier,q);
		if (q.getTypeQuestion()=='E') sRet += ecritureRElim(q.getLstReponse(),cheminDossier,q);
		if (q.getTypeQuestion()=='A') sRet += ecritureRAsso(q.getLstReponse(),cheminDossier,q);
		sRet += "\tfeedback: \""+purificationFeedback(q.getExplication())+"\",\n";
		sRet += "\tnbPoint: " + q.getPoints()+",\n";
		sRet += "\ttemps  : " + q.getTemps();
		return sRet+"}";
	}

	public static void creerVariableJS(String cheminDossier, Questionnaire quest, HashMap<Question, Notion> hashQuestions)
	{
		try
		{
			PrintWriter pw = new PrintWriter(new FileOutputStream("./src/prominfo/ressources/js/variable.js"));
			pw.println("const ressource = \""+purification(quest.getRessource().getNom())+"\";");
			pw.println("const titre = \""+purification(quest.getTitre())+"\";");
			pw.println("const estChrono = "+quest.getEstChrono()+";");

			pw.println("const questions = [");
			Set<Question> questions = hashQuestions.keySet();
			int cpt=0;
			for (Question question : questions)
			{
				pw.print(GenererSite.ecritureQuestion(question,hashQuestions.get(question), cheminDossier));
				if (cpt<hashQuestions.size()-1) pw.println(",");
				else pw.println("];");
				cpt++;
			}

			pw.close();
		}
		catch (Exception e) { e.printStackTrace(); }
	}

	public static void merge(String[] files, String outFile)
	{
		try
		{
			OutputStream out = new FileOutputStream(outFile);
			byte[] buf = new byte[1024];
			for (String file : files)
			{
				InputStream in = new FileInputStream(file);
				int b = 0;
				while ((b = in.read(buf)) >= 0)
					out.write(buf, 0, b);
				in.close();
			}

			out.close();
		}
		catch (Exception e) { e.printStackTrace(); }
	}

	public static void creerSite(String chemin, Questionnaire quest, HashMap<Question, Notion> hashQuestions)
	{
		try
		{
			new File(chemin+"/ressources").mkdirs();

			Files.copy((new File("./src/prominfo/ressources/js/style.css").toPath()), (new File(chemin+"/style.css").toPath()), StandardCopyOption.REPLACE_EXISTING);
			Files.copy((new File("./src/prominfo/ressources/js/index.html").toPath()),(new File(chemin+ "/index.html").toPath()),StandardCopyOption.REPLACE_EXISTING);

			creerVariableJS(chemin, quest, hashQuestions);
			GenererSite.merge(new String[] {"./src/prominfo/ressources/js/variable.js","./src/prominfo/ressources/js/script.js"},chemin +"/script.js");
		}
		catch (Exception e) { e.printStackTrace();}
	}
}
package prominfo.metier;

import prominfo.metier.ModelReponses.Reponse;

import java.util.List;
import java.util.ArrayList;

public class Ressource implements Comparable<Ressource>
{
	public static int nbRessources = 0;

	private int code;

	private String nom;

	private List<Notion> lstNotions;

	public Ressource( int code, String nom )
	{
		this.code = code;
		this.nom  = nom;
		this.lstNotions = new ArrayList<Notion>();
	}

	// Getters et Setters
	public String getNom() { return this.nom; }
	public void setNom(String nom) { this.nom = nom; }

	public int getCode() { return this.code; }
	public void setCode(int code) { this.code = code; }

	public List<Notion> getLstNotions() { return new ArrayList<Notion>(this.lstNotions); }
	public void setlstNotions(List<Notion> lstNotions) { this.lstNotions = lstNotions; }

	public Notion getNotion(int i) { return this.lstNotions.get(i); }
	public void setNotion(int i, Notion n) { this.lstNotions.remove(i); this.lstNotions.add(i, n); }

	//Méthode de tri
	public int compareTo(Ressource r)
	{
		return this.code - r.code;
	}

	// Méthodes de création
	public Notion creerNotion(String nom)
	{
		Notion n = new Notion(nom);
		this.lstNotions.add(n);

		return n;
	}

	public Question creerQuestion(Notion n, char type, String enonce, Difficulte diff, double pts, int temps, String cheminPJ, String explication)
	{
		return n.creerQuestion(type, enonce, diff, pts, temps, cheminPJ, explication);
	}

	public Reponse creerReponse(Notion n, Question q, String texte, boolean correct )
	{
		return n.creerReponse(q, texte, correct);
	}

	public Reponse creerReponse(Notion n, Question q, String texte, int ordre, double nbPts)
	{
		return n.creerReponse(q, texte, ordre, nbPts);
	}

	public Reponse creerReponse(Notion n, Question q, String texte, int iAsso, String lienFic)
	{
		return n.creerReponse(q, texte, iAsso, lienFic);
	}

	// Méthodes de suppression
	public void supprimerNotion(Notion n)
	{
		this.lstNotions.remove(n);
	}

	public void supprimerQuestion(Notion not, Question q)
	{
		not.supprimerQuestion(q);
	}

	// Méthodes d'affichage
	public String toString() { return this.nom; }
}
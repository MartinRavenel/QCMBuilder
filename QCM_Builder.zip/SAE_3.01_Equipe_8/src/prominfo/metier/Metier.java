package prominfo.metier;

import prominfo.metier.ModelReponses.*;

import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.text.Document;

public class Metier
{
	private Lecture lecture;

	private List<Ressource>     lstRessources;
	private List<Questionnaire> lstQuestionnaires;

	// Constructeur
	public Metier()
	{
		this.lstRessources     = new ArrayList<Ressource>();
		this.lstQuestionnaires = new ArrayList<Questionnaire>();

		this.lecture = new Lecture(this);

		this.viderTemp();
		this.viderDeleteFolder();
		this.lireTout();

		//this.toutString();
	}


	//Getters et Setters
	public List<Ressource> getLstRessources()
	{
		Collections.sort(this.lstRessources);
		return this.lstRessources;
	}

	public void setLstRessources(List<Ressource> lstRessources)
	{
		this.lstRessources = lstRessources;
	}

	public List<Questionnaire> getLstQuestionnaires()
	{
		return lstQuestionnaires;
	}

	public void setLstQuestionnaires(List<Questionnaire> lstQuestionnaires)
	{
		this.lstQuestionnaires = lstQuestionnaires;
	}

	// Méthodes de recherche
	public Ressource getRessourceParCode(int code)
	{
		for( Ressource r : this.lstRessources )
		{
			if( r.getCode() == code)
				return r;
		}
		return null;
	}
	public Ressource getRessourceParNotion(Notion notion)
	{
		for( Ressource r : this.lstRessources )
		{
			for ( Notion n : r.getLstNotions())
			{
				if (n == notion)
				{
					return r;
				}
			}
		}
		return null;
	}

	public void viderTemp()
	{
		this.lecture.viderTemp();
	}

	public void viderDeleteFolder()
	{
		this.lecture.viderDeleteFolder();
	}

	public Notion getNotionParNom(String nom)
	{
		for (Ressource r : this.lstRessources)
		{
			for (Notion n : r.getLstNotions())
			{
				if (n.getNom().equals(nom))
				{
					return n;
				}
			}
		}

		System.err.println("notion inexistante : " + nom);
		return null;
	}

	// Méthodes de création
	public Questionnaire creerTestQuestionnaire(String titre, Ressource r, Boolean estChrono, HashMap<Notion,LinkedList<Integer>> hashParams)
	{
		Questionnaire qs = new Questionnaire(titre, r, estChrono, hashParams);
		this.lstQuestionnaires.add(qs);
		return qs;
	}

	public Questionnaire creerQuestionnaire(String titre, int codeRess, Boolean estChrono,  HashMap<String,LinkedList<Integer>> hashParams )
	{
		HashMap<Notion,LinkedList<Integer>> hashParams2 = new HashMap<Notion,LinkedList<Integer>>();

		for (String key : hashParams.keySet())
		{
			Notion n = this.getNotionParNom(key);
			hashParams2.put(n, hashParams.get(key));
		}

		Questionnaire qs = new Questionnaire(titre, this.getRessourceParCode(codeRess) , estChrono, hashParams2);
		this.lstQuestionnaires.add(qs);
		return qs;
	}

	public void ecrireQuestionnaire(Questionnaire qs)
	{
		this.lecture.ecrireQuestionnaire(qs);
	}

	public Ressource creerRessource(int code, String nom )
	{
		Ressource r = new Ressource(code, nom);
		this.lstRessources.add(r);
		this.lecture.genererArborescence();
		return r;
	}

	public Notion creerNotion(Ressource r, String nom)
	{
		Notion n = r.creerNotion(nom);
		this.lecture.genererArborescence();
		return n;
	}

	public Question creerQuestion( Ressource r, Notion n, char type, String enonce, Difficulte diff, double pts, int temps, String cheminPJ, String explication)
	{
		Question temp = r.creerQuestion(n, type, enonce, diff, pts, temps, cheminPJ, explication);
		return temp;
	}

	public void ecrireQuestions(String cheminNotion, Question question, Document styleQuestion, HashMap<Reponse, Document> reponses)
	{
		this.lecture.ecrireQuestions(cheminNotion, question, styleQuestion, reponses);
	}

	public Reponse creerReponse( Ressource r, Notion n, Question q, String texte, boolean correct )
	{
		return r.creerReponse(n, q, texte, correct);
	}
	public Reponse creerReponse( Ressource r, Notion n, Question q, String texte, int ordre, double nbPts )
	{
		return r.creerReponse(n, q, texte, ordre, nbPts);
	}
	public Reponse creerReponse( Ressource r, Notion n, Question q, String texte, int iAsso, String lienfic)
	{
		return r.creerReponse(n, q, texte, iAsso, lienfic);
	}

	//Méthodes de modification
	public void modifierRessource(Ressource r, int nouveauCodeRessource, String nouveauNomRessource)
	{
		//Changer dans les fichiers
		this.lecture.modifierRessource(r, nouveauCodeRessource, nouveauNomRessource);
		r.setCode(nouveauCodeRessource);
		r.setNom(nouveauNomRessource);
	}

	public void modifierNotion(Notion n, String nouveauNomNotion)
	{
		//Changer dans les fichiers
		this.lecture.modifierNotion(n, nouveauNomNotion);
		n.setNom(nouveauNomNotion);
	}

	public void supprimerQuestionnaireParNotion(Notion notion)
	{
		for (Questionnaire q : this.lstQuestionnaires) 
		{
			for (Notion n : q.getHmParametres().keySet()) 
			{
				if(n == notion)
				{
					this.supprimerQuestionnaire(q);
				}
			}	
		}
	}

	// Méthodes de suppression
	public void supprimerQuestionnaire(Questionnaire q)
	{
		this.lecture.supprimerQuestionnaire(q);
		this.lstQuestionnaires.remove(q);
	}

	public void supprimerRessource(Ressource r)
	{
		this.lecture.supprimerRessources(r);
		this.lstRessources.remove(r);
	}

	public void supprimerNotion(Ressource r, Notion n)
	{
		this.supprimerQuestionnaireParNotion(n);
		this.lecture.supprimerNotion(n);
		r.supprimerNotion(n);
	}

	public void supprimerQuestion(Ressource r, Notion n, Question q)
	{
		this.lecture.supprimerQuestion(q);
		r.supprimerQuestion(n, q);
	}

	// Méthodes de génération du questionnaire
	public boolean genererQuestionnaire(String chemin, Questionnaire qs)
	{
		try
		{
			// Copie des paramètres
			HashMap<Notion, LinkedList<Integer>> copieParam = new HashMap<>();
			for (Map.Entry<Notion, LinkedList<Integer>> entry : qs.getHmParametres().entrySet())
			{
				Notion key = entry.getKey();
				LinkedList<Integer> diffs = new LinkedList<>(entry.getValue());
				copieParam.put(key, diffs);
			}
			//Création de la liste de questions
			HashMap<Question, Notion> hashQuestionsQs = this.genererLstQuestionsQs(copieParam);

			// Mélange de la liste
			List<Map.Entry<Question, Notion>> entries = new ArrayList<>(hashQuestionsQs.entrySet());
			Collections.shuffle(entries);

			HashMap<Question, Notion> hmMelange = new HashMap<>();
			for (Map.Entry<Question, Notion> entry : entries)
			{
				hmMelange.put(entry.getKey(), entry.getValue());
			}

			GenererSite.creerSite(chemin, qs, hmMelange);

		} catch (Exception e) {return false;}
		
		return true;
	}

	private HashMap<Question, Notion> genererLstQuestionsQs( HashMap<Notion,LinkedList<Integer>> hashParams ) // A changer
	{
		HashMap<Question, Notion> hashQuestionsQs = new HashMap<Question, Notion>();

		for (Notion n : hashParams.keySet())
		{
			List<Question> lstQuestionsNotion = n.getLstQuestions();
			Collections.shuffle(lstQuestionsNotion);

			for (Question q : lstQuestionsNotion)
			{
				for (Difficulte diff : Difficulte.values())
				{
					if( q.getDifficulte() == diff && hashParams.get(n).get(diff.getIdDifficulte()) > 0)
					{
						hashQuestionsQs.put(q, n);
						hashParams.get(n).set(diff.getIdDifficulte(), hashParams.get(n).get(diff.getIdDifficulte()) - 1);
					}
				}
			}
		}

		return hashQuestionsQs;
	}

	// Méthodes d'initialisation des données
	public void lireTout()
	{
		this.lecture.lireRessources();
		this.lecture.lireNotions();
		this.lecture.lireQuestions();
		this.lecture.lireQuestionnaire();
	}

	// Méthodes d'affichage
	public void toutString()
	{
		for (Ressource r : this.lstRessources)
		{
			System.out.println(r);
			for (Notion n : r.getLstNotions())
			{
				System.out.println("\t" + n);
				for (Question q : n.getLstQuestions())
				{
					System.out.println("\t\t" + q.getEnonce());
					for (Reponse rep : q.getLstReponse())
					{
						System.out.println("\t\t- " + rep.getTexte());
					}
				}
			}
		}
		System.out.println("\n");
		for (Questionnaire questionnaire : lstQuestionnaires) {
			System.out.println(questionnaire);
		}
	}
}
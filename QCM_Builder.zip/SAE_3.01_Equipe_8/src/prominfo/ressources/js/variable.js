const ressource = "Init Dev";
const titre = "test final 2";
const estChrono = false;
const questions = [
{
	notion :"Membres de classe et d'instance",
	question : "      <style>      <!--        p.default {          LeftIndent:0.0;          RightIndent:0.0;          FirstLineIndent:0.0;        }      -->    </style>              <span style='font-size: 12pt; font-family: arial'>        Quelles       </span>      <span style='font-size: 12pt; font-family: arial'>        <u>différences</u>      </span>      <span style='font-size: 12pt; font-family: arial'>         distinguent un membre de       </span>      <span style='color: #6666ff; font-size: 12pt; font-family: arial'>        <b>classe</b>      </span>      <span style='color: #000000; font-size: 12pt; font-family: arial'>         d’un membre d’      </span>      <span style='color: #ff6666; font-size: 12pt; font-family: arial'>        <b>instance</b>      </span>      <span style='color: #000000; font-size: 12pt; font-family: arial'>         en Java ?      </span>      ",
	difficulte: 1,
	type : "QCM",
	answers : [
		{ text : "      <style>      <!--        p.default {          LeftIndent:0.0;          RightIndent:0.0;          FirstLineIndent:0.0;        }      -->    </style>              <span style='font-size: 12pt; font-family: arial'>        Un membre de       </span>      <span style='color: #6666ff; font-size: 12pt; font-family: arial'>        classe      </span>      <span style='color: #000000; font-size: 12pt; font-family: arial'>         utilise le mot-clé static      </span>      ", correct: true},
		{ text : "      <style>      <!--        p.default {          LeftIndent:0.0;          RightIndent:0.0;          FirstLineIndent:0.0;        }      -->    </style>              <span style='font-size: 12pt; font-family: arial'>        Un membre de       </span>      <span style='color: #6666ff; font-size: 12pt; font-family: arial'>        classe      </span>      <span style='color: #000000; font-size: 12pt; font-family: arial'>         est partagé entre tous les objets de la classe.      </span>      ", correct: true},
		{ text : "      <style>      <!--        p.default {          LeftIndent:0.0;          RightIndent:0.0;          FirstLineIndent:0.0;        }      -->    </style>              <span style='font-size: 12pt; font-family: arial'>        Un membre d’      </span>      <span style='color: #ff6666; font-size: 12pt; font-family: arial'>        instance      </span>      <span style='color: #000000; font-size: 12pt; font-family: arial'>         nécessite un objet pour être utilisé.      </span>      ", correct: true},
		{ text : "      <style>      <!--        p.default {          LeftIndent:0.0;          RightIndent:0.0;          FirstLineIndent:0.0;        }      -->    </style>              <span style='font-size: 12pt; font-family: arial'>        Un membre d’      </span>      <span style='color: #ff6666; font-size: 12pt; font-family: arial'>        instance      </span>      <span style='color: #000000; font-size: 12pt; font-family: arial'>         est partagé entre tous les objets de la classe.      </span>      ", correct: false}
	],
	feedback: "",
	nbPoint: 3.5,
	temps  : 30},
{
	notion :"Membres de classe et d'instance",
	question : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Quel attribut de ce diagramme est un membre de classe ?      </span>      <br><img src=\"./ressources/diag classe.png\"/>",
	difficulte: 0,
	link : "./ressources/diag classe.png",
	type : "QCM",
	answers : [
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>              </span>      <br><img src=\"./ressources/Capture d'écran 2025-01-10 131951.png\"/>", correct: true},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>              </span>      <br><img src=\"./ressources/Capture d'écran 2025-01-10 132142.png\"/>", correct: false},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>              </span>      <br><img src=\"./ressources/Capture d'écran 2025-01-10 132120.png\"/>", correct: false}
	],
	feedback: "",
	nbPoint: 3.0,
	temps  : 50},
{
	notion :"Les conventions",
	question : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Associez chaque convention de nommage avec son type de composant.      </span>      ",
	difficulte: 1,
	type : "Association",
	answers : [
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Classes      </span>      ", numero: 2},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Constantes      </span>      ", numero: 1},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Commencer par une lettre majuscule et utiliser le PascalCase.      </span>      ", numero: 2},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Variables et méthodes      </span>      ", numero: 0},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Utiliser uniquement des lettres majuscules et des underscores (_).      </span>      ", numero: 1},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Commencer par une lettre minuscule et utiliser le camelCase.      </span>      ", numero: 0}
	],	feedback: "",
	nbPoint: 3.0,
	temps  : 30},
{
	notion :"Membres de classe et d'instance",
	question : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Associez chaque exemple avec le type de membre correspondant.      </span>      ",
	difficulte: 2,
	type : "Association",
	answers : [
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Une méthode getCounter() qui retourne un compteur partagé entre tous les objets.      </span>      ", numero: 0},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Une variable name définissant le nom unique pour chaque objet.      </span>      ", numero: 0},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Membre d’instance      </span>      ", numero: 1},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Membre de classe      </span>      ", numero: 1}
	],	feedback: "",
	nbPoint: 4.0,
	temps  : 45},
{
	notion :"Membres de classe et d'instance",
	question : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Quel comportement est correct concernant les membres d’instance en Java ?      </span>      ",
	difficulte: 1,
	type : "Elimination",
	answers : [
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Chaque objet possède sa propre copie.      </span>      ", position: 0, pointPerdus: 0.0},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Ils sont accessibles sans créer d’objet.      </span>      ", position: 2, pointPerdus: 1.0},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Ils peuvent être modifiés par des méthodes statiques.      </span>      ", position: 1, pointPerdus: 1.0},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Ils sont initialisés uniquement après la création d’un objet.      </span>      ", position: 3, pointPerdus: 1.0}
	],
	feedback: "Un membre d'instance est lié à une instance de classe",
	nbPoint: 3.0,
	temps  : 30},
{
	notion :"Membres de classe et d'instance",
	question : "      <style>      <!--      -->    </style>              Quels sont les cas d’utilisation typiques pour un membre de       <span style='color:       #6666ff'><b>classe</b>      </span>      <span style='color: #000000'>         en Java ?      </span>      ",
	difficulte: 2,
	type : "QCM",
	answers : [
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Définir une méthode utilitaire ne dépendant pas d’un objet.      </span>      ", correct: true},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Déclarer une constante accessible sans créer d’objet.      </span>      ", correct: true},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Stocker un compteur global commun à tous les objets.      </span>      ", correct: true},
		{ text : "      <style>      <!--      -->    </style>              <span style='color: #000000'>        Initialiser des valeurs spécifiques à chaque objet.      </span>      ", correct: false}
	],
	feedback: "",
	nbPoint: 4.0,
	temps  : 45}];

package prominfo.ihm.vueQuestionnaires;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.GridLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import java.util.HashMap;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;

import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

public class PanelCreationQuestionnaire2 extends JPanel implements ActionListener, MouseListener
{
	private FrameCreationQuestionnaire2 frameCreationQuestionnaire2;

	private JPanel panelGrille;
	private JPanel panelBas;
	private JPanel panelTextes;
	private JPanel panelBoutons;

	private JLabel lblSTF;
	private JLabel lblSF;
	private JLabel lblSM;
	private JLabel lblSD;
	private JLabel lblStot;

	private JTable tblQuestionnaire;

	private JScrollPane spTable;

	private String[]   tabEntetes = { "Notion", "", "Très Facile", "Facile", "Moyen", "Difficile", "Questions" };
	private String[]   tabNomNotions;
	private String[][] tabParamQuestionnaire;

	private JButton btnAjouter;
	private JButton btnRetour;

	public PanelCreationQuestionnaire2(FrameCreationQuestionnaire2 frameCreationQuestionnaire2, String[][] tabParamQuestionnaire)
	{
		this.frameCreationQuestionnaire2 = frameCreationQuestionnaire2;
		this.tabParamQuestionnaire		 = tabParamQuestionnaire;

		this.setLayout(new BorderLayout());

		/* ------------------------ */
		/*  Création des composants */
		/* ------------------------ */

		this.panelGrille  = new JPanel(new GridLayout(1, 1));
		this.panelBas     = new JPanel(new GridLayout(4, 1));
		this.panelTextes  = new JPanel(new GridLayout(1, 7));
		this.panelBoutons = new JPanel(new GridLayout(1, 6, 20, 20));

		this.lblSTF  = new JLabel("0", SwingConstants.CENTER);
		this.lblSF   = new JLabel("0", SwingConstants.CENTER);
		this.lblSM   = new JLabel("0", SwingConstants.CENTER);
		this.lblSD   = new JLabel("0", SwingConstants.CENTER);
		this.lblStot = new JLabel("Total : 0", SwingConstants.CENTER);

		this.tabNomNotions = this.frameCreationQuestionnaire2.getCtrl().getNotionsParRessource(this.frameCreationQuestionnaire2.getCodeRess());

		Object[][] data = new Object[tabNomNotions.length][tabEntetes.length + 1];

		for (int i = 0; i < this.tabNomNotions.length; i++)
		{
			data[i][0] = this.tabNomNotions[i];
			if (this.tabParamQuestionnaire != null && this.tabParamQuestionnaire[0][0].equals(this.tabNomNotions[0]))
			{
				int sommeTemp = 0;
				data[i][1] = true;
				for (int j = 2; j <= 5; j++)
				{
					data[i][j] = this.tabParamQuestionnaire[i][j - 1];
					sommeTemp += this.parseInteger(this.tabParamQuestionnaire[i][j - 1]);
				}
				data[i][6] = sommeTemp;
				if(sommeTemp == 0)
				{
					data[i][1] = false;
					for (int j = 2; j <= 5; j++)
					{
						data[i][j] = "";
					}
					data[i][6] = 0;
				}
			}
			else
			{
				data[i][1] = false;
				for (int j = 2; j <= 5; j++)
				{
					data[i][j] = "";
				}
				data[i][6] = 0;
			}
		}

		this.tblQuestionnaire = new JTable(data, this.tabEntetes)
		{
			public Class<?> getColumnClass(int column)
			{
				return column == 1 ? Boolean.class : Object.class;
			}

			public boolean isCellEditable(int row, int column)
			{
				if (column == 1)
				{
					return true;
				}

				if (column >= 2 && column <= 5)
				{
					Boolean estVerif = (Boolean) getValueAt(row, 1);
					return  estVerif != null && estVerif;
				}

				return false;
			}
		};
		majSommes();

		this.spTable = new JScrollPane(this.tblQuestionnaire);

		this.btnRetour  = new JButton("Retour");
		this.btnAjouter = new JButton("Valider");

		/* ------------------------------ */
		/*  Positionnement des composants */
		/* ------------------------------ */

		this.panelGrille.add(this.spTable);

		this.panelTextes.add(new JLabel("Nombre de questions"));
		this.panelTextes.add(new JLabel(""));
		this.panelTextes.add(this.lblSTF);
		this.panelTextes.add(this.lblSF);
		this.panelTextes.add(this.lblSM);
		this.panelTextes.add(this.lblSD);
		this.panelTextes.add(this.lblStot);

		this.panelBoutons.add(new JLabel());
		this.panelBoutons.add(new JLabel());
		this.panelBoutons.add(this.btnRetour);
		this.panelBoutons.add(this.btnAjouter);
		this.panelBoutons.add(new JLabel());
		this.panelBoutons.add(new JLabel());

		this.panelBas.add(this.panelTextes);
		this.panelBas.add(new JLabel());
		this.panelBas.add(this.panelBoutons);
		this.panelBas.add(new JLabel());

		this.add(this.panelGrille, BorderLayout.CENTER);
		this.add(this.panelBas   , BorderLayout.SOUTH);

		/* -------------------------- */
		/*  Activation des composants */
		/* -------------------------- */

		this.tblQuestionnaire.getModel().addTableModelListener(new TableChangeListener());

		this.btnAjouter.addActionListener(this);
		this.btnRetour.addActionListener(this);

		this.btnAjouter.addMouseListener(this);
		this.btnRetour.addMouseListener(this);

		this.setVisible(true);

	}

	private void majSommes() {
		int sommeTF = 0, sommeF = 0, sommeM = 0, sommeD = 0;
	
		for (int i = 0; i < tblQuestionnaire.getRowCount(); i++) 
		{
			sommeTF += parseInteger(tblQuestionnaire.getValueAt(i, 2));
			sommeF  += parseInteger(tblQuestionnaire.getValueAt(i, 3));
			sommeM  += parseInteger(tblQuestionnaire.getValueAt(i, 4));
			sommeD  += parseInteger(tblQuestionnaire.getValueAt(i, 5));
		}
	
		int sommeTot = sommeTF + sommeF + sommeM + sommeD;
	
		lblSTF.setText(String.valueOf(sommeTF));
		lblSF.setText(String.valueOf(sommeF));
		lblSM.setText(String.valueOf(sommeM));
		lblSD.setText(String.valueOf(sommeD));
		lblStot.setText("Total : " + sommeTot);
	}

	private class TableChangeListener implements TableModelListener
	{
		private boolean estMAJ = false;

		public void tableChanged(TableModelEvent e)
		{
			if (estMAJ) { return; }

			try
			{
				estMAJ = true;

				int column = e.getColumn();
				int row    = e.getFirstRow();
	
				if (column == 1)
				{ 
					Boolean estVerif = (Boolean) tblQuestionnaire.getValueAt(row, 1);
					if (estVerif != null && estVerif)
					{
						int[] maxParDiff = frameCreationQuestionnaire2.getCtrl().getMaxDiffsParNotion(tabNomNotions[row]);
						for (int j = 2; j <= 5; j++)
						{
							tblQuestionnaire.setValueAt(maxParDiff[j - 2], row, j);
						}
					}
					else
					{
						for (int j = 2; j <= 5; j++)
						{
							tblQuestionnaire.setValueAt("", row, j);
						}
					}
				}

				if (column >= 2 && column <= 5)
				{
					int maxDiff = frameCreationQuestionnaire2.getCtrl().getMaxDiffsParNotion(tabNomNotions[row])[column - 2];
					int valEntrante = parseInteger(tblQuestionnaire.getValueAt(row, column));
	
					if (valEntrante > maxDiff)
					{
						JOptionPane.showMessageDialog
						(
							null,
							"La valeur entrée dépasse le maximum autorisé (" + maxDiff + "). Elle a été ajustée.",
							"Erreur de validation",
							JOptionPane.ERROR_MESSAGE
						);

						tblQuestionnaire.setValueAt(maxDiff, row, column);
					}
				}

				for (int i = 0; i < tblQuestionnaire.getRowCount(); i++)
				{
					int sommeNotion = parseInteger(tblQuestionnaire.getValueAt(i, 2))
									+ parseInteger(tblQuestionnaire.getValueAt(i, 3))
									+ parseInteger(tblQuestionnaire.getValueAt(i, 4))
									+ parseInteger(tblQuestionnaire.getValueAt(i, 5));
					tblQuestionnaire.setValueAt(sommeNotion, i, 6);
				}
		
				majSommes();
			}

			finally
			{
				estMAJ = false;
			}
		}
	}

	private int parseInteger(Object valeur)
	{
		try
		{
			return valeur == null || valeur.toString().isEmpty() ? 0 : Integer.parseInt(valeur.toString());
		}

		catch (NumberFormatException e)
		{
			return 0;
		}
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == this.btnRetour)
		{
			String nomRess = null;
			int i = 0;
			for (String cr : this.frameCreationQuestionnaire2.getCtrl().getCodesRessources())
			{
				if (Integer.parseInt(cr) == this.frameCreationQuestionnaire2.getCodeRess())
				{
					nomRess = this.frameCreationQuestionnaire2.getCtrl().getNomsRessources()[i];
				}
				i++;
			}
			String estChrono;
			if( this.frameCreationQuestionnaire2.getEstChrono() == true)
			{
				estChrono = "Oui";
			}
			else
			{
				estChrono = "Non";
			}
			new FrameCreationQuestionnaire(this.frameCreationQuestionnaire2.getCtrl(), this.frameCreationQuestionnaire2.getGrilleDonneesQuestionnaires(), this.frameCreationQuestionnaire2.getTitre(), nomRess, estChrono, this.tabParamQuestionnaire);
			this.frameCreationQuestionnaire2.dispose();
		}

		if (e.getSource() == this.btnAjouter)
		{
			// Génération du questionnaire
			HashMap<String, LinkedList<Integer>> hmTableau = new HashMap<String, LinkedList<Integer>>();

			LinkedList<Integer> lstDifficultes = new LinkedList<Integer>();
			boolean estValide = false;

			for (int i = 0; i < this.tblQuestionnaire.getRowCount(); i++)
			{
				if ((boolean) this.tblQuestionnaire.getValueAt(i, 1))
				{
					estValide = true;
					lstDifficultes = new LinkedList<Integer>();
					for (int j = 2; j <= 5; j++)
					{
						lstDifficultes.add(parseInteger(this.tblQuestionnaire.getValueAt(i, j)));
					}

					hmTableau.put(this.tabNomNotions[i], lstDifficultes);
				}
				
			}
			if (estValide)
			{
				if (!this.frameCreationQuestionnaire2.getCtrl().estUniqueQuestionnaire(this.frameCreationQuestionnaire2.getAncienTitre()) && !this.frameCreationQuestionnaire2.getAncienTitre().equals(""))
				{
					this.frameCreationQuestionnaire2.getCtrl().supprimerQuestionnaire(this.frameCreationQuestionnaire2.getAncienTitre());
					this.frameCreationQuestionnaire2.getCtrl().ecrireQuestionnaire(this.frameCreationQuestionnaire2.getCtrl().creerQuestionnaire(this.frameCreationQuestionnaire2.getTitre(), this.frameCreationQuestionnaire2.getCodeRess(), this.frameCreationQuestionnaire2.getEstChrono(), hmTableau));
					JOptionPane.showMessageDialog(this, "Votre questionnaire a été modifié avec succès !");
				}
				else
				{
					this.frameCreationQuestionnaire2.getCtrl().ecrireQuestionnaire(this.frameCreationQuestionnaire2.getCtrl().creerQuestionnaire(this.frameCreationQuestionnaire2.getTitre(), this.frameCreationQuestionnaire2.getCodeRess(), this.frameCreationQuestionnaire2.getEstChrono(), hmTableau));
					JOptionPane.showMessageDialog(this, "Votre questionnaire a été créé avec succès !");
				}
				
				this.frameCreationQuestionnaire2.getGrilleDonneesQuestionnaires().majGrille();

				
				this.frameCreationQuestionnaire2.dispose();
			}
			else
			{
				JOptionPane.showMessageDialog(this, "Veuillez sélectionner au moins une notion !");
			}
		}
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnAjouter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnRetour.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnAjouter.setCursor(Cursor.getDefaultCursor());
		this.btnRetour.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}
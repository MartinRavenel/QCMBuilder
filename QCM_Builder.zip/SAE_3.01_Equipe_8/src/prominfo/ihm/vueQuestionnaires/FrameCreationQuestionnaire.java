package prominfo.ihm.vueQuestionnaires;

import prominfo.Controleur;

import javax.swing.JFrame;

public class FrameCreationQuestionnaire extends JFrame
{
	private Controleur ctrl;

	private GrilleDonneesQuestionnaires grilleDonneesQuestionnaires;

	private PanelCreationQuestionnaire  panelCreationQuestionnaire;

	private String ancienTitre = "";

	public FrameCreationQuestionnaire(Controleur ctrl, GrilleDonneesQuestionnaires grilleDonneesQuestionnaires)
	{
		this.ctrl = ctrl;
		this.grilleDonneesQuestionnaires = grilleDonneesQuestionnaires;

		this.setTitle("Création d'un questionnaire");
		this.setSize(900, 350);
		this.setLocationRelativeTo(panelCreationQuestionnaire);

		this.panelCreationQuestionnaire = new PanelCreationQuestionnaire(this);

		this.add(this.panelCreationQuestionnaire);

		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		this.setVisible(true);
	}

	public FrameCreationQuestionnaire(Controleur ctrl, GrilleDonneesQuestionnaires grilleDonneesQuestionnaires, String titre, String nomRessource, String estChrono, String[][] tabParamQuestionnaire)
	{
		this.ctrl = ctrl;
		this.grilleDonneesQuestionnaires = grilleDonneesQuestionnaires;
		this.ancienTitre 				 = titre;

		this.setTitle("Modification d'un questionnaire");
		this.setSize(900, 350);
		this.setLocationRelativeTo(panelCreationQuestionnaire);

		this.panelCreationQuestionnaire = new PanelCreationQuestionnaire(this, titre, nomRessource, estChrono, tabParamQuestionnaire);

		this.add(this.panelCreationQuestionnaire);

		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		this.setVisible(true);
	}

	public Controleur getCtrl()
	{
		return this.ctrl;
	}

	public GrilleDonneesQuestionnaires getGrilleDonneesQuestionnaires()
	{
		return this.grilleDonneesQuestionnaires;
	}

	public String getAncienTitre()
	{
		return this.ancienTitre;
	}
}
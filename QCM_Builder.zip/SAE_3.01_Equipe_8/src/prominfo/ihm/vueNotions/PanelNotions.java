package prominfo.ihm.vueNotions;

import prominfo.ihm.vueAccueil.FrameAccueil;
import prominfo.ihm.vueRessources.FrameRessources;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class PanelNotions extends JPanel implements ActionListener, MouseListener
{
	private FrameNotions frameNotions;

	private GrilleDonneesNotions grilleDonneesNotions;

	private JPanel panelTitre;
	private JPanel panelGrille;
	private JPanel panelBouton;

	private GridBagConstraints gbcTableau;
	private GridBagConstraints gbcBouton;
	private GridBagConstraints gbcTitre;

	private JButton btnAccueil;
	private JButton btnAjouterNotion;
	private JButton btnRetour;

	public PanelNotions(FrameNotions frameNotions)
	{
		this.frameNotions  = frameNotions;

		this.setLayout(new BorderLayout());

		/* ------------------------ */
		/*  Création des composants */
		/* ------------------------ */

		this.panelTitre  = new JPanel(new GridBagLayout());
		this.panelGrille = new JPanel(new GridBagLayout());
		this.panelBouton = new JPanel(new GridBagLayout());

		this.grilleDonneesNotions = new GrilleDonneesNotions(this.frameNotions.getCtrl(), this.frameNotions.getCodeRess(), this.frameNotions.getFrameRessources(), this.frameNotions);

		this.gbcTableau = new GridBagConstraints();
		this.gbcBouton  = new GridBagConstraints();
		this.gbcTitre   = new GridBagConstraints();

		this.gbcTitre.insets    = new Insets(25, 700, 0, 575);
		this.gbcTitre.fill      = GridBagConstraints.BOTH;

		this.gbcTitre.weightx   = 1.0;
		this.gbcTitre.weighty   = 1.0;

		this.gbcTableau.insets  = new Insets(25, 200, 50, 200);
		this.gbcTableau.fill    = GridBagConstraints.BOTH;

		this.gbcTableau.weightx = 1.0;
		this.gbcTableau.weighty = 1.0;

		this.gbcBouton.insets   = new Insets(0, 250, 50, 250);
		this.gbcBouton.fill     = GridBagConstraints.BOTH;

		this.gbcBouton.weightx  = 1.0;
		this.gbcBouton.weighty  = 1.0;

		this.btnAccueil = new JButton(new ImageIcon("./src/prominfo/ressources/images/accueil.png"));
		this.btnAccueil.setPreferredSize(new Dimension(100, 100));
		this.btnAccueil.setBorderPainted(false);
		this.btnAccueil.setContentAreaFilled(false);

		this.btnAjouterNotion = new JButton("Ajouter");
		this.btnAjouterNotion.setPreferredSize(new Dimension(50, 50));

		this.btnRetour = new JButton("Retour");
		this.btnRetour.setPreferredSize(new Dimension(50, 50));

		/* ------------------------------ */
		/*  Positionnement des composants */
		/* ------------------------------ */

		this.panelTitre.add(this.btnAccueil);
		this.panelTitre.add(new JLabel((new ImageIcon("./src/prominfo/ressources/images/notions.png"))), gbcTitre, JLabel.CENTER);

		this.panelGrille.add(new JScrollPane(this.grilleDonneesNotions.getTable()), gbcTableau);

		this.panelBouton.add(this.btnRetour, gbcBouton);
		this.panelBouton.add(this.btnAjouterNotion, gbcBouton);

		this.add(this.panelTitre , BorderLayout.NORTH );
		this.add(this.panelGrille, BorderLayout.CENTER);
		this.add(this.panelBouton, BorderLayout.SOUTH );

		/* -------------------------- */
		/*  Activation des composants */
		/* -------------------------- */

		this.btnAccueil.addActionListener(this);
		this.btnAjouterNotion.addActionListener(this);
		this.btnRetour.addActionListener(this);

		this.btnAccueil.addMouseListener(this);
		this.btnAjouterNotion.addMouseListener(this);
		this.btnRetour.addMouseListener(this);
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == this.btnAccueil)
		{
			for( int i = 0; i < FrameNotions.getFrames().length; i++ ) { FrameNotions.getFrames()[i].dispose(); }
			new FrameAccueil(this.frameNotions.getCtrl());
		}

		if (e.getSource() == this.btnAjouterNotion)
		{
			new FrameCreationNotion(this.frameNotions.getCtrl(), this.grilleDonneesNotions, Integer.parseInt(this.frameNotions.getCodeRess()));
		}

		if (e.getSource() == this.btnRetour)
		{
			new FrameRessources(this.frameNotions.getCtrl());
			this.frameNotions.dispose();
		}
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnAccueil.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnAjouterNotion.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnRetour.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnAccueil.setCursor(Cursor.getDefaultCursor());
		this.btnAjouterNotion.setCursor(Cursor.getDefaultCursor());
		this.btnRetour.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}
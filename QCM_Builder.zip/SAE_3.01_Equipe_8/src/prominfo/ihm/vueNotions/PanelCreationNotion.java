package prominfo.ihm.vueNotions;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.GridLayout;

import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelCreationNotion extends JPanel implements ActionListener, MouseListener
{
	private FrameCreationNotion frameCreationNotion;

	private JPanel panelNom;
	private JPanel panelBouton;

	private JTextField txtNotion;

	private JButton btnValider;
	private JButton btnAnnuler;

	public PanelCreationNotion(FrameCreationNotion frameCreationNotion)
	{
		this.frameCreationNotion = frameCreationNotion;

		this.setLayout(new GridLayout(5, 1));

		/* ------------------------ */
		/*  Création des composants */
		/* ------------------------ */

		this.panelNom    = new JPanel (new GridLayout(1, 3));
		this.panelBouton = new JPanel (new GridLayout(1, 5));

		this.txtNotion   = new JTextField(15);
		this.txtNotion.setBackground(Color.WHITE);
		this.txtNotion.setEnabled(true);
		if (this.frameCreationNotion.getNomNotion() != null)
		{
			this.txtNotion.setText(this.frameCreationNotion.getNomNotion());
		}
		this.btnValider  = new JButton("Valider");
		this.btnAnnuler  = new JButton("Annuler");

		/* ------------------------------ */
		/*  Positionnement des composants */
		/* ------------------------------ */

		if (!this.frameCreationNotion.getNomNotion().equals(""))
		{
			this.panelNom.add(new JLabel("Nouveau nom : ", JLabel.RIGHT));
		}
		else
		{
			this.panelNom.add(new JLabel("Nom : ", JLabel.RIGHT));
		}
		this.panelNom.add(this.txtNotion);
		this.panelNom.add(new JLabel());

		this.panelBouton.add(new JLabel());
		this.panelBouton.add(this.btnAnnuler);
		this.panelBouton.add(new JLabel());
		this.panelBouton.add(this.btnValider);
		this.panelBouton.add(new JLabel());

		this.add(new JLabel());
		this.add(this.panelNom);
		this.add(new JLabel());
		this.add(this.panelBouton);
		this.add(new JLabel());

		/* -------------------------- */
		/*  Activation des composants */
		/* -------------------------- */

		this.txtNotion.addActionListener(this);

		this.btnValider.addActionListener(this);
		this.btnAnnuler.addActionListener(this);

		this.btnValider.addMouseListener(this);
		this.btnAnnuler.addMouseListener(this);
	}

	public void actionPerformed(ActionEvent e)
	{

		if (e.getSource() == this.btnValider)
		{
			if (this.txtNotion.getText().isBlank())
			{
				JOptionPane.showMessageDialog(this, "Veuillez entrer un nom pour votre notion", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
			if (!this.frameCreationNotion.getNomNotion().equals(this.txtNotion.getText()) && !this.frameCreationNotion.getCtrl().estUniqueNotion(this.txtNotion.getText()))
			{
				JOptionPane.showMessageDialog(this, "Le nom doit être unique, celui choisi existe déjà", "Erreur", JOptionPane.ERROR_MESSAGE);
			}
			else
			{
				String codeRess = String.valueOf(this.frameCreationNotion.getCodeRessource());

				if (this.frameCreationNotion.getNomNotion().equals(""))
				{
					JOptionPane.showMessageDialog(this, "Notion créée avec succès !", "Notion " + this.txtNotion.getText(), JOptionPane.PLAIN_MESSAGE);
					this.frameCreationNotion.getCtrl().creerNotion(codeRess, this.txtNotion.getText());
				}
				else
				{
					this.frameCreationNotion.getCtrl().modifierNotion(this.frameCreationNotion.getNomNotion(), this.txtNotion.getText());
					JOptionPane.showMessageDialog(this, "Notion modifiée avec succès !", "Notion " + this.txtNotion.getText(), JOptionPane.PLAIN_MESSAGE);
				}

				this.frameCreationNotion.getGrilleDonneesNotions().majGrille();
				this.frameCreationNotion.dispose();
			}
		}

		if (e.getSource() == this.btnAnnuler)
		{
			this.frameCreationNotion.dispose();
		}
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnValider.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		this.btnAnnuler.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnValider.setCursor(Cursor.getDefaultCursor());
		this.btnAnnuler.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}

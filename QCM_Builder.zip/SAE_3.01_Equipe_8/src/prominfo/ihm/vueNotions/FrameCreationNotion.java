package prominfo.ihm.vueNotions;

import prominfo.Controleur;

import javax.swing.JFrame;

public class FrameCreationNotion extends JFrame
{
	private Controleur ctrl;

	private GrilleDonneesNotions grilleDonneesNotions;

	private PanelCreationNotion  panelCreationNotion;

	private int codeRessource;

	private String nomNotion = "";

	public FrameCreationNotion(Controleur ctrl, GrilleDonneesNotions grilleDonneesNotions, int codeRessource)
	{
		this.ctrl                 = ctrl;
		this.grilleDonneesNotions = grilleDonneesNotions;
		this.codeRessource        = codeRessource;

		this.setTitle("Création d'une notion");
		this.setSize(750, 250);
		this.setLocationRelativeTo(panelCreationNotion);

		this.panelCreationNotion = new PanelCreationNotion(this);

		this.add(panelCreationNotion);

		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		this.setVisible(true);
	}

	public FrameCreationNotion(Controleur ctrl, GrilleDonneesNotions grilleDonneesNotions, int codeRessource, String nomNotion)
	{
		this.ctrl                 = ctrl;
		this.grilleDonneesNotions = grilleDonneesNotions;
		this.codeRessource        = codeRessource;
		this.nomNotion			  = nomNotion;

		this.setTitle("Modification d'une notion");
		this.setSize(750, 250);
		this.setLocationRelativeTo(panelCreationNotion);

		this.panelCreationNotion = new PanelCreationNotion(this);

		this.add(panelCreationNotion);

		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		this.setVisible(true);
	}

	public Controleur getCtrl()
	{
		return this.ctrl;
	}

	public int getCodeRessource()
	{
		return this.codeRessource;
	}

	public GrilleDonneesNotions getGrilleDonneesNotions()
	{
		return this.grilleDonneesNotions;
	}
	
	public String getNomNotion()
	{
		return this.nomNotion;
	}
}

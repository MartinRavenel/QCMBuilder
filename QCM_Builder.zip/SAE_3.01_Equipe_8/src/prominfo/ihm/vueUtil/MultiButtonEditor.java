package prominfo.ihm.vueUtil;

import java.awt.Component;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractCellEditor;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;

import javax.swing.table.TableCellEditor;

import prominfo.ihm.vueNotions.GrilleDonneesNotions;
import prominfo.ihm.vueQuestionnaires.GrilleDonneesQuestionnaires;
import prominfo.ihm.vueQuestions.GrilleDonneesQuestions;
import prominfo.ihm.vueRessources.GrilleDonneesRessources;

public class MultiButtonEditor extends AbstractCellEditor implements TableCellEditor, ActionListener
{
	private GrilleDonneesModel grilleDonneesModel;

	private JPanel panelBtn;

	private JTable tblBtn;

	private int ligne;

	private JButton btnModifier;
	private JButton btnSupprimer;

	private int indexEnonce;

	public MultiButtonEditor(GrilleDonneesModel grilleDonneesModel)
	{
		this.grilleDonneesModel  = grilleDonneesModel;

		this.indexEnonce  = this.grilleDonneesModel.getIndexEnonce();

		this.panelBtn     = new JPanel(new FlowLayout());

		this.btnModifier  = new JButton(new ImageIcon("./src/prominfo/ressources/images/modifier.png" ));
		this.btnSupprimer = new JButton(new ImageIcon("./src/prominfo/ressources/images/supprimer.png"));

		this.btnModifier.setBorderPainted(false);
		this.btnModifier.setContentAreaFilled(false);
		this.btnSupprimer.setBorderPainted(false);
		this.btnSupprimer.setContentAreaFilled(false);

		this.panelBtn.add(btnModifier);
		this.panelBtn.add(btnSupprimer);

		this.btnModifier.addActionListener(this);
		this.btnSupprimer.addActionListener(this);
	}

	public Component getTableCellEditorComponent(JTable tblBtn, Object value, boolean isSelected, int row, int column)
	{
		this.tblBtn = tblBtn;
		this.ligne = row;

		return panelBtn;
	}

	public Object getCellEditorValue()
	{
		return null;
	}

	public void actionPerformed(ActionEvent e)
	{
		if ( e.getSource() == this.btnModifier )
		{
			if (tblBtn != null)
			{
				tblBtn.getValueAt(ligne, this.indexEnonce);

				grilleDonneesModel.modifier(ligne);
			}

			this.stopCellEditing();
		}

		if ( e.getSource() == this.btnSupprimer )
		{
			if (tblBtn != null)
			{
				if (grilleDonneesModel instanceof GrilleDonneesRessources) 
				{
					if (JOptionPane.showConfirmDialog(null, "Etes-vous sûr de vouloir supprimer cette ressource ?", "Suppression", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
					{
						grilleDonneesModel.supprimer(ligne);
					}
				} 
				else if (grilleDonneesModel instanceof GrilleDonneesNotions) 
				{
					if (JOptionPane.showConfirmDialog(null, "Etes-vous sûr de vouloir supprimer cette notion ?", "Suppression", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
					{
						grilleDonneesModel.supprimer(ligne);
					}
				} 
				else if (grilleDonneesModel instanceof GrilleDonneesQuestions) 
				{
					if (JOptionPane.showConfirmDialog(null, "Etes-vous sûr de vouloir supprimer cette question ?", "Suppression", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
					{
						grilleDonneesModel.supprimer(ligne);
					}
				} 
				else if (grilleDonneesModel instanceof GrilleDonneesQuestionnaires) 
				{
					if (JOptionPane.showConfirmDialog(null, "Etes-vous sûr de vouloir supprimer ce questionnaire ?", "Suppression", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
					{
						grilleDonneesModel.supprimer(ligne);
					}
				}

				this.stopCellEditing();
			}
		}
	}
}

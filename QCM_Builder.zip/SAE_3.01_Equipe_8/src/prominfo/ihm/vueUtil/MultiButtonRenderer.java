package prominfo.ihm.vueUtil;

import java.awt.Component;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTable;

import javax.swing.table.TableCellRenderer;

public class MultiButtonRenderer extends JPanel implements TableCellRenderer 
{
	private JButton btnModifier;
	private JButton btnSupprimer;

	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
	{
		this.removeAll();

		this.btnModifier  = new JButton(new ImageIcon("./src/prominfo/ressources/images/modifier.png" ));
		this.btnSupprimer = new JButton(new ImageIcon("./src/prominfo/ressources/images/supprimer.png"));

		this.btnModifier.setBorderPainted(false);
		this.btnModifier.setContentAreaFilled(false);
		this.btnSupprimer.setBorderPainted(false);
		this.btnSupprimer.setContentAreaFilled(false);

		this.add(btnModifier);
		this.add(btnSupprimer);

		return this;
	}
}

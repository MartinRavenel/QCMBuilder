package prominfo.ihm.vueQuestions.ElementCreationQuestion;

import prominfo.Controleur;

import prominfo.ihm.vueQuestions.ElementCreationQuestion.panelsReponses.ReponseAssociation;
import prominfo.ihm.vueQuestions.ElementCreationQuestion.panelsReponses.ReponseElimination;
import prominfo.ihm.vueQuestions.ElementCreationQuestion.panelsReponses.ReponseQCM;

import java.awt.GridLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.ArrayList;

import javax.swing.JPanel;

public class PanelLstReponse extends JPanel implements ActionListener
{
	@SuppressWarnings("unused")
	private Controleur ctrl;

	private ArrayList<JPanel> lstPanel;

	private char typeQuestion;

	private int nbReponse;
	private String listeRep;

	public PanelLstReponse(Controleur ctrl, String listeRep, char type)
	{
		this.ctrl = ctrl;
		this.listeRep = listeRep;

		this.typeQuestion = type;
		this.nbReponse = 0;

		int numRep;
		if(listeRep != null)
		{
			numRep = getNbRep(listeRep, type);
		}
		else 
		{
			numRep = 2;
		}

		this.clearLst();

		for (int i = 0; i < numRep; i++) 
		{
			this.addPanel();
		}
		
	}
	
	public static int getNbRep(String liste, char type)
	{
		switch (type) 
		{
			case 'A' -> 
			{
				return liste.split("\t").length / 2;
			}
			case 'E' -> 
			{	
				return liste.split("\t").length / 3;
			}
			case 'Q' -> 
			{
				return liste.split("\t").length / 2;
			}
		}
		return 0;
	}

	public void addPanel()
	{

		this.nbReponse++;

		this.setLayout(new GridLayout(this.nbReponse, 1, 5, 5));
		JPanel temp = new ReponseQCM(null, false);
	
		switch (this.typeQuestion)
		{
			case 'A' ->
			{
				String enonce1 = "", enonce2 = "";

				if(this.listeRep == null)
				{
					temp = new ReponseAssociation(null, null);
				}
				else
				{
					String[] tabPram = this.listeRep.split("\t");

					enonce1 = tabPram[(this.nbReponse - 1) * 2];
					enonce2 = tabPram[(this.nbReponse - 1) * 2 + 1];
					temp = new ReponseAssociation(enonce1, enonce2);
				}
				((ReponseAssociation)temp).getBtnDelete().addActionListener(this);
			}
			case 'E' ->
			{
				String enonce = "";
				int ordre = 0;
				double nbPts = 0;
				if(this.listeRep == null)
				{
					temp = new ReponseElimination(null, 0, 0, false);
				}
				else
				{
					String[] tabPram = this.listeRep.split("\t");
					enonce = tabPram[(this.nbReponse - 1) * 3];
					ordre = Integer.parseInt(tabPram[(this.nbReponse - 1) * 3 + 1]);
					nbPts = Double.parseDouble(tabPram[(this.nbReponse - 1) * 3 + 2]);
					temp = new ReponseElimination(enonce, nbPts, ordre, true);
					
				}

				((ReponseElimination)temp).getBtnDelete().addActionListener(this);
			}
			default  ->
			{
				String enonce = "";
				boolean correct = false;

				if(this.listeRep == null)
				{
					temp = new ReponseQCM(null, false);
				}
				else
				{
					String[] tabPram = this.listeRep.split("\t");
					enonce = tabPram[(this.nbReponse - 1) * 2 ];
					correct = Boolean.parseBoolean(tabPram[(this.nbReponse - 1) * 2 + 1]);
					temp = new ReponseQCM(enonce, correct);
				}
 				((ReponseQCM)temp).getBtnDelete().addActionListener(this);
			}
		}	

		this.add(temp);
		this.lstPanel.add(temp);

		this.revalidate();
		this.repaint();
	}

	public void addMultPanel()
	{
		JPanel temp;

		for (int i = 0; i < this.nbReponse; i++)
		{
			switch (this.typeQuestion)
			{
				case 'A' ->
				{
					temp = new ReponseAssociation(null, null);
					((ReponseAssociation)temp).getBtnDelete().addActionListener(this);
				}
				case 'E' ->
				{
					temp = new ReponseElimination(null, 0, 0, false);
					((ReponseElimination)temp).getBtnDelete().addActionListener(this);
				}
				case 'Q' ->
				{
					temp = new ReponseQCM(null, false);
					((ReponseQCM)temp).getBtnDelete().addActionListener(this);
				}
				default  ->
				{
					temp = null;
				}
			}

			this.add(temp);
			this.lstPanel.add(temp);

			this.revalidate();
			this.repaint();
		}
	}

	public void deletePanel(JPanel p)
	{
		this.nbReponse--;
		this.setLayout(new GridLayout(this.nbReponse, 1, 5, 5));
		this.lstPanel.remove(p);
		this.remove(p);

		this.revalidate();
		this.repaint();
	}

	public void actionPerformed(ActionEvent e) 
	{
		if(this.nbReponse > 2)
		{
			for (int i = 0; i < this.lstPanel.size(); i++)
			{
				switch (this.typeQuestion)
				{
					case 'A' ->
					{
						if(e.getSource() == ((ReponseAssociation)this.lstPanel.get(i)).getBtnDelete())
						{
							this.deletePanel(this.lstPanel.get(i));
							break;
						}
					}
					case 'E' ->
					{
						if(e.getSource() == ((ReponseElimination)this.lstPanel.get(i)).getBtnDelete())
						{
							this.deletePanel(this.lstPanel.get(i));
							break;
						}
					}
					case 'Q' ->
					{
						if(e.getSource() == ((ReponseQCM)this.lstPanel.get(i)).getBtnDelete())
						{
							this.deletePanel(this.lstPanel.get(i));
							break;
						}
					}
				}

				this.repaint();
			}
		}
	}

	public ArrayList<JPanel> getListPanels()
	{
		return this.lstPanel;
	}

	public JPanel getPanelReponse(int i)
	{
		return lstPanel.get(i);
	}

	public int getIndicePanelReponse(JPanel p)
	{
		return lstPanel.lastIndexOf(p);
	}

	public char getTypeQuestion()
	{
		return this.typeQuestion;
	}

	public void setTypeQuestion(char typeQuestion) 
	{
		this.typeQuestion = typeQuestion;
	}

	public void clearLst()
	{
		this.lstPanel = new ArrayList<JPanel>();
	}
}
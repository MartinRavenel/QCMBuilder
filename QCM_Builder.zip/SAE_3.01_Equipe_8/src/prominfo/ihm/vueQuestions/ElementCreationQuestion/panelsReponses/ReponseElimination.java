package prominfo.ihm.vueQuestions.ElementCreationQuestion.panelsReponses;

import prominfo.ihm.vueQuestions.styleComponents.IStyleEditor;
import prominfo.ihm.vueQuestions.styleComponents.PanelStyleEditor;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import javax.swing.text.rtf.RTFEditorKit;

public class ReponseElimination extends JPanel implements MouseListener, IStyleEditor, ActionListener
{
	private PanelStyleEditor panelStyleEditor;

	private JEditorPane epTxtArea;

	private JTextField txtOrdre;
	private JTextField txtNbPtsEnMoins;

	private JCheckBox cbBonneRep;

	private JButton btnDelete;

	private JLabel lblOrdre;
	private JLabel lblNbPointsEnMoins;

	public ReponseElimination(String enonce, double nbPts, int ordre, boolean modifier)
	{
		this.setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();

		JPanel panel    = new JPanel(new GridLayout(2, 1, 5, 5));

		this.btnDelete  = new JButton(new ImageIcon("./src/prominfo/ressources/images/supprimerRep.png"));
		this.btnDelete.setBorderPainted(false);
		this.btnDelete.setContentAreaFilled(false);

		this.epTxtArea  = new JEditorPane();
	
		this.cbBonneRep = new JCheckBox();
	
		this.lblOrdre   = new JLabel("Ordre d'élimination : ");
		this.lblNbPointsEnMoins = new JLabel("Points perdus : ");
	
		this.txtOrdre   = new JTextField();
		this.txtNbPtsEnMoins = new JTextField();

		if( modifier && (ordre == 0) )
		{
			this.cbBonneRep.setSelected(true);
			this.lblOrdre.setEnabled(false);
			this.lblNbPointsEnMoins.setEnabled(false);
			this.txtOrdre.setEnabled(false);
			this.txtNbPtsEnMoins.setEnabled(false);
		}

		this.txtOrdre.setText((Integer.toString(ordre)));
		this.txtNbPtsEnMoins.setText(Double.toString(nbPts));

		if(nbPts != 0)
			this.txtNbPtsEnMoins.setText(Double.toString(nbPts));

	
		this.cbBonneRep.addActionListener(this);

		this.epTxtArea.setContentType("text/rtf");
		this.epTxtArea.setEditorKit(new RTFEditorKit());

		this.panelStyleEditor = new PanelStyleEditor(this, enonce);

		panel.add(this.lblOrdre);
		panel.add(this.txtOrdre);
		panel.add(this.lblNbPointsEnMoins);
		panel.add(this.txtNbPtsEnMoins);

		this.txtNbPtsEnMoins.setMaximumSize(new Dimension(20, 30));

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 0.005;
		gbc.ipady   = 25;
		gbc.gridy   = 0;
		gbc.gridx   = 0;
		this.add(this.btnDelete, gbc);

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.ipady   = 67;
		gbc.weightx = 0.850;
		gbc.insets  = new Insets(2,5,2,0);
		gbc.gridy   = 0;
		gbc.gridx   = 1;
		this.add(new JScrollPane(this.epTxtArea), gbc);

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 0.095;
		gbc.ipady   = 40;
		gbc.gridy   = 0;
		gbc.gridx   = 2;
		this.add(panel, gbc);

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 0.05;
		gbc.ipady   = 40;
		gbc.gridy   = 0;
		gbc.gridx   = 3;
		this.add(this.cbBonneRep, gbc);

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 0.5;
		gbc.ipady   = 40;
		gbc.gridy   = 1;
		gbc.gridx   = 1;
		this.add(this.panelStyleEditor, gbc);

		this.btnDelete.addMouseListener(this);
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == this.cbBonneRep)
		{
			if (this.cbBonneRep.isSelected())
			{
				this.lblOrdre.setEnabled(false);
				this.lblNbPointsEnMoins.setEnabled(false);
				this.txtOrdre.setText("0");
				this.txtNbPtsEnMoins.setText("0");
				this.txtOrdre.setEnabled(false);
				this.txtNbPtsEnMoins.setEnabled(false);
			}
			else
			{
				this.lblOrdre.setEnabled(true);
				this.lblNbPointsEnMoins.setEnabled(true);
				this.txtOrdre.setText("");
				this.txtNbPtsEnMoins.setText("");
				this.txtOrdre.setEnabled(true);
				this.txtNbPtsEnMoins.setEnabled(true);
			}
		}
	}

	public String getContentTextArea()
	{
		try
		{
			return this.epTxtArea.getDocument().getText(0, this.epTxtArea.getDocument().getLength());
		}
		catch (Exception e)
		{
			System.out.println("document vide ou invalide");
		}

		return null;
	}

	public String getImage()
	{
		return this.panelStyleEditor.getImage();
	}

	public boolean getBonneRep()
	{
		return this.cbBonneRep.isSelected();
	}

	public JButton getBtnDelete()
	{
		return this.btnDelete;
	}

	public int getOrdre()
	{
		try
		{
			return Integer.parseInt(this.txtOrdre.getText());
		}
		catch (Exception e)
		{
			return -1;
		}
	}

	public double getNbPointsEnMoins()
	{
		try
		{
			return Double.parseDouble(this.txtNbPtsEnMoins.getText());
		}
		catch (Exception e)
		{
			return -1;
		}
	}

	@Override
	public JEditorPane getTexteAreaEditor()
	{
		return this.epTxtArea;
	}

	public void mouseEntered(MouseEvent e)
	{
		this.btnDelete.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.btnDelete.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e){}
	public void mousePressed (MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
}
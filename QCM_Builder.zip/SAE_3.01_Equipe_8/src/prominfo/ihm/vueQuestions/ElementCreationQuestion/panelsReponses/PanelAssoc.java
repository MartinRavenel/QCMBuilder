package prominfo.ihm.vueQuestions.ElementCreationQuestion.panelsReponses;

import prominfo.ihm.vueQuestions.styleComponents.IStyleEditor;
import prominfo.ihm.vueQuestions.styleComponents.PanelStyleEditor;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import javax.swing.text.rtf.RTFEditorKit;

public class PanelAssoc extends JPanel implements IStyleEditor
{
	private JEditorPane epTxtArea;

	private PanelStyleEditor panelStyleEditor;

	public PanelAssoc(String enonce)
	{
		this.setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();

		this.epTxtArea = new JEditorPane();

		this.epTxtArea.setContentType("text/rtf");
		this.epTxtArea.setEditorKit(new RTFEditorKit());

		this.panelStyleEditor = new PanelStyleEditor(this, enonce);

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.gridy   = 0;
		gbc.ipady   = 67;
		gbc.gridx   = 1;
		gbc.weighty = 0.8;
		gbc.insets  = new Insets(0,0,-8,0);
		this.add(new JScrollPane(this.epTxtArea), gbc);

		gbc.fill    = GridBagConstraints.HORIZONTAL;
		gbc.gridy   = 1;
		gbc.ipady   = 67;
		gbc.gridx   = 1;
		gbc.weighty = 0.2;
		this.add(this.panelStyleEditor, gbc);
	}

	@Override
	public JEditorPane getTexteAreaEditor() { return this.epTxtArea; }

	public String getImage() { return this.panelStyleEditor.getImage(); }
}
package prominfo.ihm.vueQuestions;

import prominfo.Controleur;
import prominfo.ihm.vueUtil.GrilleDonneesModel;
import prominfo.ihm.vueUtil.MultiButtonEditor;
import prominfo.ihm.vueUtil.MultiButtonRenderer;

import java.awt.Cursor;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JTable;

import javax.swing.table.DefaultTableModel;

public class GrilleDonneesQuestions extends GrilleDonneesModel implements MouseListener
{
	private Controleur ctrl;
	private FrameQuestions frameQuestions;

	private String[]   tabEntetes;
	private Object[][] tabDonnees;

	private String[][] tabQuestions;
	private String     nomNotion;

	private int indexEnonce;

	public GrilleDonneesQuestions(Controleur ctrl, FrameQuestions frameQuestions, String nomNotion)
	{
		this.ctrl      = ctrl;
		this.frameQuestions = frameQuestions;
		this.nomNotion = nomNotion;

		this.tblGrille = new JTable(this);

		this.majGrille();
	}

	public void majGrille()
	{
		this.tabQuestions = new String[this.ctrl.getQuestionsParNotion(this.nomNotion).length][3];

		this.setTabEntetes(new String[] { "Enoncé", "Difficulté", "Temps Estimé", "Actions" });
		this.tabEntetes  = this.getTabEntetes();
		this.indexEnonce = this.getIntColumn("Enoncé");

		this.setTabDonnees(new Object[this.tabQuestions.length][this.tabEntetes.length]);
		this.tabDonnees = this.getTabDonnees();

		this.tabQuestions = this.ctrl.getQuestionsParNotion(nomNotion);
		//Question : (0 = char type, 1 = String enonce, 2 = Difficulte diff,  3 = double pts , 4 = int tps, 5 = String cheminPJ, 6 = String explication, 7 = lstReponse)
		for (int i = 0; i < this.tabQuestions.length; i++)
		{
			this.tabDonnees[i][0] = tabQuestions[i][1];
			this.tabDonnees[i][1] = tabQuestions[i][2];
			this.tabDonnees[i][2] = tabQuestions[i][4];
			this.tabDonnees[i][3] = "Actions";
		}

		this.tblGrille.setModel(new DefaultTableModel(this.tabDonnees, this.tabEntetes));
		this.tblGrille.getColumn("Actions").setCellRenderer(new MultiButtonRenderer());
		this.tblGrille.getColumn("Actions").setCellEditor(new MultiButtonEditor(this));
		this.tblGrille.setRowHeight(40);

		this.tblGrille.addMouseListener(this);
		this.fireTableDataChanged();
	}


	public void modifier(int ligne)
	{
		new FrameCreationQuestion(ctrl, this.frameQuestions, this, this.tabQuestions[ligne][0].charAt(0), this.tabQuestions[ligne][1] , this.tabQuestions[ligne][2], this.tabQuestions[ligne][3], this.tabQuestions[ligne][4],this.tabQuestions[ligne][6], tabQuestions[ligne][7]);
	}

	@Override
	public void supprimer(int ligne)
	{
		this.ctrl.supprimerQuestion(this.nomNotion, ligne);
		this.majGrille();
	}

	public boolean isCellEditable(int row, int col)
	{
		for (int cpt = 0; cpt < this.tabEntetes.length; cpt++)
		{
			if (this.tabEntetes[cpt].equals("Actions"))
			{
				return col == cpt;
			}
		}

		return false;
	}

	public int getIndexEnonce()
	{
		return this.indexEnonce;
	}

	public void mouseEntered(MouseEvent e)
	{
		this.tblGrille.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.tblGrille.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked (MouseEvent e) {}
	public void mousePressed (MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
}
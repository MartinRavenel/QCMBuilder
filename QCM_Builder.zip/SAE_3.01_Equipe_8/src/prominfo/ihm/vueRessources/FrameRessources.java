package prominfo.ihm.vueRessources;

import prominfo.Controleur;

import javax.swing.JFrame;

public class FrameRessources extends JFrame
{
	private Controleur ctrl;

	private PanelRessources panelRessources;

	public FrameRessources(Controleur ctrl)
	{
		this.ctrl = ctrl;

		this.setTitle("QCM Builder");
		this.setSize(1800, 900);
		this.setLocationRelativeTo(panelRessources);

		this.panelRessources = new PanelRessources(this);

		this.add(panelRessources);

		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		this.setVisible(true);
	}

	public Controleur getCtrl()
	{
		return this.ctrl;
	}
}
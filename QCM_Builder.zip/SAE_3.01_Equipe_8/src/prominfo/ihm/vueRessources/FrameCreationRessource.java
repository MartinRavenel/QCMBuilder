package prominfo.ihm.vueRessources;

import prominfo.Controleur;

import javax.swing.JFrame;

public class FrameCreationRessource extends JFrame
{
	private Controleur ctrl;

	private GrilleDonneesRessources grilleDonneesRessources;

	private PanelCreationRessource  panelCreationRessource;

	private String codeRessource = "";
	private String nomRessource  = "";

	public FrameCreationRessource(Controleur ctrl, GrilleDonneesRessources grilleDonneesRessources)
	{
		this.ctrl = ctrl;
		this.grilleDonneesRessources = grilleDonneesRessources;

		this.setTitle("Création d'une ressource");
		this.setSize(900, 350);
		this.setLocationRelativeTo(panelCreationRessource);

		this.panelCreationRessource = new PanelCreationRessource(this);

		this.add(panelCreationRessource);

		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		this.setVisible(true);
	}

	public FrameCreationRessource(Controleur ctrl, GrilleDonneesRessources grilleDonneesRessources, String codeRessource, String nomRessource)
	{
		this.ctrl = ctrl;
		this.grilleDonneesRessources = grilleDonneesRessources;
		this.codeRessource 			 = codeRessource;
		this.nomRessource 			 = nomRessource;

		this.setTitle("Modification d'une ressource");
		this.setSize(900, 350);
		this.setLocationRelativeTo(panelCreationRessource);

		this.panelCreationRessource = new PanelCreationRessource(this);

		this.add(panelCreationRessource);

		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		this.setVisible(true);
	}

	public Controleur getCtrl()
	{
		return this.ctrl;
	}

	public GrilleDonneesRessources getGrilleDonneesRessources()
	{
		return this.grilleDonneesRessources;
	}

	public String getCodeRessource()
	{
		return this.codeRessource;
	}
	public String getNomRessource()
	{
		return this.nomRessource;
	}
}

package prominfo.ihm.vueRessources;

import prominfo.Controleur;

import prominfo.ihm.vueNotions.FrameNotions;

import prominfo.ihm.vueUtil.GrilleDonneesModel;
import prominfo.ihm.vueUtil.MultiButtonEditor;
import prominfo.ihm.vueUtil.MultiButtonRenderer;

import java.awt.Cursor;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JTable;
import javax.swing.SwingUtilities;

import javax.swing.table.DefaultTableModel;

public class GrilleDonneesRessources extends GrilleDonneesModel implements MouseListener
{
	private Controleur ctrl;

	private FrameRessources frameRessources;

	private String[]   tabEntetes;
	private Object[][] tabDonnees;

	private String[]   tabNomsRessources;
	private String[]   tabCodesRessources;

	private int indexEnonce;

	private boolean estOuvert = false;

	public GrilleDonneesRessources(Controleur ctrl, FrameRessources frameRessources)
	{
		this.ctrl            = ctrl;
		this.frameRessources = frameRessources;

		this.tblGrille = new JTable(this);

		this.majGrille();
	}

	public void majGrille()
	{
		this.tabNomsRessources = this.ctrl.getNomsRessources();
		this.tabCodesRessources = this.ctrl.getCodesRessources();

		this.setTabEntetes(new String[] {"Code", "Nom", "Actions"} );
		this.indexEnonce = this.getIntColumn("Nom");
		this.tabEntetes = this.getTabEntetes();

		this.setTabDonnees(new Object[this.tabCodesRessources.length][this.tabEntetes.length]);
		this.tabDonnees = this.getTabDonnees();

		for (int i = 0; i < this.tabCodesRessources.length; i++)
		{
			this.tabDonnees[i][0] = "R" + this.tabCodesRessources[i].charAt(0) + "." + this.tabCodesRessources[i].substring(1);
			this.tabDonnees[i][1] = this.tabNomsRessources[i];
			this.tabDonnees[i][2] = "Actions";
		}

		this.tblGrille.setModel(new DefaultTableModel(this.tabDonnees, this.tabEntetes));
		this.tblGrille.getColumn("Actions").setCellRenderer(new MultiButtonRenderer());
		this.tblGrille.getColumn("Actions").setCellEditor(new MultiButtonEditor(this));
		this.tblGrille.setRowHeight(40);

		this.tblGrille.addMouseListener(this);
		this.fireTableDataChanged();
	}

	@Override
	public void supprimer(int ligne)
	{
		String codeRess = this.tabCodesRessources[ligne];
		this.ctrl.supprimerRessource(codeRess);
		this.majGrille();
	}

	public void modifier(int ligne)
	{
		new FrameCreationRessource(this.frameRessources.getCtrl(), this, this.tabCodesRessources[ligne], this.tabNomsRessources[ligne]);
	}

	public boolean isCellEditable(int row, int col)
	{
		for (int cpt = 0; cpt < this.tabEntetes.length; cpt++)
		{
			if (this.tabEntetes[cpt].equals("Actions"))
			{
				return col == cpt;
			}
		}

		return false;
	}

	public int getIndexEnonce()
	{
		return this.indexEnonce;
	}

	public void mouseEntered(MouseEvent e)
	{
		this.tblGrille.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseExited(MouseEvent e)
	{
		this.tblGrille.setCursor(Cursor.getDefaultCursor());
	}

	public void mouseClicked(MouseEvent e)
	{
		if (e.getClickCount() == 1)
		{
			int col = this.tblGrille.columnAtPoint(e.getPoint());
			int row = this.tblGrille.rowAtPoint(e.getPoint());

			if (col != this.getIntColumn("Actions"))
			{
				String codeRessource = this.tabCodesRessources[row];

				if (!this.estOuvert)
				{
					this.estOuvert = true;
					SwingUtilities.invokeLater(() ->
					{
						new FrameNotions(this.ctrl, this.frameRessources, codeRessource).setVisible(true);
						this.frameRessources.dispose();
						this.estOuvert = false;
					});
				}
			}
		}
	}

	public void mousePressed (MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
}
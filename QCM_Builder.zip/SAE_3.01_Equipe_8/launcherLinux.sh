#!/bin/bash

#Donner les permissions d'exécution au script lui-même
chmod +x "$0"

#Compilation
javac -d bin src/prominfo/*.java

#Exécution
java -cp bin prominfo.Controleur